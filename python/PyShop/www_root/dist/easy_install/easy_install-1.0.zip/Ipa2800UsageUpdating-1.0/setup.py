from setuptools import setup

setup(name='Ipa2800UsageUpdating',
      version='1.0',
      description='Usage updating for IPA2800 based equipment',
      author='IPATA',
      author_email='coo-ra-mr-ipatasigmateamdg@mlist.emea.nsn-intra.net',
      url='',      
      package_dir={'': 'src'},
      platforms    = 'any',
      )

