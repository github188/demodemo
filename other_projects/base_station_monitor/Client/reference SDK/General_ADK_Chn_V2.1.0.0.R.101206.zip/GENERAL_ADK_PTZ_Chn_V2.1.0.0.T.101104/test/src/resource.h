//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ADKPTZOcxTest.rc
//
#define IDD_ADKPTZOCXTEST_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON1                     1000
#define IDC_EDIT1                       1001
#define IDC_ADKPTZOCXCTRL1              1002
#define IDC_EDIT2                       1003
#define IDC_EDIT3                       1004
#define IDC_EDIT4                       1005
#define IDC_EDIT5                       1006
#define IDC_BUTTON2                     1007
#define IDC_BUTTON3                     1008
#define IDC_BUTTON4                     1009
#define IDC_BUTTON5                     1010
#define IDC_BUTTON6                     1011
#define IDC_BUTTON7                     1012
#define IDC_BUTTON8                     1013
#define IDC_BUTTON9                     1014
#define IDC_BUTTON10                    1015
#define IDC_BUTTON11                    1016
#define IDC_BUTTON12                    1017
#define IDC_BUTTON13                    1018
#define IDC_BUTTON14                    1019
#define IDC_BUTTON15                    1020
#define IDC_BUTTON16                    1021
#define IDC_BUTTON17                    1022
#define IDC_BUTTON18                    1023
#define IDC_BUTTON19                    1024
#define IDC_BUTTON20                    1025
#define IDC_EDIT6                       1026
#define IDC_BUTTON21                    1027
#define IDC_BUTTON22                    1028
#define IDC_BUTTON23                    1029
#define IDC_EDIT7                       1030
#define IDC_COMBO1                      1031
#define IDC_BUTTON24                    1032
#define IDC_EDIT8                       1033
#define IDC_EDIT9                       1034
#define IDC_BTN_GETVERSION              1035
#define IDC_COMBO2                      1036
#define IDC_EDIT10                      1037
#define IDC_STATIC_DMS                  1038
#define IDC_STATIC_DEV                  1039
#define IDC_STATIC_CURDEV               1040
#define IDC_STATIC_LIST                 1041
#define IDC_STATIC_ADDDEV               1042
#define IDC_STATIC_USER                 1043
#define IDC_STATIC_PSW                  1044
#define IDC_STATIC_PORT                 1045
#define IDC_STATIC_CHL                  1046
#define IDC_STATIC_INTERFACE            1047
#define IDC_STATIC_STEP                 1048
#define IDC_STATIC_ZOOM                 1049
#define IDC_STATIC_FOCUS                1050
#define IDC_STATIC_IRIS                 1051
#define IDC_STATIC_PRESET               1052
#define IDC_STATIC_DDNSPORT             1053
#define IDC_STATIC_VISION               1054
#define IDC_STATIC_PTZ                  1055

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1056
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
