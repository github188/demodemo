// ADKPTZOcxTestDlg.h : ͷ�ļ�
//

#pragma once
#include "adkptzocxctrl1.h"
#include "afxwin.h"

#include "DemoLanguage.h"

// CADKPTZOcxTestDlg �Ի���
class CADKPTZOcxTestDlg : public CDialog
{
// ����
public:
	CADKPTZOcxTestDlg(CWnd* pParent = NULL);	// ��׼���캯��
	virtual ~CADKPTZOcxTestDlg();

// �Ի�������
	enum { IDD = IDD_ADKPTZOCXTEST_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON				m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
	BOOL	 m_bEnablePanel;
	BOOL m_bExistSit;
	BOOL	 m_bSitSwitch;
	BOOL m_bHidSwitch;
	long m_nDmsId;
	long m_nCameraId;

public:
	CAdkptzocxctrl1	m_ptzOcx;
	CEdit m_editDmsIp;
	CEdit m_editCameraIp;
	CEdit m_editUser;
	CEdit m_editPassword;
	CEdit	m_editNum;
	CEdit m_editCurIndex;
	CEdit m_editChannel;
	CComboBox m_comOwnIndex;
	CButton m_btnLoginDMS;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton6();
	afx_msg void OnBnClickedButton7();
	afx_msg void OnBnClickedButton8();
	afx_msg void OnBnClickedButton9();
	afx_msg void OnBnClickedButton10();
	afx_msg void OnBnClickedButton11();
	afx_msg void OnBnClickedButton12();
	afx_msg void OnBnClickedButton13();
	afx_msg void OnBnClickedButton14();
	afx_msg void OnBnClickedButton15();
	afx_msg void OnBnClickedButton16();
	afx_msg void OnBnClickedButton17();
	afx_msg void OnBnClickedButton18();
	afx_msg void OnBnClickedButton19();
	afx_msg void OnBnClickedButton20();
	afx_msg void OnBnClickedButton21();
	afx_msg void OnBnClickedButton22();
	afx_msg void OnBnClickedButton23();
	CEdit m_editDdnsIp;
	CEdit m_editDdnsPort;
	afx_msg void OnBnClickedButton24();
	afx_msg void OnBnClickedBtnGetversion();
	CComboBox m_comStep;
	CEdit m_editCameraPort;

	//CDemoLanguage*		m_pInitLanguage;
	
};

//#define LOAD_CS2(x)	m_pInitLanguage->ConvertString(x)