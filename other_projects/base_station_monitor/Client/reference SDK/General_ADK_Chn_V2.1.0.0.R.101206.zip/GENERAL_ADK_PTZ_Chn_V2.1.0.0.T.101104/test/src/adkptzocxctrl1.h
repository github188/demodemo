#pragma once

// ������������� Microsoft Visual C++ ������ IDispatch ��װ��

// ע��: ��Ҫ�޸Ĵ��ļ������ݡ����������
//  Microsoft Visual C++ �������ɣ������޸Ľ�����д��

/////////////////////////////////////////////////////////////////////////////
// CAdkptzocxctrl1 ��װ��

class CAdkptzocxctrl1 : public CWnd
{
protected:
	DECLARE_DYNCREATE(CAdkptzocxctrl1)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0x5DAB9C50, 0x45D5, 0x4138, { 0xA0, 0xA2, 0xD2, 0xB0, 0xB2, 0x55, 0x1E, 0x3F } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle,
						const RECT& rect, CWnd* pParentWnd, UINT nID, 
						CCreateContext* pContext = NULL)
	{ 
		return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID); 
	}

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, 
				UINT nID, CFile* pPersist = NULL, BOOL bStorage = FALSE,
				BSTR bstrLicKey = NULL)
	{ 
		return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
		pPersist, bStorage, bstrLicKey); 
	}

// ����
public:


// ����
public:

// _DADKPTZOcx

// Functions
//

	long AddDmsServer(LPCTSTR strDmsIp, long nDmsPort, LPCTSTR strDmsPsw)
	{
		long result;
		static BYTE parms[] = VTS_BSTR VTS_I4 VTS_BSTR ;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_I4, (void*)&result, parms, strDmsIp, nDmsPort, strDmsPsw);
		return result;
	}
	long AddCamera(long nDmsId, LPCTSTR strDevIp, long nDevPort, LPCTSTR strUserName, LPCTSTR strPsw, long nChannel)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_BSTR VTS_I4 VTS_BSTR VTS_BSTR VTS_I4 ;
		InvokeHelper(0x2, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nDmsId, strDevIp, nDevPort, strUserName, strPsw, nChannel);
		return result;
	}
	long SetCurCamera(long nCameraId)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x3, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nCameraId);
		return result;
	}
	long SetParameter(long nKey, long nValue)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 ;
		InvokeHelper(0x4, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nKey, nValue);
		return result;
	}
	long EnablePanel(long nEnable)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x5, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nEnable);
		return result;
	}
	long HidePanel(long nEnable)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x6, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nEnable);
		return result;
	}
	long SendSITCommand(long nWndHandle, long nLeft, long nTop, long nRight, long nBottom, long nReverse)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0x7, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndHandle, nLeft, nTop, nRight, nBottom, nReverse);
		return result;
	}
	long SendDirectionCommand(long nDirection, long nStep)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 ;
		InvokeHelper(0x8, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nDirection, nStep);
		return result;
	}
	long SendCameraCommand(long nOperation, long nAct)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 ;
		InvokeHelper(0x9, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nOperation, nAct);
		return result;
	}
	long SendPrepointCommand(long nOperation, long nNum)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 ;
		InvokeHelper(0xa, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nOperation, nNum);
		return result;
	}
	long AddDDNSServer(long nDmsId, LPCTSTR strIp, long nPort, LPCTSTR strVersion)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_BSTR VTS_I4 VTS_BSTR ;
		InvokeHelper(0xb, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nDmsId, strIp, nPort, strVersion);
		return result;
	}
	CString GetVersion()
	{
		CString result;
		InvokeHelper(0xc, DISPATCH_METHOD, VT_BSTR, (void*)&result, NULL);
		return result;
	}

// Properties
//



};
