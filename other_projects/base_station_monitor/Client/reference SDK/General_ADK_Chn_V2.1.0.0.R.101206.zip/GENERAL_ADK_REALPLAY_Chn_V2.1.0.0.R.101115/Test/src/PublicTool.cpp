#include "StdAfx.h"
#include "PublicTool.h"

PublicTool::PublicTool(void)
{
}

PublicTool::~PublicTool(void)
{
}


CString PublicTool::GetIp(DWORD IP)
{
	char szaddr[16]={0};
	byte* p = reinterpret_cast<byte*>(&IP);
	sprintf(szaddr, "%d.%d.%d.%d", p[3], p[2], p[1], p[0]);
	CString strIp(szaddr);

	return strIp;
}

DWORD PublicTool::GetIp(CString IP)
{
	DWORD dwIP = inet_addr(IP);
	dwIP = htonl( dwIP );

	return dwIP;
}

DWORD PublicTool::GetIp(char* IP)
{
	DWORD dwIP = inet_addr(IP);
	dwIP = htonl( dwIP );

	return dwIP;
}

CString PublicTool::GetSelfPath()
{
	TCHAR sDrive[_MAX_DRIVE];   
	TCHAR sDir[_MAX_DIR];   
	TCHAR sFilename[_MAX_FNAME], Filename[_MAX_FNAME];   
	TCHAR sExt[_MAX_EXT];   
	GetModuleFileName(AfxGetInstanceHandle(), Filename, _MAX_PATH);   
	_tsplitpath(Filename, sDrive, sDir, sFilename, sExt);   
	CString homeDir(CString(sDrive) + CString(sDir));   
	int nLen = homeDir.GetLength();   
	if(homeDir.GetAt(nLen - 1) != _T('\\')) 
	{
		homeDir += _T('\\');
	}

	return CString(homeDir);
}