#pragma once

#include <WinSock2.h>
#pragma  comment(lib, "ws2_32.lib")

class PublicTool
{
public:
	PublicTool(void);

	~PublicTool(void);

	CString GetIp(DWORD IP);

	DWORD GetIp(CString IP);

	DWORD GetIp(char* IP);

	CString GetSelfPath();
};
