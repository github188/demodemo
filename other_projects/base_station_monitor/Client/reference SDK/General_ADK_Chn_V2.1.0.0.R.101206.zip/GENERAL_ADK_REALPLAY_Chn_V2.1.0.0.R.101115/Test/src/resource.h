//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TestAdkRealPlayOcx.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTADKREALPLAYOCX_DIALOG   102
#define IDR_MAINFRAME                   128
#define IDC_ADKREALPLAYOCXCTRL1         1000
#define IDC_ADKREALPLAYOCXCTRL          1000
#define IDC_EDIT_WND_MUM                1001
#define IDC_BUTTON_SET_WND_NUM          1002
#define IDC_BUTTON_FULLSCREEN           1004
#define IDC_BUTTON_GET_WND_NUM          1005
#define IDC_IPADDRESS_MTS_IP            1006
#define IDC_BUTTON_ADD_MTS              1007
#define IDC_EDIT_MTS_PORT               1008
#define IDC_EDIT_MTS_PWD                1009
#define IDC_IPADDRESS_DEV_IP            1010
#define IDC_BUTTON_ADD_MTS2             1010
#define IDC_BUTTON_REMOVE_MTS2          1010
#define IDC_EDIT_DEV_PORT               1011
#define IDC_EDIT_DEV_PWD                1012
#define IDC_EDIT_DEV_USERNAME           1013
#define IDC_EDIT_DEV_CHANNEL            1014
#define IDC_EDIT_WND_INDEX              1015
#define IDC_BUTTON_OPEN_REALPLAY        1016
#define IDC_BUTTON_CLOSE_REALPLAY       1017
#define IDC_BUTTON_STOP_REALPLAY        1017
#define IDC_BUTTON_START_TALK_DEV       1018
#define IDC_EDIT2                       1019
#define IDC_EDIT_PATH_SNAP              1019
#define IDC_BUTTON_OPEN_SOUND           1020
#define IDC_BUTTON_CLOSE_SOUND          1021
#define IDC_BUTTON_START_TALK_WND       1022
#define IDC_BUTTON_STOP_TALK2           1023
#define IDC_BUTTON_STOP_TALK            1023
#define IDC_EDIT_MTS_ID_DDNS            1024
#define IDC_EDIT_MTS_ID                 1025
#define IDC_BUTTON_SET_PARAM            1026
#define IDC_BUTTON_SET_RC               1027
#define IDC_EDIT_PATH_VALUE             1028
#define IDC_BUTTON_OPEN_REALPLAY2       1028
#define IDC_BUTTON_OPEN_REALPLAY_EX     1028
#define IDC_BUTTON_SET_PATH             1029
#define IDC_EDIT_WORK_PATH              1029
#define IDC_BUTTON3                     1030
#define IDC_BUTTON_SNAP                 1030
#define IDC_COMBO_RECORD_TYPE           1031
#define IDC_EDIT_WND_INDEX_SNAP         1032
#define IDC_COMBO_FULLSCREEN            1033
#define IDC_COMBO_PARAM_TYPE            1034
#define IDC_COMBO_PARAM_VALUE           1035
#define IDC_EDIT4                       1036
#define IDC_EDIT_PATH_RECORD            1036
#define IDC_BUTTON5                     1037
#define IDC_BUTTON_START_RECORD         1037
#define IDC_EDIT_WND_INDEX_RECORD       1038
#define IDC_BUTTON6                     1039
#define IDC_BUTTON_STOP_RECOR           1039
#define IDC_EDIT_DEV_CHANNEL2           1040
#define IDC_EDIT_WND_INDEX_OP           1040
#define IDC_BUTTON_SET_POPMENU          1041
#define IDC_BUTTON_SNAP2                1041
#define IDC_BUTTON_VERSION              1041
#define IDC_COMBO_PATH_TYPE             1042
#define IDC_BUTTON_SET_WORK_PATH        1042
#define IDC_COMBO_POPMENU_VALUE         1043
#define IDC_COMBO_PARAM_VALUE2          1043
#define IDC_COMBO_WORK_PATH             1043
#define IDC_COMBO_POPMENU_TYPE          1044
#define IDC_BUTTON_SET_SIT              1045
#define IDC_COMBO_POPMENU_VALUE2        1046
#define IDC_COMBO_SET_RECT              1046
#define IDC_EDIT_OLD_WND_INDEX          1047
#define IDC_EDIT_WND_INDEX_RECORD2      1048
#define IDC_EDIT_WND_INDEX_SET_RECT     1048
#define IDC_EDIT_OLD_WND_CAMERA_ID      1049
#define IDC_EDIT_NEW_WND_INDEX          1050
#define IDC_EDIT_NEW_WND_CAMERA_ID      1051
#define IDC_EDIT_WND_INDEX_RECT         1052
#define IDC_EDIT_POS_LEFT               1053
#define IDC_EDIT_POS_RIGHT              1054
#define IDC_EDIT_POS_TOP                1055
#define IDC_EDIT_NEW_WND_EXTEND         1056
#define IDC_EDIT_POS_BOTTOM             1057
#define IDC_EDIT_POS_REVERSE            1058
#define IDC_IPADDRESS_DDNS_IP           1059
#define IDC_EDIT_DDNS_PORT              1060
#define IDC_BUTTON_SET_SIT2             1061
#define IDC_BUTTON_SET_DDNS             1061
#define IDC_EDIT_DEVICE_IP              1062
#define IDC_EDIT_WND_INDEX_SET_SELECT   1063
#define IDC_BUTTON_SET_SELECT_WND       1064
#define IDC_COMBO_RC_CTL                1065
#define IDC_COMBO_RC_VL                 1066

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1067
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
