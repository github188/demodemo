// TestAdkRealPlayOcxDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "TestAdkRealPlayOcx.h"
#include "TestAdkRealPlayOcxDlg.h"

//#include "vld.h"

#include "multilanguage.h"

#define		LANGUAGE_FILE       ("Language.ini")
#define		CHINESE_SIMPLE		("ChineseSimple.ini")
#define		ENGLISH				("English.ini")

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CTestAdkRealPlayOcxDlg �Ի���




CTestAdkRealPlayOcxDlg::CTestAdkRealPlayOcxDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestAdkRealPlayOcxDlg::IDD, pParent)
	, m_wndNum(4)
	, m_MTS_IP(0)
	, m_MTS_Port(9110)
	, m_wndIndex(0)
	, m_devicePort(37777)
	, m_username(_T("admin"))
	, m_password(_T("admin"))
	, m_channel(0)
	, m_wndIndexOP(0)
	, m_pathSnap(_T("C:\\PATH\\picture.bmp"))
	, m_wndIndexSnap(0)
	, m_wndIndexRecord(0)
	, m_pathRecrod(_T("C:\\PATH\\record.dav"))
	, m_wndIndexSetRect(0)
	, m_DDNS_IP(0)
	, m_DDNS_Port(0)
	, m_oldWndIndex(0)
	, m_oldCameraID(_T(""))
	, m_newWndIndex(0)
	, m_newCameraID(_T(""))
	, m_extendValue(_T(""))
	, m_wndIndexRect(0)
	, m_rectLeft(0)
	, m_rectRight(0)
	, m_rectTop(0)
	, m_rectBottom(0)
	, m_rectReverse(0)
	, m_devIP(_T("20.2.1.36"))	//10.7.10.205 20.2.1.36 10.7.4.29
	, m_MTS_ID(0)
	, m_mtsIdDdns(0)
	, m_wndIndexselected(0)
	, m_bFullScreen(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestAdkRealPlayOcxDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_FULLSCREEN, m_fullScreenCtrl);
	DDX_Control(pDX, IDC_COMBO_PARAM_TYPE, m_paramTypeCtrl);
	DDX_Control(pDX, IDC_COMBO_PARAM_VALUE, m_paramValueCtrl);
	DDX_Control(pDX, IDC_COMBO_RECORD_TYPE, m_recordTypeCtrl);
	DDX_Text(pDX, IDC_EDIT_WND_MUM, m_wndNum);
	DDX_IPAddress(pDX, IDC_IPADDRESS_MTS_IP, m_MTS_IP);
	DDX_Text(pDX, IDC_EDIT_MTS_PORT, m_MTS_Port);
	DDX_Text(pDX, IDC_EDIT_WND_INDEX, m_wndIndex);
	DDX_Text(pDX, IDC_EDIT_DEV_PORT, m_devicePort);
	DDX_Text(pDX, IDC_EDIT_DEV_USERNAME, m_username);
	DDX_Text(pDX, IDC_EDIT_DEV_PWD, m_password);
	DDX_Text(pDX, IDC_EDIT_DEV_CHANNEL, m_channel);
	DDV_MinMaxLong(pDX, m_channel, 0, 15);
	DDX_Control(pDX, IDC_ADKREALPLAYOCXCTRL, m_AdkRealPlayOcx);
	DDX_Text(pDX, IDC_EDIT_WND_INDEX_OP, m_wndIndexOP);
	DDV_MinMaxLong(pDX, m_wndIndexOP, 0, 36);
	DDX_Text(pDX, IDC_EDIT_PATH_SNAP, m_pathSnap);
	DDX_Text(pDX, IDC_EDIT_WND_INDEX_SNAP, m_wndIndexSnap);
	DDX_Text(pDX, IDC_EDIT_WND_INDEX_RECORD, m_wndIndexRecord);
	DDX_Text(pDX, IDC_EDIT_PATH_RECORD, m_pathRecrod);
	DDX_Text(pDX, IDC_EDIT_WND_INDEX_SET_RECT, m_wndIndexSetRect);
	DDX_Control(pDX, IDC_COMBO_SET_RECT, m_setRectCtrl);
	DDX_IPAddress(pDX, IDC_IPADDRESS_DDNS_IP, m_DDNS_IP);
	DDX_Text(pDX, IDC_EDIT_DDNS_PORT, m_DDNS_Port);
	DDX_Text(pDX, IDC_EDIT_OLD_WND_INDEX, m_oldWndIndex);
	DDX_Text(pDX, IDC_EDIT_OLD_WND_CAMERA_ID, m_oldCameraID);
	DDX_Text(pDX, IDC_EDIT_NEW_WND_INDEX, m_newWndIndex);
	DDX_Text(pDX, IDC_EDIT_NEW_WND_CAMERA_ID, m_newCameraID);
	DDX_Text(pDX, IDC_EDIT_NEW_WND_EXTEND, m_extendValue);
	DDX_Text(pDX, IDC_EDIT_WND_INDEX_RECT, m_wndIndexRect);
	DDX_Text(pDX, IDC_EDIT_POS_LEFT, m_rectLeft);
	DDX_Text(pDX, IDC_EDIT_POS_RIGHT, m_rectRight);
	DDX_Text(pDX, IDC_EDIT_POS_TOP, m_rectTop);
	DDX_Text(pDX, IDC_EDIT_POS_BOTTOM, m_rectBottom);
	DDX_Text(pDX, IDC_EDIT_POS_REVERSE, m_rectReverse);
	DDX_Text(pDX, IDC_EDIT_DEVICE_IP, m_devIP);
	DDX_Text(pDX, IDC_EDIT_MTS_ID, m_MTS_ID);
	DDX_Text(pDX, IDC_EDIT_MTS_ID_DDNS, m_mtsIdDdns);
	DDX_Text(pDX, IDC_EDIT_WND_INDEX_SET_SELECT, m_wndIndexselected);
}

BEGIN_MESSAGE_MAP(CTestAdkRealPlayOcxDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_OPEN_REALPLAY, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonOpenRealplay)
	ON_BN_CLICKED(IDC_BUTTON_SET_DDNS, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetDdns)
	ON_BN_CLICKED(IDC_BUTTON_SET_WND_NUM, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetWndNum)
	ON_BN_CLICKED(IDC_BUTTON_GET_WND_NUM, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonGetWndNum)
	ON_BN_CLICKED(IDC_BUTTON_FULLSCREEN, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonFullscreen)
	ON_BN_CLICKED(IDC_BUTTON_ADD_MTS, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonAddMts)
	ON_BN_CLICKED(IDC_BUTTON_START_TALK_DEV, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonStartTalkDev)
	ON_BN_CLICKED(IDC_BUTTON_START_TALK_WND, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonStartTalkWnd)
	ON_BN_CLICKED(IDC_BUTTON_STOP_TALK, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonStopTalk)
	ON_BN_CLICKED(IDC_BUTTON_STOP_REALPLAY, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonStopRealplay)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_SOUND, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonOpenSound)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE_SOUND, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonCloseSound)
	ON_BN_CLICKED(IDC_BUTTON_SET_PARAM, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetParam)
	ON_BN_CLICKED(IDC_BUTTON_SNAP, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonSnap)
	ON_BN_CLICKED(IDC_BUTTON_START_RECORD, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonStartRecord)
	ON_BN_CLICKED(IDC_BUTTON_STOP_RECOR, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonStopRecor)
	ON_BN_CLICKED(IDC_BUTTON_SET_SIT, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetSit)
	ON_BN_CLICKED(IDC_BUTTON_SET_SELECT_WND, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetSelectWnd)
	ON_BN_CLICKED(IDC_BUTTON_VERSION, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonVersion)
	ON_BN_CLICKED(IDC_BUTTON_SET_RC, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetRc)
	ON_BN_CLICKED(IDC_BUTTON_REMOVE_MTS2, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonRemoveMts2)
	ON_COMMAND(ID_RIGHT_CLICK_INDEX, SetFullScreen)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BUTTON_OPEN_REALPLAY_EX, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonOpenRealplayEx)
	ON_BN_CLICKED(IDC_BUTTON_SET_WORK_PATH, &CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetWorkPath)
END_MESSAGE_MAP()


// CTestAdkRealPlayOcxDlg ��Ϣ��������

BOOL CTestAdkRealPlayOcxDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������

	char* pLanguageFilePath = new char[MAX_PATH];
	memset(pLanguageFilePath , 0 , MAX_PATH);
	int len = CMultiLanguage::GetModuleFileInformations(pLanguageFilePath);
	strcat(pLanguageFilePath , (const char*)LANGUAGE_FILE);
	//strcat(pLanguageFilePath , (const char*)ENGLISH);
	//strcat(pLanguageFilePath , (const char*)CHINESE_SIMPLE);
	_LANGUAGE_INIT(pLanguageFilePath);
	delete[] pLanguageFilePath;

	_CWndCS(this);

	m_fullScreenCtrl.InsertString(0, _CS("Normal"));
	m_fullScreenCtrl.InsertString(1, _CS("Full Screen"));
	m_fullScreenCtrl.SetCurSel(1);

	m_paramTypeCtrl.InsertString(0, _CS("Video Repeat"));
	m_paramTypeCtrl.SetCurSel(0);

	m_paramValueCtrl.InsertString(0, _CS("Disable"));
	m_paramValueCtrl.InsertString(1, _CS("Enable"));
	m_paramValueCtrl.SetCurSel(1);

	m_recordTypeCtrl.InsertString(0, "dav");
	//m_recordTypeCtrl.InsertString(1, "avi");
	m_recordTypeCtrl.SetCurSel(0);

	CString defaultMtsIP("20.2.1.36");
	m_MTS_IP = m_tool.GetIp(defaultMtsIP);

	m_setRectCtrl.InsertString(0, _CS("Disable"));
	m_setRectCtrl.InsertString(1, _CS("Enable"));
	m_setRectCtrl.SetCurSel(1);

	//����video�����Ҽ�
	//m_AdkRealPlayOcx.SetPopMenu(0,1);
	//m_AdkRealPlayOcx.SetPopMenu(1,1);
	//m_AdkRealPlayOcx.SetPopMenu(2,1);
	//m_AdkRealPlayOcx.SetPopMenu(3,1);
	//m_AdkRealPlayOcx.SetPopMenu(4,1);
	//m_AdkRealPlayOcx.SetPopMenu(5,1);

	((CComboBox*)GetDlgItem(IDC_COMBO_RC_CTL))->InsertString(0, _CS("Close Video"));
	((CComboBox*)GetDlgItem(IDC_COMBO_RC_CTL))->InsertString(1, _CS("Record"));
	((CComboBox*)GetDlgItem(IDC_COMBO_RC_CTL))->InsertString(2, _CS("Snap"));
	((CComboBox*)GetDlgItem(IDC_COMBO_RC_CTL))->InsertString(3, _CS("Audio"));
	((CComboBox*)GetDlgItem(IDC_COMBO_RC_CTL))->InsertString(4, _CS("Talk"));
	((CComboBox*)GetDlgItem(IDC_COMBO_RC_CTL))->InsertString(5, _CS("Fullscreen"));
	((CComboBox*)GetDlgItem(IDC_COMBO_RC_CTL))->SetCurSel(0);

	((CComboBox*)GetDlgItem(IDC_COMBO_RC_VL))->InsertString(0, _CS("Disable"));
	((CComboBox*)GetDlgItem(IDC_COMBO_RC_VL))->InsertString(1, _CS("Enable"));
	((CComboBox*)GetDlgItem(IDC_COMBO_RC_VL))->SetCurSel(1);

	
	((CComboBox*)GetDlgItem(IDC_COMBO_WORK_PATH))->InsertString(0, _CS("Snap"));
	((CComboBox*)GetDlgItem(IDC_COMBO_WORK_PATH))->InsertString(1, _CS("Record"));
	((CComboBox*)GetDlgItem(IDC_COMBO_WORK_PATH))->SetCurSel(0);

	//GetDlgItem(IDC_EDIT_WORK_PATH)->SetDlgItemText(_T("C:\\PIC"));
	SetDlgItemText(IDC_EDIT_WORK_PATH, _T("C:\\PIC"));

	GetDlgItem(IDC_BUTTON_REMOVE_MTS2)->EnableWindow(FALSE);

	UpdateData(FALSE);

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CTestAdkRealPlayOcxDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CTestAdkRealPlayOcxDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ��������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ��
//
HCURSOR CTestAdkRealPlayOcxDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonOpenRealplay()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

	long res = m_AdkRealPlayOcx.RealPlay(m_MTS_ID,
										m_devIP, 
										m_devicePort,
										m_username,
										m_password,
										m_channel,
										m_wndIndex);

	ShowRes(res);
}


void CTestAdkRealPlayOcxDlg::OnBnClickedButtonOpenRealplayEx()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

 	long res = m_AdkRealPlayOcx.RealPlayEx(m_MTS_ID,
 		m_devIP, 
 		m_devicePort,
 		m_username,
 		m_password,
 		m_channel,
 		m_wndIndex);
 
 	ShowRes(res);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetDdns()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	UpdateData();
	CString DDNS_IP("");
	DDNS_IP = m_tool.GetIp(m_DDNS_IP);
	long res = m_AdkRealPlayOcx.AddDDNSServer(m_mtsIdDdns, DDNS_IP, m_DDNS_Port, "");
	ShowRes(res);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetWndNum()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//UpdateData();
	//long res = m_AdkRealPlayOcx.SetVideoWndNum(m_wndNum);

	CString strWndNum;
	GetDlgItemText(IDC_EDIT_WND_MUM, strWndNum);
	long res = m_AdkRealPlayOcx.SetVideoWndNum(_tstoi(strWndNum));
	if ( 0 > res)
	{
		ShowRes(res);
	}
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonGetWndNum()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	ShowInfo(m_AdkRealPlayOcx.GetSelWndIndex());
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonFullscreen()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//int fullScreenValue = m_fullScreenCtrl.GetCurSel();
	//m_AdkRealPlayOcx.FullScreen(fullScreenValue);
	SetFullScreen();
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonAddMts()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	CString MTS_IP("10.7.9.60");
	MTS_IP = m_tool.GetIp(m_MTS_IP);

	long mtsid = m_AdkRealPlayOcx.AddMTSServer(MTS_IP, m_MTS_Port, "");

	if (mtsid > 0)
	{
		m_MTS_ID = mtsid;
		m_mtsIdDdns = mtsid;

		GetDlgItem(IDC_BUTTON_ADD_MTS)->EnableWindow(FALSE);
		GetDlgItem(IDC_BUTTON_REMOVE_MTS2)->EnableWindow(TRUE);

		UpdateData(FALSE);
	}
	

	ShowResMts(mtsid);
}


void CTestAdkRealPlayOcxDlg::OnBnClickedButtonRemoveMts2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	long res = m_AdkRealPlayOcx.RemoveMTSServer(m_MTS_ID);
	if ( 0 <= res)
	{
		GetDlgItem(IDC_BUTTON_ADD_MTS)->EnableWindow(TRUE);
		GetDlgItem(IDC_BUTTON_REMOVE_MTS2)->EnableWindow(FALSE);
	}
	ShowRes(res);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonStartTalkDev()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

	long res = m_AdkRealPlayOcx.StartTalkByDev(	m_MTS_ID,
												m_devIP,
												m_devicePort,
												m_username,
												m_password);
	ShowRes(res);
	
}

void CTestAdkRealPlayOcxDlg::ShowRes(long res)
{
	CString resStr("");
	if (res >= 0) 
	{
		resStr.Format(_CS("Success"));
	}
	else
	{
		resStr.Format("%s, %s : %d", _CS("Failed"), _CS("Error Code"), res);
	}

	MessageBox(resStr);
}

void CTestAdkRealPlayOcxDlg::ShowInfo(long info)
{
	CString infoStr("");
	infoStr.Format("%d", info);

	MessageBox(infoStr);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonStartTalkWnd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	UpdateData();
	long res = m_AdkRealPlayOcx.StartTalkByWnd(m_wndIndexOP);
	ShowRes(res);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonStopTalk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	UpdateData();
	long res = m_AdkRealPlayOcx.StopTalk();
	ShowRes(res);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonStopRealplay()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	long res  = m_AdkRealPlayOcx.StopRealPlay(m_wndIndexOP);
	ShowRes(res);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonOpenSound()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	long res = m_AdkRealPlayOcx.EnableAudio(m_wndIndexOP, 1);
	ShowRes(res);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonCloseSound()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	UpdateData();
	long res = m_AdkRealPlayOcx.EnableAudio(m_wndIndexOP, 0);
	ShowRes(res);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetParam()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	long patamType = m_paramTypeCtrl.GetCurSel();
	long paramValue = m_paramValueCtrl.GetCurSel();

	long res  = m_AdkRealPlayOcx.SetParameter(patamType, paramValue);
	ShowRes(res);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonSnap()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

	//m_pathRecrod = _T("");
	GetDlgItem(IDC_EDIT_PATH_SNAP)->GetWindowText(m_pathRecrod);

	long res = m_AdkRealPlayOcx.Snap(m_wndIndexSnap, m_pathSnap);

	ShowRes(res);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonStartRecord()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	long res = 0;
	CString strkey = _T("");
	GetDlgItem(IDC_BUTTON_START_RECORD)->GetWindowText(strkey);
	if ( (_T("Start") == strkey) || (_T("��ʼ") == strkey) )
	{
		GetDlgItem(IDC_EDIT_PATH_RECORD)->GetWindowText(m_pathRecrod);
		long recordType = m_recordTypeCtrl.GetCurSel();
		res = m_AdkRealPlayOcx.StartRecord(m_wndIndexRecord, m_pathRecrod, recordType);
		if ( 0 <= res )
		{
			SetDlgItemText(IDC_BUTTON_START_RECORD,_CS("Stop"));
		}
	}
	else if ((_T("Stop") == strkey) || (_T("ֹͣ") == strkey))
	{
		res = m_AdkRealPlayOcx.StopRecord(m_wndIndexRecord);
		if ( 0 <= res )
		{
			SetDlgItemText(IDC_BUTTON_START_RECORD,_CS("Start"));
		}
	}

}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonStopRecor()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	long res = m_AdkRealPlayOcx.StopRecord(m_wndIndexRecord);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetSit()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	UpdateData();
	long sitEnable = m_setRectCtrl.GetCurSel();
	long res = m_AdkRealPlayOcx.EnableSelectRect(m_wndIndexSetRect, sitEnable);
	ShowRes(res);
}
BEGIN_EVENTSINK_MAP(CTestAdkRealPlayOcxDlg, CDialog)
	ON_EVENT(CTestAdkRealPlayOcxDlg, IDC_ADKREALPLAYOCXCTRL, 3, CTestAdkRealPlayOcxDlg::OnRightBtnClickAdkrealplayocxctrl, VTS_NONE)
	ON_EVENT(CTestAdkRealPlayOcxDlg, IDC_ADKREALPLAYOCXCTRL, 1, CTestAdkRealPlayOcxDlg::OnSelectRectAdkrealplayocxctrl, VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4)
	ON_EVENT(CTestAdkRealPlayOcxDlg, IDC_ADKREALPLAYOCXCTRL, 2, CTestAdkRealPlayOcxDlg::OnVideoWndChangedAdkrealplayocxctrl, VTS_I4 VTS_I4 VTS_BSTR VTS_BSTR VTS_BSTR)
	ON_EVENT(CTestAdkRealPlayOcxDlg, IDC_ADKREALPLAYOCXCTRL, 4, CTestAdkRealPlayOcxDlg::OnMTSDisconnectAdkrealplayocxctrl, VTS_I4)
END_EVENTSINK_MAP()

/*
	�Ҽ��¼�,�Զ������Ӱ�ť
*/
void CTestAdkRealPlayOcxDlg::OnRightBtnClickAdkrealplayocxctrl()
{
	// TODO: �ڴ˴�������Ϣ�����������
	//CMenu tempMenu;
	//BOOL bRet = FALSE;
	//tempMenu.CreatePopupMenu();

	////ȫ��
	//tempMenu.AppendMenu(MF_STRING, ID_RIGHT_CLICK_INDEX, (LPCTSTR)(_CS("FullScreen_Ex")));

	//CPoint pt;
	//::GetCursorPos(&pt);
	//tempMenu.TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON , pt.x , pt.y , this);
	//return;
}

void CTestAdkRealPlayOcxDlg::OnSelectRectAdkrealplayocxctrl(long videoWndIndex, long left, long top, long right, long bottom, long reverse)
{
	// TODO: �ڴ˴�������Ϣ�����������
	m_wndIndexRect = videoWndIndex;
	m_rectLeft = left;
	m_rectRight = right;
	m_rectTop = top;
	m_rectBottom = bottom;
	m_rectReverse = reverse;
	UpdateData(FALSE);
}

void CTestAdkRealPlayOcxDlg::OnVideoWndChangedAdkrealplayocxctrl(long oldWndIndex, long newWndIndex, LPCTSTR oldCameraId, LPCTSTR newCameraId, LPCTSTR extend)
{
	// TODO: �ڴ˴�������Ϣ�����������
	m_oldWndIndex = oldWndIndex;
	m_oldCameraID = oldCameraId;
	m_newWndIndex = newWndIndex;
	m_newCameraID = newCameraId;

	m_wndIndex = newWndIndex;
	m_wndIndexOP = newWndIndex;
	m_wndIndexSnap = newWndIndex;
	m_wndIndexRecord = newWndIndex;
	m_wndIndexSetRect = newWndIndex;
	m_wndIndexselected = newWndIndex;

	UpdateData(FALSE);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetSelectWnd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	//UpdateData();
	//long res = m_AdkRealPlayOcx.SetSelectedWnd(m_wndIndexselected);
	CString strIndex;
	GetDlgItemText(IDC_EDIT_WND_INDEX_SET_SELECT, strIndex);

	long res = m_AdkRealPlayOcx.SetSelectedWnd(_tstoi(strIndex));
	if ( 0 > res)
	{
		ShowRes(res);
	}
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonVersion()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString versionInfo("");
	versionInfo = m_AdkRealPlayOcx.GetVersion();

	MessageBox(versionInfo);
}

void CTestAdkRealPlayOcxDlg::ShowResMts(long mtsid)
{
	CString resStr("");

	if (mtsid > 0)
	{
		resStr.Format("%s, MtsId : %d", _CS("Success"), mtsid);
	}
	else
	{
		resStr.Format("%s, %s��%d", _CS("Failed"), _CS("Error Code"), mtsid);
	}

	MessageBox(resStr);
}

void CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetRc()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	long patamType = ((CComboBox*)GetDlgItem(IDC_COMBO_RC_CTL))->GetCurSel();
	long paramValue = ((CComboBox*)GetDlgItem(IDC_COMBO_RC_VL))->GetCurSel();

	long res = m_AdkRealPlayOcx.SetPopMenu(patamType,paramValue);
	ShowRes(res);
}

void CTestAdkRealPlayOcxDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	// TODO: �ڴ˴�������Ϣ�����������
}

void CTestAdkRealPlayOcxDlg::SetFullScreen()
{
	m_AdkRealPlayOcx.FullScreen(1);
	m_bFullScreen = TRUE;
}
void CTestAdkRealPlayOcxDlg::OnMTSDisconnectAdkrealplayocxctrl(long MTS_ID)
{
	// TODO: �ڴ˴�������Ϣ�����������
	return;
}


void CTestAdkRealPlayOcxDlg::OnBnClickedButtonSetWorkPath()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

	GetDlgItem(IDC_EDIT_WORK_PATH)->GetWindowText(m_pathRecrod);
	long type = ((CComboBox*)GetDlgItem(IDC_COMBO_WORK_PATH))->GetCurSel();

	long res = m_AdkRealPlayOcx.SetWorkPath(type, m_pathRecrod);

	ShowRes(res);
}
