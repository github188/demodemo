// TestAdkRealPlayOcxDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "adkrealplayocxctrl.h"
#include "PublicTool.h"

#define  ID_RIGHT_CLICK_INDEX					(WM_USER + 1)
#define  ID_RIGHT_CLICK_INDEX2					(WM_USER + 2)


// CTestAdkRealPlayOcxDlg �Ի���
class CTestAdkRealPlayOcxDlg : public CDialog
{
// ����
public:
	CTestAdkRealPlayOcxDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_TESTADKREALPLAYOCX_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void SetFullScreen();
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnBnClickedButtonOpenRealplay();
	CComboBox m_fullScreenCtrl;
	CComboBox m_paramTypeCtrl;
	CComboBox m_paramValueCtrl;
	CComboBox m_recordTypeCtrl;
	afx_msg void OnBnClickedButtonSetDdns();
	long m_wndNum;
	afx_msg void OnBnClickedButtonSetWndNum();
	DWORD m_MTS_IP;
	long m_MTS_Port;
	long m_wndIndex;
	long m_devicePort;
	CString m_username;
	CString m_password;
	long m_channel;
	CAdkrealplayocxctrl m_AdkRealPlayOcx;
	afx_msg void OnBnClickedButtonGetWndNum();
	afx_msg void OnBnClickedButtonFullscreen();
	afx_msg void OnBnClickedButtonAddMts();

private:
	PublicTool m_tool;
	void ShowRes(long res);
	void ShowInfo(long info);
	void ShowResMts(long mtsid);
public:
	afx_msg void OnBnClickedButtonStartTalkDev();
	afx_msg void OnBnClickedButtonStartTalkWnd();
	long m_wndIndexOP;
	afx_msg void OnBnClickedButtonStopTalk();
	afx_msg void OnBnClickedButtonStopRealplay();
	afx_msg void OnBnClickedButtonOpenSound();
	afx_msg void OnBnClickedButtonCloseSound();
	afx_msg void OnBnClickedButtonSetParam();
	CString m_pathSnap;
	long m_wndIndexSnap;
	long m_wndIndexRecord;
	CString m_pathRecrod;
	afx_msg void OnBnClickedButtonSnap();
	afx_msg void OnBnClickedButtonStartRecord();
	afx_msg void OnBnClickedButtonStopRecor();
	long m_wndIndexSetRect;
	CComboBox m_setRectCtrl;
	afx_msg void OnBnClickedButtonSetSit();
	DWORD m_DDNS_IP;
	long m_DDNS_Port;
	DECLARE_EVENTSINK_MAP()
	void OnRightBtnClickAdkrealplayocxctrl();
	void OnSelectRectAdkrealplayocxctrl(long videoWndIndex, long left, long top, long right, long bottom, long reverse);
	void OnVideoWndChangedAdkrealplayocxctrl(long oldWndIndex, long newWndIndex, LPCTSTR oldCameraId, LPCTSTR newCameraId, LPCTSTR extend);
	long m_oldWndIndex;
	CString m_oldCameraID;
	long m_newWndIndex;
	CString m_newCameraID;
	CString m_extendValue;
	long m_wndIndexRect;
	long m_rectLeft;
	long m_rectRight;
	long m_rectTop;
	long m_rectBottom;
	long m_rectReverse;
	CString m_devIP;
	long m_MTS_ID;
	long m_mtsIdDdns;
	afx_msg void OnBnClickedButtonSetSelectWnd();
	long m_wndIndexselected;
	afx_msg void OnBnClickedButtonVersion();
	afx_msg void OnBnClickedButtonSetRc();
	afx_msg void OnBnClickedButtonRemoveMts2();
	afx_msg void OnSize(UINT nType, int cx, int cy);

	bool m_bFullScreen;
	void OnMTSDisconnectAdkrealplayocxctrl(long MTS_ID);
	afx_msg void OnBnClickedButtonOpenRealplayEx();
	afx_msg void OnBnClickedButtonSetWorkPath();
};
