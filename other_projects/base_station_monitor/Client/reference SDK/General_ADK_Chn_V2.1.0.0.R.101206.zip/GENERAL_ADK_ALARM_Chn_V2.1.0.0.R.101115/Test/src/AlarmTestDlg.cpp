// AlarmTestDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "AlarmTest.h"
#include "AlarmTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAlarmTestDlg �Ի���




CAlarmTestDlg::CAlarmTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAlarmTestDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	//m_pInitLanguage = new CDemoLanguage;
}

CAlarmTestDlg::~CAlarmTestDlg()
{
	CDemoLanguage::UnInstace();
// 	if( m_pInitLanguage != NULL) 
// 	{
// 		delete m_pInitLanguage; 
// 		m_pInitLanguage = NULL;
// 	}
}

void CAlarmTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_editDmsIp);
	DDX_Control(pDX, IDC_EDIT2, m_editDmsPort);
	DDX_Control(pDX, IDC_ADKALARMOCXCTRL1, m_ocxAlarm);
	DDX_Control(pDX, IDC_LIST2, m_listAlarm);
	DDX_Control(pDX, IDC_EDIT3, m_editCameraIp);
	DDX_Control(pDX, IDC_EDIT4, m_editCameraPort);
	DDX_Control(pDX, IDC_EDIT5, m_editCameraChannel);
	DDX_Control(pDX, IDC_EDIT6, m_editUser);
	DDX_Control(pDX, IDC_EDIT7, m_editPassword);
	DDX_Control(pDX, IDC_COMBO1, m_comSessionExist);
	DDX_Control(pDX, IDC_BUTTON1, m_btnLoginDms);
	DDX_Control(pDX, IDC_COMBO2, m_comboAlarmType);
	DDX_Control(pDX, IDC_EDIT8, m_editDdnsIp);
	DDX_Control(pDX, IDC_EDIT9, m_editDdnsPort);
	DDX_Control(pDX, IDC_LIST_DEV_STATUS, m_listDevStatus);
}

BEGIN_MESSAGE_MAP(CAlarmTestDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CAlarmTestDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CAlarmTestDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CAlarmTestDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CAlarmTestDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BTN_GET_VERSION, &CAlarmTestDlg::OnBnClickedBtnGetVersion)
	ON_BN_CLICKED(IDC_BUTTON5, &CAlarmTestDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &CAlarmTestDlg::OnBnClickedButton6)
END_MESSAGE_MAP()


// CAlarmTestDlg ��Ϣ��������

BOOL CAlarmTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	//���������ļ�·��
	TCHAR   cFileName[512] = {0};
	GetModuleFileName(AfxGetInstanceHandle(), cFileName, 512);
	TCHAR acBuf[512];
	GetLongPathName(cFileName,acBuf,512); //ȫ·��
	CString strPre = acBuf;
	CString strPath = strPre.Left(strPre.ReverseFind(_T('\\'))+1);
	if ( strPath.Right(1) != _T("\\"))
	{
		strPath += _T("\\");
	}

	//�����ļ��ĳ�ʼ��
	//CDemoLanguage* pLanguage = m_pInitLanguage;
	if ( !strPath.IsEmpty() )
	{
// 		pLanguage->Init( strPath );
// 		pLanguage->SetCurLanguageSolution( LANGUAGE_CHINESE_VERSION );
// 		//���öԻ����еľ�̬�ı�(Ӣ��-->��ǰ����)
// 		pLanguage->SetWndStaticText(this);

		CDemoLanguage::Instance()->Init( strPath );
		CDemoLanguage::Instance()->SetCurLanguageSolution( LANGUAGE_CHINESE_VERSION );
		//���öԻ����еľ�̬�ı�(Ӣ��-->��ǰ����)
		_CWndCS( this );
	}

	//	Ĭ�϶˿�
	//m_editDmsIp.SetWindowText(_T("20.2.1.36"));
	m_editDmsIp.SetWindowText(_T("10.7.9.60"));
	m_editDmsPort.SetWindowText(_T("9210"));
	m_editCameraPort.SetWindowText(_T("37777"));
	m_editDdnsPort.SetWindowText(_T("7070"));

	GetDlgItem(IDC_EDIT3)->SetWindowText(_T("10.7.10.205"));
	GetDlgItem(IDC_EDIT6)->SetWindowText(_T("admin"));
	GetDlgItem(IDC_EDIT7)->SetWindowText(_T("admin"));

	// ��������
	m_comboAlarmType.AddString(LOAD_CS2(_T("All Type")));
	m_comboAlarmType.AddString(LOAD_CS2(_T("Video Lost")));
	m_comboAlarmType.AddString(LOAD_CS2(_T("Outer Alarm")));
	m_comboAlarmType.AddString(LOAD_CS2(_T("Video Motion")));
	m_comboAlarmType.AddString(LOAD_CS2(_T("Video Cover")));
	m_comboAlarmType.AddString(LOAD_CS2(_T("Disk Full")));
	m_comboAlarmType.AddString(LOAD_CS2(_T("Disk Fault")));
	//m_comboAlarmType.AddString(LOAD_CS2(_T("GPS Alarm")));

	m_comboAlarmType.SetCurSel(0);

	m_listAlarm.SetExtendedStyle( LVS_EX_FLATSB|LVS_EX_FULLROWSELECT|LVS_EX_HEADERDRAGDROP|LVS_EX_ONECLICKACTIVATE|LVS_EX_GRIDLINES);
	m_listAlarm.InsertColumn(0,_T("IP"),LVCFMT_CENTER,90,0);
	m_listAlarm.InsertColumn(1,LOAD_CS2(_T("Port")),LVCFMT_CENTER,50,1);
	m_listAlarm.InsertColumn(2,LOAD_CS2(_T("Channel")),LVCFMT_CENTER,60,2);
	m_listAlarm.InsertColumn(3,LOAD_CS2(_T("Time")),LVCFMT_CENTER,140,3);
	m_listAlarm.InsertColumn(4,LOAD_CS2(_T("AlarmType")),LVCFMT_CENTER,80,4);
	m_listAlarm.InsertColumn(5,LOAD_CS2(_T("Status")),LVCFMT_CENTER,60,5);
	m_listAlarm.InsertColumn(6,_T("Dms"),LVCFMT_CENTER,60,6);
	//m_listAlarm.InsertColumn(7,LOAD_CS2(_T("GPS Add-in")),LVCFMT_CENTER,350,7);

	m_listDevStatus.SetExtendedStyle( LVS_EX_FLATSB|LVS_EX_FULLROWSELECT|LVS_EX_HEADERDRAGDROP|LVS_EX_ONECLICKACTIVATE|LVS_EX_GRIDLINES);
	m_listDevStatus.InsertColumn(0,_T("IP"),LVCFMT_CENTER,90,0);
	m_listDevStatus.InsertColumn(1,LOAD_CS2(_T("Port")),LVCFMT_CENTER,50,1);
	m_listDevStatus.InsertColumn(2,LOAD_CS2(_T("Channel")),LVCFMT_CENTER,60,2);
	m_listDevStatus.InsertColumn(3,LOAD_CS2(_T("Time")),LVCFMT_CENTER,140,3);
	m_listDevStatus.InsertColumn(4,LOAD_CS2(_T("Status")),LVCFMT_CENTER,70,4);
	m_listDevStatus.InsertColumn(5,LOAD_CS2(_T("Add-in")),LVCFMT_CENTER,120,5);

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CAlarmTestDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ��������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ��
//
HCURSOR CAlarmTestDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CAlarmTestDlg::OnBnClickedButton1()	// login DMS
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strDmsIp;
	m_editDmsIp.GetWindowText(strDmsIp);
	m_nCurDmsId = m_ocxAlarm.AddDmsServer(strDmsIp,9210,_T(""));
	if (m_nCurDmsId > 0)
	{
		m_btnLoginDms.EnableWindow(FALSE);
		//MessageBox(_T("��½�ɹ�!"));
		MessageBox(LOAD_CS2(_T("DMS Login Success")),LOAD_CS2(_T("System Prompt")),MB_OK|MB_ICONWARNING);
	}
	else
	{
		//MessageBox(_T("��½ʧ��!"));
		MessageBox(LOAD_CS2(_T("DMS Login Fail")),LOAD_CS2(_T("System Prompt")),MB_OK|MB_ICONWARNING);
	}

}

void CAlarmTestDlg::OnBnClickedButton2()	//	����
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strIp,strUser,strPsw,strChannel,strAlarmType;
	CString strCameraPort;

	m_editCameraIp.GetWindowText(strIp);
	m_editUser.GetWindowText(strUser);
	m_editPassword.GetWindowText(strPsw);
	m_editCameraChannel.GetWindowText(strChannel);
	m_editCameraPort.GetWindowText(strCameraPort);

	//m_comboAlarmType.GetWindowText(strAlarmType);
	int nAlarmType = -1;
	nAlarmType = m_comboAlarmType.GetCurSel();
	if ( nAlarmType < 7 )
	{
		nAlarmType -=1;
	}

	int channel = _wtoi(strChannel);
	int nCameraPort = _wtoi(strCameraPort);
	if ( nCameraPort < 0 )
	{
		return;
	}
	//int nAlarmType = _wtoi(strAlarmType);

	if (m_nCurDmsId < 0)
	{
		//MessageBox(_T("���ȵ�½������!"));
		MessageBox(LOAD_CS2(_T("Please Login DMS first")),LOAD_CS2(_T("System Prompt")),MB_OK|MB_ICONWARNING);
		return;
	}

	int CurSessionId = m_ocxAlarm.SubscribeAlarm( m_nCurDmsId,  strIp, nCameraPort, strUser, strPsw, channel,nAlarmType);
	if( CurSessionId > 0)
	{
		//MessageBox(_T("���ĳɹ�!"));
		MessageBox(LOAD_CS2(_T("Subscribe Success")),LOAD_CS2(_T("System Prompt")),MB_OK|MB_ICONWARNING);
		m_editCameraIp.SetWindowText(_T(""));
		m_editUser.SetWindowText(_T(""));
		m_editPassword.SetWindowText(_T(""));
		m_editCameraChannel.SetWindowText(_T(""));

		int comboCount;
		comboCount = m_comSessionExist.GetCount();
		if(comboCount > 0)
		{
			int i;
			for(i = 0; i < comboCount; i++)
			{
				CString strTmpText("");
				CString strSession;

				m_comSessionExist.GetLBText(i, strTmpText);
				if (strTmpText.IsEmpty())
				{
					continue;
				}

				int nPos = strTmpText.Find('-');
				if ( nPos != -1 )
				{
					strSession = strTmpText.Left(nPos);
				}
				int TempSessionId = _wtoi(strSession);
				if (TempSessionId == CurSessionId)
				{
					return;
				}
			}
		}
	
		// ���Ӷ��ĻỰ����ʽΪ (�ỰID-IP:ͨ�� "SessionId-IP:Channel" )
		CString strTmp("");
		strTmp.Format(_T("%d"), CurSessionId);
		CString strChl("");
		strChl.Format(_T("%d"), channel);
		CString strCombo;
		strCombo = strTmp + '-' + strIp + ':' + strChl;
		m_comSessionExist.AddString(strCombo);
	}
	if( CurSessionId < 0)
	{
		if ( CurSessionId == -312 )
		{
			MessageBox(LOAD_CS2(_T("User & Password clash")),LOAD_CS2(_T("Subscribe Fail")),MB_OK|MB_ICONWARNING);
		}
		else
		{
			//MessageBox(_T("����ʧ�ܣ����飡"));
			CString strErrorCode("");
			strErrorCode.Format(_T("%d"),CurSessionId);
			MessageBox(LOAD_CS2(_T("The Error Code:"))+strErrorCode, LOAD_CS2(_T("Subscribe Fail")),MB_OK|MB_ICONWARNING);
		}
	}
}

void CAlarmTestDlg::OnBnClickedButton3()	//	ȡ������
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strTmp = _T("");
	CString strSession = _T("");
	CString strCameraId = _T("");
	CString strChannel = _T("");
	CString strDevId = _T("");

	m_comSessionExist.GetWindowText(strTmp);
	if ( strTmp.IsEmpty() )
	{
		return;
	}
	int nPos = strTmp.Find('-');
	if ( nPos != -1 )
	{
		strSession = strTmp.Left(nPos);
		strCameraId = strTmp.Right(strTmp.GetLength() - nPos - 1);
	}
	int CurSessionId = _wtoi(strSession);

	nPos = strCameraId.Find(':');
	if ( nPos != -1 )
	{
		strDevId = strCameraId.Left(nPos);
		strChannel = strCameraId.Right(strCameraId.GetLength() - nPos - 1);
	}
	int CurChannel = _wtoi(strChannel);

	if( m_ocxAlarm.CancelSubscribe(CurSessionId) == 0 )
	{
		// ȡ���ɹ����ڻỰ�˵���ɾ������
		int comIndex = m_comSessionExist.GetCurSel();
		m_comSessionExist.DeleteString( comIndex);	

		if ( CurChannel == -1 )		// ȡ�����ĵ�ͨ��Ϊ -1���Ự�˵���ɾ�����豸�����ж���
		{
			int comboCount;
			comboCount = m_comSessionExist.GetCount();
			if(comboCount > 0)
			{
				int i = 0;
				while( i < comboCount )
				{
					CString strTmpText = _T("");
					CString strTempCameraId = _T("");
					CString strTempDevId = _T("");

					m_comSessionExist.GetLBText(i, strTmpText);
					if (strTmpText.IsEmpty())
					{
						continue;
					}

					int nPos = strTmpText.Find('-');
					if ( nPos != -1 )
					{
						strTempCameraId = strTmpText.Right(strTmpText.GetLength() - nPos - 1);
					}

					nPos = strTempCameraId.Find(':');
					if ( nPos != -1 )
					{
						strTempDevId = strTempCameraId.Left(nPos);
					}
					if ( strTempDevId == strDevId )
					{
						m_comSessionExist.DeleteString( i );
					}
					else
					{
						i++;
					}
					comboCount = m_comSessionExist.GetCount();
				}
			}
		}

		m_comSessionExist.SetCurSel(-1);
		//MessageBox(_T("ȡ�����ĳɹ���"));
		MessageBox(LOAD_CS2(_T("Cancel Subscribe Success")),LOAD_CS2(_T("System Prompt")),MB_OK|MB_ICONWARNING);
	}
	else
	{
		//MessageBox(_T("ȡ������ʧ�ܣ����飡"));
		MessageBox(LOAD_CS2(_T("Cancel Subscribe Fail")),LOAD_CS2(_T("System Prompt")),MB_OK|MB_ICONWARNING);
	}
}

BEGIN_EVENTSINK_MAP(CAlarmTestDlg, CDialog)
	ON_EVENT(CAlarmTestDlg, IDC_ADKALARMOCXCTRL1, 1, CAlarmTestDlg::OnAlarmAdkalarmocxctrl1, VTS_I4 VTS_BSTR VTS_I4 VTS_I4 VTS_BSTR VTS_I4 VTS_I4 VTS_BSTR)
	ON_EVENT(CAlarmTestDlg, IDC_ADKALARMOCXCTRL1, 2, CAlarmTestDlg::OnDeviceStatusAdkalarmocxctrl1, VTS_I4 VTS_BSTR VTS_I4 VTS_I4 VTS_BSTR VTS_I4)
END_EVENTSINK_MAP()


void CAlarmTestDlg::OnAlarmAdkalarmocxctrl1(long nDmsId, LPCTSTR strDevIp, long nDevPort, long nChannel, LPCTSTR strAlarmTime, long nAlarmType, long nAlarmStatus, LPCTSTR strGPSMsg)
{
	 	CString strIp = strDevIp;
	 	CString strTime = strAlarmTime;
	 	CString strDms,strPort,strChannel,strType,strStatus;
	 	strPort.Format(_T("%d"),nDevPort);
	 	strChannel.Format(_T("%d"),nChannel);
	 	switch ( nAlarmType )
	 	{
	 	case 0:
	 		strType = LOAD_CS2(_T("Video Lost"));	
	 		break;
	 	case 1:
	 		strType = LOAD_CS2(_T("Outer Alarm"));	
	 		break;
	 	case 2:
	 		strType = LOAD_CS2(_T("Video Motion"));	
	 		break;
		case 3:
			strType = LOAD_CS2(_T("Video Cover"));	
			break;
		case 4:
			strType = LOAD_CS2(_T("Disk Full"));	
			break;
		case 5:
			strType = LOAD_CS2(_T("Disk Fault"));	
			break;
	/*	case 7:
			strType = LOAD_CS2(_T("GPS Alarm"));	
			break;*/
	 	default:
	 		strType.Format(_T("%d"),nAlarmType); // ��������
	 		break;
	 	}
	 
	 	if ( nAlarmStatus == 1 )
	 	{
	 		strStatus = LOAD_CS2(_T("Occur"));
	 	}
	 	else
	 	{
	 		strStatus = LOAD_CS2(_T("Halt"));
	 	}
	 	strDms.Format(_T("%d"),nDmsId);
	 
	 	int nCount = m_listAlarm.GetItemCount();
	 	m_listAlarm.InsertItem( nCount,strIp);
	 	m_listAlarm.SetItemText(nCount,1,strPort);
		if ( (4 != nAlarmType) && (5 != nAlarmType))
		{
			m_listAlarm.SetItemText(nCount,2,strChannel);
		}
	 	m_listAlarm.SetItemText(nCount,3,strTime);
	 	m_listAlarm.SetItemText(nCount,4,strType);
	 	m_listAlarm.SetItemText(nCount,5,strStatus);
	 	m_listAlarm.SetItemText(nCount,6,strDms);
		//m_listAlarm.SetItemText(nCount,7,strGPSMsg);
}

void CAlarmTestDlg::OnBnClickedButton4()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CString strIp,strPort;

	m_editDdnsIp.GetWindowText(strIp);
	m_editDdnsPort.GetWindowText(strPort);

	if ( strIp.IsEmpty() || strPort.IsEmpty() )
	{
		//MessageBox(_T("��������Ϊ��"));
		MessageBox(LOAD_CS2(_T("The Parameter is Empty")),LOAD_CS2(_T("System Prompt")),MB_OK|MB_ICONWARNING);
		return;
	}

	int nPort = _wtoi(strPort);
	int nRes = m_ocxAlarm.AddDDNSServer(m_nCurDmsId,strIp,nPort,_T(""));

	if (nRes == 0 )
	{
		//MessageBox(_T("����DDNS����ɹ�"));
		MessageBox(LOAD_CS2(_T("Add DDNS Success")),LOAD_CS2(_T("System Prompt")),MB_OK|MB_ICONWARNING);
		GetDlgItem(IDC_BUTTON4)->EnableWindow(FALSE);
	}
	else
	{
		//MessageBox(_T("����DDNS����ʧ��,���飡"));
		MessageBox(LOAD_CS2(_T("Add DDNS Fail")),LOAD_CS2(_T("System Prompt")),MB_OK|MB_ICONWARNING);
	}
}

void CAlarmTestDlg::OnBnClickedBtnGetVersion()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CString strVersion("");

	strVersion = m_ocxAlarm.GetVersion();

	MessageBox(strVersion);

}

void CAlarmTestDlg::OnDeviceStatusAdkalarmocxctrl1(long nDevStatus, LPCTSTR strDevIp, long nDevPort, long nChannel, LPCTSTR strTime, long nParam)
{
	// TODO: �ڴ˴�������Ϣ�����������

	CString strIp = strDevIp;
	CString strTmpTime = strTime;

	CString strPort,strChannel,strStatus;
	strPort.Format(_T("%d"),nDevPort);

	if ( nChannel != -1 )
	{
		strChannel.Format(_T("%d"),nChannel);
	}
	else 
	{
		//һ����� �豸״̬���ϱ�����ָͨ����ͨ����
		strChannel.Format(LOAD_CS2(_T("All")));
	}

	switch ( nDevStatus )
	{
	case 1:
		strStatus = LOAD_CS2(_T("On Line"));
		break;
	case 2:
		strStatus = LOAD_CS2(_T("Off Line"));
		break;
	default:
		strStatus = LOAD_CS2(_T("Unknown"));
		break;
	}


	int nCount = m_listDevStatus.GetItemCount();

	m_listDevStatus.InsertItem( nCount,strIp);
	m_listDevStatus.SetItemText(nCount,1,strPort);
	m_listDevStatus.SetItemText(nCount,2,strChannel);
	m_listDevStatus.SetItemText(nCount,3,strTmpTime);
	m_listDevStatus.SetItemText(nCount,4,strStatus);
	//m_listDevStatus.SetItemText(nCount,5,_T("non"));

}

void CAlarmTestDlg::OnBnClickedButton5()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_listAlarm.DeleteAllItems();
}

void CAlarmTestDlg::OnBnClickedButton6()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_listDevStatus.DeleteAllItems();
}