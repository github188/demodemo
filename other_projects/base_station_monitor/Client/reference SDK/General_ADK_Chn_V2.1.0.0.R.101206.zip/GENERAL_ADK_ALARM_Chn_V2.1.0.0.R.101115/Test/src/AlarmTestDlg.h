// AlarmTestDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include "adkalarmocxctrl1.h"
#include "afxcmn.h"

#include "DemoLanguage.h"

// CAlarmTestDlg �Ի���
class CAlarmTestDlg : public CDialog
{
// ����
public:
	CAlarmTestDlg(CWnd* pParent = NULL);	// ��׼���캯��
	virtual ~CAlarmTestDlg();

// �Ի�������
	enum { IDD = IDD_ALARMTEST_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	long  m_nCurDmsId;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	//CDemoLanguage*		m_pInitLanguage;

	CEdit m_editDmsIp;
	CEdit m_editDmsPort;
	CEdit m_editCameraIp;
	CEdit m_editCameraPort;
	CEdit m_editCameraChannel;
	CEdit m_editUser;
	CEdit m_editPassword;
	CEdit m_editDdnsIp;
	CEdit m_editDdnsPort;
	CButton m_btnLoginDms;
	CComboBox m_comSessionExist;
	CComboBox m_comboAlarmType;
	CListCtrl m_listAlarm;
	CListCtrl m_listDevStatus;
	CAdkalarmocxctrl1 m_ocxAlarm;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedBtnGetVersion();
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton6();
	DECLARE_EVENTSINK_MAP()
	void OnAlarmAdkalarmocxctrl1(long nDmsId, LPCTSTR strDevIp, long nDevPort, long nChannel, LPCTSTR strAlarmTime, long nAlarmType, long nAlarmStatus, LPCTSTR strGPSMsg);
	void OnDeviceStatusAdkalarmocxctrl1(long nDevStatus, LPCTSTR strDevIp, long nDevPort, long nChannel, LPCTSTR strTime, long nParam);
};

//#define LOAD_CS2(x)	m_pInitLanguage->ConvertString(x)
