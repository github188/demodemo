//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AlarmTest.rc
//
#define IDD_ALARMTEST_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_BUTTON1                     1002
#define IDC_BUTTON2                     1003
#define IDC_BUTTON3                     1004
#define IDC_ADKALARMOCXCTRL1            1005
#define IDC_EDIT3                       1006
#define IDC_LIST2                       1007
#define IDC_EDIT4                       1008
#define IDC_EDIT5                       1009
#define IDC_EDIT6                       1010
#define IDC_EDIT7                       1011
#define IDC_COMBO1                      1012
#define IDC_BUTTON4                     1013
#define IDC_BUTTON5                     1014
#define IDC_COMBO2                      1015
#define IDC_EDIT8                       1016
#define IDC_EDIT9                       1017
#define IDC_BTN_GET_VERSION             1018
#define IDC_LIST_DEV_STATUS             1019
#define IDC_BUTTON6                     1020
#define IDC_STATIC_DMS                  1021
#define IDC_STATIC_DMSPORT              1022
#define IDC_STATIC_DEV                  1023
#define IDC_STATIC_                     1024
#define IDC_STATIC_USER                 1024
#define IDC_STATIC_PSW                  1025
#define IDC_STATIC_DEVPORT              1026
#define IDC_STATIC_CHL                  1027
#define IDC_STATIC_TYPE                 1028
#define IDC_STATIC_CANCEL               1029
#define IDC_STATIC_SESSION              1030
#define IDC_STATIC_DDNSPORT             1031
#define IDC_STATIC_VISION               1032
#define IDC_STATIC_ALARM                1033
#define IDC_STATIC_STATUS               1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
