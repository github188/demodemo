#pragma once

// ������������� Microsoft Visual C++ ������ IDispatch ��װ��

// ע��: ��Ҫ�޸Ĵ��ļ������ݡ����������
//  Microsoft Visual C++ �������ɣ������޸Ľ�����д��

/////////////////////////////////////////////////////////////////////////////
// CAdkalarmocxctrl1 ��װ��

class CAdkalarmocxctrl1 : public CWnd
{
protected:
	DECLARE_DYNCREATE(CAdkalarmocxctrl1)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0x42143DCD, 0x1BDA, 0x4E3C, { 0x83, 0x6, 0xA, 0xB6, 0xBD, 0xA2, 0xC8, 0xD7 } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle,
						const RECT& rect, CWnd* pParentWnd, UINT nID, 
						CCreateContext* pContext = NULL)
	{ 
		return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID); 
	}

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, 
				UINT nID, CFile* pPersist = NULL, BOOL bStorage = FALSE,
				BSTR bstrLicKey = NULL)
	{ 
		return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
		pPersist, bStorage, bstrLicKey); 
	}

// ����
public:


// ����
public:

// _DADKAlarmOcx

// Functions
//

	long AddDmsServer(LPCTSTR strDmsIp, long nDmsPort, LPCTSTR strDmsPsw)
	{
		long result;
		static BYTE parms[] = VTS_BSTR VTS_I4 VTS_BSTR ;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_I4, (void*)&result, parms, strDmsIp, nDmsPort, strDmsPsw);
		return result;
	}
	long SubscribeAlarm(long nDmsId, LPCTSTR strDevIp, long nDevPort, LPCTSTR strUser, LPCTSTR strPsw, long nChannel, long nAlarmType)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_BSTR VTS_I4 VTS_BSTR VTS_BSTR VTS_I4 VTS_I4 ;
		InvokeHelper(0x2, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nDmsId, strDevIp, nDevPort, strUser, strPsw, nChannel, nAlarmType);
		return result;
	}
	long CancelSubscribe(long nSessionId)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x3, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSessionId);
		return result;
	}
	long AddDDNSServer(long nDmsId, LPCTSTR strIp, long nPort, LPCTSTR strVersion)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_BSTR VTS_I4 VTS_BSTR ;
		InvokeHelper(0x4, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nDmsId, strIp, nPort, strVersion);
		return result;
	}
	CString GetVersion()
	{
		CString result;
		InvokeHelper(0x5, DISPATCH_METHOD, VT_BSTR, (void*)&result, NULL);
		return result;
	}

// Properties
//



};
