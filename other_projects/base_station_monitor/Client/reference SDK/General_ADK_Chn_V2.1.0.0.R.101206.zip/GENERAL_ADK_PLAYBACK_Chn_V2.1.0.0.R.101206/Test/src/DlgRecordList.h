#pragma once
#include "Resource.h"
#include "afxcmn.h"
#include "afxwin.h"
#include "DemoLanguage.h"

// CDlgRecordList �Ի���

class CDlgRecordList : public CDialog
{
	DECLARE_DYNAMIC(CDlgRecordList)

public:
	CDlgRecordList(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgRecordList();

// �Ի�������
	enum { IDD = IDD_DLG_RECORDLIST };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_listRecordInfo;
	virtual BOOL OnInitDialog();

public:
	void	SetDlgInfo(void* pInfo){ m_pDlgInfo = pInfo;}
	int		InputNewRecordInfo(void* pParse);
	CEdit m_editRecordDevInfo;

	void*	 m_pDlgInfo;
	CString  m_strCameraIp;
	int		 m_nCameraPort;
	int		 m_nCameraChl;
	int		 m_nCameraIndex;
	afx_msg void OnNMDblclkList1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedButtonFileplay();
	afx_msg void OnBnClickedButtonFiledown();
	CEdit m_editDownloadProc;
	CComboBox m_comWinNum;
	CEdit m_editFileDownFileName;
	CEdit m_editFileDownFilePath;

	long	m_nDownloadId;
	afx_msg void OnBnClickedButtonCancel();
};