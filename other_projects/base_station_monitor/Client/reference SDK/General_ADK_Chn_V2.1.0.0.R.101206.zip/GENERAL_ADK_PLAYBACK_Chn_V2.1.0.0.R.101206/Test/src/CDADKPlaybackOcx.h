// CDADKPlaybackOcx.h : �� Microsoft Visual C++ ������ ActiveX �ؼ���װ�������

#pragma once

/////////////////////////////////////////////////////////////////////////////
// CAdkplaybackocxctrl1

class CAdkplaybackocxctrl1 : public CWnd
{
protected:
	DECLARE_DYNCREATE(CAdkplaybackocxctrl1)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0x59CC500F, 0x68B0, 0x484C, { 0xA6, 0xA6, 0xF5, 0x27, 0xD, 0xCE, 0xA0, 0xAE } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle,
						const RECT& rect, CWnd* pParentWnd, UINT nID, 
						CCreateContext* pContext = NULL)
	{ 
		return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID); 
	}

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, 
				UINT nID, CFile* pPersist = NULL, BOOL bStorage = FALSE,
				BSTR bstrLicKey = NULL)
	{ 
		return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
		pPersist, bStorage, bstrLicKey); 
	}

// ����
public:

// ����
public:

	long AddSSServer(LPCTSTR strSsIp, long nSsPort, LPCTSTR strSsPsw)
	{
		long result;
		static BYTE parms[] = VTS_BSTR VTS_I4 VTS_BSTR ;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_I4, (void*)&result, parms, strSsIp, nSsPort, strSsPsw);
		return result;
	}
	long AddMTSServer(LPCTSTR strMtsIp, long nMtsPort, LPCTSTR strMtsPsw)
	{
		long result;
		static BYTE parms[] = VTS_BSTR VTS_I4 VTS_BSTR ;
		InvokeHelper(0x2, DISPATCH_METHOD, VT_I4, (void*)&result, parms, strMtsIp, nMtsPort, strMtsPsw);
		return result;
	}
	long AddCamera(LPCTSTR strIp, long nPort, LPCTSTR strUserName, LPCTSTR strPsw, long nChannel)
	{
		long result;
		static BYTE parms[] = VTS_BSTR VTS_I4 VTS_BSTR VTS_BSTR VTS_I4 ;
		InvokeHelper(0x3, DISPATCH_METHOD, VT_I4, (void*)&result, parms, strIp, nPort, strUserName, strPsw, nChannel);
		return result;
	}
	long StartRecord(long nSsId, long nMtsId, long nCameraId, long nPlanId)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0x4, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nMtsId, nCameraId, nPlanId);
		return result;
	}
	long StopRecord(long nSsId, long nCameraId, long nPlanId)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0x5, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nCameraId, nPlanId);
		return result;
	}
	long AddRecordTask(long nSsId, long nMtsId, long nCameraId, LPCTSTR strTmBegin, LPCTSTR strTmEnd, long nPlanId)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_I4 VTS_BSTR VTS_BSTR VTS_I4 ;
		InvokeHelper(0x6, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nMtsId, nCameraId, strTmBegin, strTmEnd, nPlanId);
		return result;
	}
	long RemoveRecordTask(long nSsId, long nMtsId, long nPlanId)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0x7, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nMtsId, nPlanId);
		return result;
	}
	CString QueryRecords(long nSsId, long nCameraId, long nSourceType, long nRecordType, LPCTSTR strTmBegin, LPCTSTR strTmEnd, long nLimited)
	{
		CString result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_BSTR VTS_BSTR VTS_I4 ;
		InvokeHelper(0x8, DISPATCH_METHOD, VT_BSTR, (void*)&result, parms, nSsId, nCameraId, nSourceType, nRecordType, strTmBegin, strTmEnd, nLimited);
		return result;
	}
	long PlaybackByFile(long nSsId, long nSourceType, LPCTSTR strName, long nFileHandle, LPCTSTR strDiskId, long nLength, long nCameraId, long nWinIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_BSTR VTS_I4 VTS_BSTR VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0x9, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nSourceType, strName, nFileHandle, strDiskId, nLength, nCameraId, nWinIndex);
		return result;
	}
	long DownloadByFile(long nSsId, long nSourceType, LPCTSTR strName, long nFileHandle, LPCTSTR strDiskId, long nLength, long nCameraId, LPCTSTR strFileName, LPCTSTR strPathEx)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_BSTR VTS_I4 VTS_BSTR VTS_I4 VTS_I4 VTS_BSTR VTS_BSTR ;
		InvokeHelper(0xa, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nSourceType, strName, nFileHandle, strDiskId, nLength, nCameraId, strFileName, strPathEx);
		return result;
	}
	long PlaybackByTime(long nSsId, long nSourceType, LPCTSTR strTmBegin, LPCTSTR strTmEnd, long nCameraId, long nWinIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_BSTR VTS_BSTR VTS_I4 VTS_I4 ;
		InvokeHelper(0xb, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nSourceType, strTmBegin, strTmEnd, nCameraId, nWinIndex);
		return result;
	}
	long DownloadByTime(long nSsId, long nSourceType, LPCTSTR strTmBegin, LPCTSTR strTmEnd, long nCameraId, LPCTSTR strFileName, LPCTSTR strPathEx)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_BSTR VTS_BSTR VTS_I4 VTS_BSTR VTS_BSTR ;
		InvokeHelper(0xc, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nSourceType, strTmBegin, strTmEnd, nCameraId, strFileName, strPathEx);
		return result;
	}
	long ClientSnap(long nSsId, long nCameraId, long nCount, long nInterval)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0xd, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nCameraId, nCount, nInterval);
		return result;
	}
	long SsSnap(long nSsId, long nCameraId, long nCount, long nInterval)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0xe, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nCameraId, nCount, nInterval);
		return result;
	}
	long ClientSnapTask(long nSsId, long nCameraId, LPCTSTR strTmBegin, LPCTSTR strTmEnd, long nInterval)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_BSTR VTS_BSTR VTS_I4 ;
		InvokeHelper(0xf, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nCameraId, strTmBegin, strTmEnd, nInterval);
		return result;
	}
	long SsSnapTask(long nSsId, long nCameraId, LPCTSTR strTmBegin, LPCTSTR strTmEnd, long nInterval)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_BSTR VTS_BSTR VTS_I4 ;
		InvokeHelper(0x10, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nCameraId, strTmBegin, strTmEnd, nInterval);
		return result;
	}
	long AddDDNSServer(long nSsId, long nMtsId, LPCTSTR strIp, long nPort, LPCTSTR strVersion)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_BSTR VTS_I4 VTS_BSTR ;
		InvokeHelper(0x11, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nMtsId, strIp, nPort, strVersion);
		return result;
	}
	long SetPath(long nSsId, long nType, LPCTSTR strPath)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_BSTR ;
		InvokeHelper(0x12, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, nType, strPath);
		return result;
	}
	long HidePanel(long bHide)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x13, DISPATCH_METHOD, VT_I4, (void*)&result, parms, bHide);
		return result;
	}
	long PlaybackByFileEx(long nSsId, LPCTSTR strXmlItem, long nCameraId, long nWinIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_BSTR VTS_I4 VTS_I4 ;
		InvokeHelper(0x14, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, strXmlItem, nCameraId, nWinIndex);
		return result;
	}
	long DownloadByFileEx(long nSsId, LPCTSTR strXmlItem, long nCameraId, LPCTSTR strFileName, LPCTSTR strPathEx)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_BSTR VTS_I4 VTS_BSTR VTS_BSTR ;
		InvokeHelper(0x15, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nSsId, strXmlItem, nCameraId, strFileName, strPathEx);
		return result;
	}
	CString GetVersion()
	{
		CString result;
		InvokeHelper(0x16, DISPATCH_METHOD, VT_BSTR, (void*)&result, NULL);
		return result;
	}
	long PlayLocalFile(LPCTSTR strFile, long nWinIndex)
	{
		long result;
		static BYTE parms[] = VTS_BSTR VTS_I4 ;
		InvokeHelper(0x17, DISPATCH_METHOD, VT_I4, (void*)&result, parms, strFile, nWinIndex);
		return result;
	}
	long SetVideoWndNum(long nWndNum)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x18, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndNum);
		return result;
	}
	long GetSelWndIdx()
	{
		long result;
		InvokeHelper(0x19, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
		return result;
	}
	long HidePlaybackBar(long bHide)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x1a, DISPATCH_METHOD, VT_I4, (void*)&result, parms, bHide);
		return result;
	}
	long Fast(long nWndIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x1b, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndIndex);
		return result;
	}
	long Slow(long nWndIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x1c, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndIndex);
		return result;
	}
	long Head(long nWndIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x1d, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndIndex);
		return result;
	}
	long Tail(long nWndIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x1e, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndIndex);
		return result;
	}
	long Start(long nWndIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x1f, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndIndex);
		return result;
	}
	long Stop(long nWndIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x20, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndIndex);
		return result;
	}
	long Pause(long nWndIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x21, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndIndex);
		return result;
	}
	long Resume(long nWndIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x22, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndIndex);
		return result;
	}
	long PlaySound(long nWndIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x23, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndIndex);
		return result;
	}
	long StopSound(long nWndIndex)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x24, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nWndIndex);
		return result;
	}
	long StopDownload(long nDownloadId)
	{
		long result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x25, DISPATCH_METHOD, VT_I4, (void*)&result, parms, nDownloadId);
		return result;
	}


};
