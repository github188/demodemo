// ADKPlaybackTestDlg.h : ͷ�ļ�
//

#pragma once
#include "CDADKPlaybackOcx.h"
#include "afxwin.h"
#include <map>
#include "afxdtctl.h"
#include "XmlRecordInfoParser.h"
#include "DlgRecordList.h"
#include "DlgOther.h"
#include "DemoLanguage.h"

typedef struct
{
	CString strIp;
	int		nPort;
	int		nChannel;
	CString strUser;
	CString strPsw;

}CLIENT_CAMERA_INFO;	// �ͻ� �Խ�����ͷ��Ϣ�洢 

typedef std::map<int,CLIENT_CAMERA_INFO> MAP_CLIENTCAMERA_INFO;


//on error֪ͨ����
typedef enum
{
	FILE_PLAYBACK_START_FAILED =1,
	FILE_DOWNLOAD_START_FAILED,
	TIME_PLAYBACK_START_FAILED,
	TIME_DOWNLOAD_START_FAILED,

	FILE_PLAYBACK_DATA_ERROR,
	FILE_DOWNLOAD_DATA_ERROR,
	TIME_PLAYBACK_DATA_ERROR,
	TIME_DOWNLOAD_DATA_ERROR,

}ON_ERROR_CODE;



//������
#define PB_ERROR_BEGIN					-201

#define PB_ERROR_CTRLDATA_NULL			-202		
#define PB_ERROR_STRING_EMPTY			-203		//�ַ�Ϊ��
#define PB_ERROR_RESPONSE_TIMEOUT		-204		//Ӧ��ʱ
#define PB_ERROR_RESPONSE_FAILED		-205		//Ӧ��ʧ��
#define PB_ERROR_RESPONSE_LOST			-206		//Ӧ��ʧ
#define PB_ERROR_REGOCX_FAILED			-207		//���ڿؼ�ע��ʧ��
#define PB_ERROR_INVALID_SYSPOINTER		-208		//�ڲ�ָ��Ϊ��
#define PB_ERROR_INVALID_PLANID			-209		//��Ч��¼��ƻ�ID
#define PB_ERROR_INVALID_CAMERAINDEX	-210		//��Ч������ͷ����
#define PB_ERROR_INVALID_TIMESTR		-211		//��Ч��ʱ���ַ���
#define PB_ERROR_INVALID_SSID			-212		//��ЧSS ID
#define PB_ERROR_INVALID_MTSID			-213		//��ЧMTS ID
#define PB_ERROR_INVALID_TYPE			-214		//һ��Ϊswitchʱ��鲻������
#define PB_ERROR_WITHOUT_PATH			-215		//·��Ϊ��
#define PB_ERROR_INVALID_BOOL			-216		//��Ч����ֵ ��0��1
#define PB_ERROR_INVALID_WNDHANDLE		-217		//�Ի�������Ч iswindow ��
#define PB_ERROR_INVALID_SOURCE			-218		//Դ���ʹ���
#define PB_ERROR_INVALID_WND			-219		//��Ч�Ĵ��ں�
#define PB_ERROR_INVALID_XMLFILESTR		-220		//�ļ�XML�ַ�������ʧ��
#define PB_ERROR_DOWNLOAD_EXISTED		-221		//��ǰ����¼����������
#define PB_ERROR_PLANID_NOTFOUND		-222		//¼��ƻ�IDû��û���ҵ�,һ�������ɾ��¼��ƻ���ʱ��
#define PB_ERROR_PLANID_EXISTED			-223		//¼��ƻ�ID�Ѿ����ڣ�һ����������Ӽƻ���ʱ��
#define PB_ERROR_PLAN_ISRUNNING			-224		//����ָ���ļ�ʱ��·������¼��

#define PB_ERROR_END					-300



typedef enum
{
	DownloadFailed = 0,		//����ʧ��
	Downloading,			//���ؽ�����
	DownloadSuccess			//���سɹ�

}DownloadStatusEnum;


// CADKPlaybackTestDlg �Ի���
class CADKPlaybackTestDlg : public CDialog
{
// ����
public:
	CADKPlaybackTestDlg(CWnd* pParent = NULL);	// ��׼���캯��
	virtual ~CADKPlaybackTestDlg();

// �Ի�������
	enum { IDD = IDD_ADKPLAYBACKTEST_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
// 	CAdkplaybackocxctrl1 m_ocxPlayback;
	CDlgRecordList		m_dlgRecordList;
	CDlgOther			m_dlgOther;
	CEdit m_editSSIp;
	CEdit m_editSSPort;

	CEdit m_editMTSIp;
	CEdit m_editMTSPort;

	CEdit m_editCameraIp;
	CEdit m_editCameraPort;
	CEdit m_editCameraUser;
	CEdit m_editCameraPsw;
	CEdit m_editCameraChl;

	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButtonAddcamera();

	CComboBox m_comboxCameraExisted;
	CComboBox m_comboxSsExisted;
	CComboBox m_comboxMtsExisted;


	CDateTimeCtrl m_dateBegin;
	CDateTimeCtrl m_timeBegin;
	CDateTimeCtrl m_dateEnd;
	CDateTimeCtrl m_timeEnd;
	CEdit m_editQuerySSId;
	CComboBox m_comQueryRecordType;
	CEdit m_editQueryCameraId;
	CComboBox m_comQuerySource;
	int			m_nMaxItem;		//����ѯ��


	afx_msg void OnBnClickedButtonQuery();
	afx_msg void OnBnClickedButtonShowlist();


	XMLRecordInfoParser m_recordXMLParse;
	BOOL				m_bNeedFlash;		//ָ�б��Ƿ���Ҫ��������

	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);

	CDateTimeCtrl m_dateTimePlayBegin;
	CDateTimeCtrl m_timeTimePlayBegin;
	CDateTimeCtrl m_dateTimePlayEnd;
	CDateTimeCtrl m_timeTimePlayEnd;
	afx_msg void OnBnClickedButtonPlaytime();
	afx_msg void OnBnClickedButtonTimedown();
	CComboBox m_comTimePlayWin;
	CComboBox m_comTimePlaySource;
	CEdit m_editTimePlayCamera;
	CEdit m_editTimePlaySsId;


	CEdit m_editRecordCamera;
	CEdit m_editRecordSsId;
	CEdit m_editRecordMtsId;
	CEdit m_editPlanId;
	afx_msg void OnBnClickedButtonRecord();
	afx_msg void OnBnClickedButtonStoprecord();



	CDateTimeCtrl m_dataRecordBegin;
	CDateTimeCtrl m_timeRecordBegin;
	CDateTimeCtrl m_dataRecordEnd;
	CDateTimeCtrl m_timeRecordEnd;
	CEdit m_editRecPlanSsId;
	CEdit m_editRecPlanMtsId;
	CEdit m_editRecPlanCameraId;
	CEdit m_editRecPlanPlanId;
	afx_msg void OnBnClickedButtonAddRecordplan();
	afx_msg void OnBnClickedButtonRemoveRecordPlan();

	void OnDownloadProgressAdkplaybackocxctrl1(long bValid, long nSessionId, long nCurLen, long nFileLen);


	DECLARE_EVENTSINK_MAP()

	afx_msg void OnBnClickedButtonHide();
	afx_msg void OnBnClickedButtonHide2();

	void OnErrorAdkplaybackocxctrl1(long nError, LPCTSTR strTime, long nSessionId, long nParam);

public:
	int ConverErrorCode( int nErrorCode );

	CEdit m_editTimeDownFileName;
	CEdit m_editTimeDownFilePath;
	CEdit m_editTimeDownStatus;
	afx_msg void OnBnClickedBtnLocalfile();
	CAdkplaybackocxctrl1 m_ocxPlayback;
	void OnPlayEndAdkplaybackocxctrl1(long nSessionId);
	afx_msg void OnBnClickedButtonPlay();
	afx_msg void OnBnClickedButtonStop();
	afx_msg void OnBnClickedButtonPause();
	afx_msg void OnBnClickedButtonResume();
	afx_msg void OnBnClickedButtonFast();
	afx_msg void OnBnClickedButtonSlow();
	afx_msg void OnBnClickedButtonHead();
	afx_msg void OnBnClickedButtonTail();
	afx_msg void OnBnClickedButtonHideplaybar();
	afx_msg void OnBnClickedButtonOpensound();
	afx_msg void OnBnClickedButtonClosesound();
	void OnDownloadEndAdkplaybackocxctrl1(long nSessionId);
	afx_msg void OnBnClickedButtonDownloadcancel();

	long m_nDownloadId;
	afx_msg void OnCbnSelchangeComboWndnum();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};