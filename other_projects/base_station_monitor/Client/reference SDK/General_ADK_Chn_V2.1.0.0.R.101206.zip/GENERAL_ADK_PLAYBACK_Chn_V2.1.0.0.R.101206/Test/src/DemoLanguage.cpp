// DemoLanguage.cpp: implementation of the CDemoLanguage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DemoLanguage.h"

#pragma warning(disable : 4996)

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// Ψһ����.
CDemoLanguage* CDemoLanguage::s_pLanguage = NULL ;

CDemoLanguage::CDemoLanguage()
{
	m_pCurLanguage = NULL;	
	m_strLanguage = _T("Language"); //Ĭ��ֵ
}

CDemoLanguage::~CDemoLanguage()
{
	Destroy();

}

CDemoLanguage* CDemoLanguage::Instance()
{
	if( s_pLanguage == NULL )
	{
		s_pLanguage = new CDemoLanguage;
	}
	ASSERT( s_pLanguage != NULL );

	return s_pLanguage;
}

void CDemoLanguage::UnInstace()
{
	if( s_pLanguage )
	{
		delete s_pLanguage;
		s_pLanguage = NULL;
	}
}

void CDemoLanguage::AddLanguage(CString strIniFile)
{
	ASSERT(strIniFile.GetLength()>0);
	//���ļ���ת�������·��
	strIniFile.Format(_T("Language_demo\\%s"),strIniFile);

	TCHAR val[64];
	CString strIniPath,strLang,strAuthor;

	strIniPath.Format(_T("%s%s"),m_strCurDir,strIniFile);
	//��������
	GetPrivateProfileString(_T("Info"),_T("Language"),_T(""),
		val,sizeof(val),strIniPath);
	strLang=val;
	//���Է�������
	GetPrivateProfileString(_T("Info"),_T("Author"),_T(""),
		val,sizeof(val),strIniPath);
	strAuthor=val;

	//�Ѵ������Լ��뵽���Զ���������
	if(strLang.GetLength()>0)
	{
		LANGUAGE_TYPE * pLang=new LANGUAGE_TYPE;
		memset(pLang,0,sizeof(LANGUAGE_TYPE));
		_tcscpy(pLang->LangName,strLang);
		_tcscpy(pLang->AuthorName,strAuthor);
		_tcscpy(pLang->IniFile,strIniFile);

		m_LanguageList.Add(pLang);
	}
}



BOOL CDemoLanguage::SetCurInterfaceSolution( Enum_Language_Version nLangType )
{
	switch( nLangType )
	{
	case LANGUAGE_CHINESE_VERSION:
		m_strLanguage = _T("Chinese"); 
		break;

	case LANGUAGE_ENGLISH_VERSION:
		m_strLanguage = _T("English");
		break;

	default:
		return FALSE;
	}

	m_pCurLanguage  = NULL;
	int nSize = m_LanguageList.GetSize();
	for( int i = 0 ; i < nSize ;i++ )
	{
		LANGUAGE_TYPE * pLanguage= m_LanguageList.GetAt( i );

		if ( pLanguage->LangName == m_strLanguage )
		{
			m_pCurLanguage = pLanguage;
			break;
		}
	}

	return TRUE;
}

//�˺���������ʼ��������������
void CDemoLanguage::InitLanguageList()
{
	////��¼��ǰ·��
	TCHAR curdir[MAX_PATH];
	::GetCurrentDirectory( MAX_PATH ,curdir );

	//���� ini �ļ������������Ͷ���ӵ�������
	CString strDir = m_strCurDir + _T("Language_demo");
	::SetCurrentDirectory( strDir );
	CFileFind finder;
	if( finder.FindFile( _T("*.ini") ) )
	{
		BOOL bIsLast;
		do
		{
			bIsLast = !finder.FindNextFile();
			CString strFile = finder.GetFileName();
			AddLanguage( strFile ); 
		}while( !bIsLast );

		finder.Close();
	}

	//�ָ���ǰ·��
	::SetCurrentDirectory( curdir );
}


BOOL CDemoLanguage::Init(CString strCurdir)
{
	m_strCurDir = strCurdir;

	InitLanguageList();         	//��ʼ��������������

	return TRUE;
}

//�����ڴ�
void CDemoLanguage::Destroy()
{
	//�ͷ��ڴ�
	int nSize = m_LanguageList.GetSize();
	int i=0;
	for( i=0 ; i < nSize ; i++ )
	{
		LANGUAGE_TYPE * pLang = m_LanguageList.GetAt( i );
		if( pLang ) 
		{
			delete pLang;
			pLang = NULL;
		}
	}

}


CString CDemoLanguage::ConvertString(CString strText)
{
	TCHAR val[300];
	CString strIniPath,strRet;
	CString strLang;
	if (m_pCurLanguage)
	{
		strIniPath.Format(_T("%s%s"),m_strCurDir,m_pCurLanguage->IniFile);
	}
	memset(val,0,sizeof(val));
	GetPrivateProfileString(_T("String"),strText,_T(""),
		val,sizeof(val),strIniPath);
	strRet=val;
	if(strRet.GetLength()==0)
	{
		//���ini�ļ��в����ڶ�Ӧ���ַ���������ΪĬ��ֵ��Ӣ�ģ�
		strRet=strText;
	}

	return strRet;
}

void CDemoLanguage::SetWndStaticText(CWnd * pWnd)
{
	CString strCaption,strText;

	//���������ڵı���
	pWnd->GetWindowText(strCaption);
	if(strCaption.GetLength()>0)
	{
		strText=ConvertString(strCaption);
		pWnd->SetWindowText(strText);
	}

	//�����Ӵ��ڵı���
	CWnd * pChild=pWnd->GetWindow(GW_CHILD);
	CString strClassName;
	while(pChild)
	{
		//////////////////////////////////////////////////////////////////////////		
		//Added by Jackbin 2005-03-11
		strClassName = ((CRuntimeClass*)pChild->GetRuntimeClass())->m_lpszClassName;
		if(strClassName == "CEdit")
		{
			//��һ���Ӵ���
			pChild=pChild->GetWindow(GW_HWNDNEXT);
			continue;
		}

		//////////////////////////////////////////////////////////////////////////

		//�����Ӵ��ڵĵ�ǰ�����ı�
		pChild->GetWindowText(strCaption);
		strText=ConvertString(strCaption);
		pChild->SetWindowText(strText);

		//��һ���Ӵ���
		pChild=pChild->GetWindow(GW_HWNDNEXT);
	}
}