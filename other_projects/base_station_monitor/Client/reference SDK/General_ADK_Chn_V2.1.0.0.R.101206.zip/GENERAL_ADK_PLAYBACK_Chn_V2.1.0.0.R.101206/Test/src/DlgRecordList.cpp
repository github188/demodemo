// DlgRecordList.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ADKPlaybackTest.h"
#include "DlgRecordList.h"
#include "ADKPlaybackTestDlg.h"


// CDlgRecordList �Ի���

IMPLEMENT_DYNAMIC(CDlgRecordList, CDialog)

CDlgRecordList::CDlgRecordList(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgRecordList::IDD, pParent)
{
	m_strCameraIp = "";
	m_nCameraPort = 0;
	m_nCameraChl = -1;
	m_nCameraIndex =0;
	m_pDlgInfo = NULL;

	m_nDownloadId  = -1;
}

CDlgRecordList::~CDlgRecordList()
{
	CDemoLanguage::UnInstace();
}

void CDlgRecordList::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_listRecordInfo);
	DDX_Control(pDX, IDC_EDIT1, m_editRecordDevInfo);
	DDX_Control(pDX, IDC_EDIT2, m_editDownloadProc);
	DDX_Control(pDX, IDC_COMBO1, m_comWinNum);
	DDX_Control(pDX, IDC_EDIT35, m_editFileDownFileName);
	DDX_Control(pDX, IDC_EDIT36, m_editFileDownFilePath);
}


BEGIN_MESSAGE_MAP(CDlgRecordList, CDialog)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, &CDlgRecordList::OnNMDblclkList1)
	ON_BN_CLICKED(IDC_BUTTON_FILEPLAY, &CDlgRecordList::OnBnClickedButtonFileplay)
	ON_BN_CLICKED(IDC_BUTTON_FILEDOWN, &CDlgRecordList::OnBnClickedButtonFiledown)
	ON_BN_CLICKED(IDC_BUTTON_CANCEL, &CDlgRecordList::OnBnClickedButtonCancel)
END_MESSAGE_MAP()


// CDlgRecordList ��Ϣ��������

BOOL CDlgRecordList::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	//���������ļ�·��
	TCHAR   cFileName[512] = {0};
	GetModuleFileName(AfxGetInstanceHandle(), cFileName, 512);
	TCHAR acBuf[512];
	GetLongPathName(cFileName,acBuf,512); //ȫ·��
	CString strPre = acBuf;
	CString strPath = strPre.Left(strPre.ReverseFind(_T('\\'))+1);
	if ( strPath.Right(1) != _T("\\"))
	{
		strPath += _T("\\");
	}

	//�����ļ��ĳ�ʼ��
	if ( !strPath.IsEmpty() )
	{
// 		CDemoLanguage::Instance()->Init( strPath );
// 		CDemoLanguage::Instance()->SetCurLanguageSolution( LANGUAGE_ENGLISH_VERSION );
// 		//���öԻ����еľ�̬�ı�(Ӣ��-->��ǰ����)
		_CWndCS( this );
	}

	
	m_listRecordInfo.SetExtendedStyle( LVS_EX_FLATSB|LVS_EX_FULLROWSELECT|LVS_EX_HEADERDRAGDROP|LVS_EX_ONECLICKACTIVATE|LVS_EX_GRIDLINES);
	m_listRecordInfo.InsertColumn(0,"ID",LVCFMT_CENTER,30,0);
	m_listRecordInfo.InsertColumn(1,"Name",LVCFMT_CENTER,50,1);
	m_listRecordInfo.InsertColumn(2,"Begin",LVCFMT_CENTER,105,2);
	m_listRecordInfo.InsertColumn(3,"End",LVCFMT_CENTER,105,3);
	m_listRecordInfo.InsertColumn(4,"Source",LVCFMT_CENTER,60,4);
	m_listRecordInfo.InsertColumn(5,"Record",LVCFMT_CENTER,60,5);
	m_listRecordInfo.InsertColumn(6,"Len",LVCFMT_CENTER,40,6);
	m_listRecordInfo.InsertColumn(7,"Plan",LVCFMT_CENTER,40,7);
	m_listRecordInfo.InsertColumn(8,"Ss",LVCFMT_CENTER,40,8);
	m_listRecordInfo.InsertColumn(9,"Disk",LVCFMT_CENTER,55,9);
	m_listRecordInfo.InsertColumn(10,"File",LVCFMT_CENTER,58,10);

	m_comWinNum.AddString("0");
	m_comWinNum.AddString("1");
	m_comWinNum.AddString("2");
	m_comWinNum.AddString("3");

	m_comWinNum.SetCurSel(0);

	m_editDownloadProc.SetReadOnly(TRUE);


	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

int	CDlgRecordList::InputNewRecordInfo(void* pParse)
{
	if ( pParse == NULL )
	{
		return -1;
	}
	m_listRecordInfo.DeleteAllItems();

	XMLRecordInfoParser* kParser = (XMLRecordInfoParser*)pParse;

	CString strCameraInfo;
	m_strCameraIp = kParser->getDevIp();
	m_nCameraPort = kParser->getDevPort();
	m_nCameraChl = kParser->getCameraChannel();
	m_nCameraIndex = kParser->getCameraIndex();

	strCameraInfo.Format("IP=%s,Port=%d,Channel=%d,Index=%d",m_strCameraIp,m_nCameraPort,m_nCameraChl,m_nCameraIndex);
	m_editRecordDevInfo.SetWindowText(strCameraInfo);

	CString strId;
	CString strSource;
	CString strRecord;
	CString strLen;
	CString strPlan;
	CString strSSId;
	CString strHandle;

	XMLRecordItem* recordItem = kParser->firstRecordItem();
	int ItemCount = 0;
	while(recordItem != NULL )
	{
		strId.Format("%d",recordItem->_id);
		m_listRecordInfo.InsertItem(ItemCount,strId);

		m_listRecordInfo.SetItemText(ItemCount,1,recordItem->_name);
		m_listRecordInfo.SetItemText(ItemCount,2,recordItem->_beginTime);
		m_listRecordInfo.SetItemText(ItemCount,3,recordItem->_endTime);


		if ( recordItem->_resourceType == 2 )
		{
			strSource = _T(_CS("Device source"));
		}
		else
		{
			strSource = _T(_CS("Center source"));
		}
		m_listRecordInfo.SetItemText(ItemCount,4,strSource);


		switch(recordItem->_recordType )
		{
		case 2:
			strRecord = _T(_CS("Alarm record"));
			break;

		case 3:
			strRecord = _T(_CS("Motion record"));
			break;

		case 4:
			strRecord = _T(_CS("VideoLose record"));
			break;

		case 5:
			strRecord = _T(_CS("VideoCove record"));
			break;

		default:
			strRecord = _T(_CS("Normal record"));
			break;
		}
		m_listRecordInfo.SetItemText(ItemCount,5,strRecord);


		strLen.Format("%d",recordItem->_recordLen);
		m_listRecordInfo.SetItemText(ItemCount,6,strLen);

		strPlan.Format("%d",recordItem->_planId);
		m_listRecordInfo.SetItemText(ItemCount,7,strPlan);

		strSSId.Format("%d",recordItem->_ssId);
		m_listRecordInfo.SetItemText(ItemCount,8,strSSId);

		m_listRecordInfo.SetItemText(ItemCount,9,recordItem->_diskId);

		strHandle.Format("%d",recordItem->_fileHandle);
		m_listRecordInfo.SetItemText(ItemCount,10,strHandle);

		ItemCount++;
		recordItem = kParser->nextRecordItem();
	}

	return 0;
}
void CDlgRecordList::OnNMDblclkList1(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;

	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;
	if ( pDlg == NULL )
	{
		return;
	}

	int nSel = m_listRecordInfo.GetSelectionMark();
	if ( nSel == -1 )
	{
		return;
	}

	CString strSs = m_listRecordInfo.GetItemText(nSel,8);
	CString strName =m_listRecordInfo.GetItemText(nSel,1);
	CString strHandle =m_listRecordInfo.GetItemText(nSel,10);
	CString strDisk =m_listRecordInfo.GetItemText(nSel,9);
	CString strLen =m_listRecordInfo.GetItemText(nSel,6);

	int nSource = 2;
	CString strSource = m_listRecordInfo.GetItemText(nSel,4);
	if ( strSource == _T(_CS("Center source")))
	{
		nSource = 3;
	}
	else if ( strSource == _T(_CS("Device source")))
	{
		nSource = 2;
	}

	int nSsId = atoi(strSs);
	int nHandle = atoi(strHandle);
	int nLen = atoi(strLen);

	CString strWinNum;
	m_comWinNum.GetWindowText(strWinNum);
	int nWinNum = atoi(strWinNum);


	int nRes = pDlg->m_ocxPlayback.PlaybackByFile(nSsId,nSource,strName,nHandle,strDisk,nLen,m_nCameraIndex,nWinNum);

	if ( nRes < 0 )
	{
		pDlg->ConverErrorCode(nRes);
	}

	return;
}

void CDlgRecordList::OnBnClickedButtonFileplay()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;
	if ( pDlg == NULL )
	{
		return;
	}

	int nSel = m_listRecordInfo.GetSelectionMark();
	if ( nSel == -1 )
	{
		return;
	}

	CString strSs = m_listRecordInfo.GetItemText(nSel,8);
	CString strName =m_listRecordInfo.GetItemText(nSel,1);
	CString strHandle =m_listRecordInfo.GetItemText(nSel,10);
	CString strDisk =m_listRecordInfo.GetItemText(nSel,9);
	CString strLen =m_listRecordInfo.GetItemText(nSel,6);

	CString strWinNum;
	m_comWinNum.GetWindowText(strWinNum);
	int nWinNum = atoi(strWinNum);

	int nSource = 2;
	CString strSource = m_listRecordInfo.GetItemText(nSel,4);
	if ( strSource == _T(_CS("Center source")))
	{
		nSource = 3;
	}
	else if ( strSource == _T(_CS("Device source")))
	{
		nSource = 2;
	}

	int nSsId = atoi(strSs);
	int nHandle = atoi(strHandle);
	int nLen = atoi(strLen);

	int nRes = pDlg->m_ocxPlayback.PlaybackByFile(nSsId,nSource,strName,nHandle,strDisk,nLen,m_nCameraIndex,nWinNum);
	if ( nRes < 0 )
	{
		pDlg->ConverErrorCode(nRes);
	}

}


void CDlgRecordList::OnBnClickedButtonFiledown()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;
	if ( pDlg == NULL )
	{
		return;
	}

	int nSel = m_listRecordInfo.GetSelectionMark();
	if ( nSel == -1 )
	{
		return;
	}

	CString strSs = m_listRecordInfo.GetItemText(nSel,8);
	CString strName =m_listRecordInfo.GetItemText(nSel,1);
	CString strHandle =m_listRecordInfo.GetItemText(nSel,10);
	CString strDisk =m_listRecordInfo.GetItemText(nSel,9);
	CString strLen =m_listRecordInfo.GetItemText(nSel,6);

	int nSsId = atoi(strSs);
	int nHandle = atoi(strHandle);
	int nLen = atoi(strLen);

	int nSource = 2;
	CString strSource = m_listRecordInfo.GetItemText(nSel,4);
	if ( strSource == _T(_CS("Center source")))
	{
		nSource = 3;
	}
	else if ( strSource == _T(_CS("Device source")))
	{
		nSource = 2;
	}

	CString strFileName("");
	CString strFilePath("");
	m_editFileDownFileName.GetWindowText(strFileName);
	m_editFileDownFilePath.GetWindowText(strFilePath);
	if ( strFileName.IsEmpty() )
	{
		MessageBox(_CS("Please fill in the file name that you want to save as"));
		return;
	}

	int nRes = pDlg->m_ocxPlayback.DownloadByFile(nSsId,nSource,strName,nHandle,strDisk,nLen,m_nCameraIndex,strFileName,strFilePath);

	if ( nRes < 0 )
	{
		m_editDownloadProc.SetWindowText("");
		pDlg->ConverErrorCode(nRes);
	}
	else
	{
		m_nDownloadId = nRes;

		CString strTmp("");
		if ( nSource == 2 )
		{
			strTmp.Format(_T(_CS("Sending the download command.During the downloading time, you couldn't open video of the device record")));
		}
		if ( nSource == 3 )
		{
			strTmp.Format(_T(_CS("Sending the download command")));
		}

		m_editDownloadProc.SetWindowText(_CS("Downloading the FileRecord file"));
		MessageBox(strTmp);
	}


}

void CDlgRecordList::OnBnClickedButtonCancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_nDownloadId > 0)
	{
		CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;
		long nRet = pDlg->m_ocxPlayback.StopDownload(m_nDownloadId);
		if (nRet < 0)
		{
			pDlg->ConverErrorCode(nRet);	
			return;
		}

		m_editDownloadProc.SetWindowText("");
		m_nDownloadId = -1;
	}
}
