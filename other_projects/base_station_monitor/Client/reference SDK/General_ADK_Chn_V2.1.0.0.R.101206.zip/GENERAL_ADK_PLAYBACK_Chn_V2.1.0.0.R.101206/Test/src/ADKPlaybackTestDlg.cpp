// ADKPlaybackTestDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ADKPlaybackTest.h"
#include "ADKPlaybackTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CADKPlaybackTestDlg �Ի���




CADKPlaybackTestDlg::CADKPlaybackTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CADKPlaybackTestDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bNeedFlash = FALSE;
	m_nMaxItem = 100;

	m_nDownloadId = -1;
}

CADKPlaybackTestDlg::~CADKPlaybackTestDlg()
{
	CDemoLanguage::UnInstace();
}

void CADKPlaybackTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_ADKPLAYBACKOCXCTRL1, m_ocxPlayback);
	DDX_Control(pDX, IDC_EDIT1, m_editSSIp);
	DDX_Control(pDX, IDC_EDIT2, m_editSSPort);
	DDX_Control(pDX, IDC_EDIT3, m_editMTSIp);
	DDX_Control(pDX, IDC_EDIT4, m_editMTSPort);
	DDX_Control(pDX, IDC_EDIT5, m_editCameraIp);
	DDX_Control(pDX, IDC_EDIT6, m_editCameraPort);
	DDX_Control(pDX, IDC_EDIT7, m_editCameraUser);
	DDX_Control(pDX, IDC_EDIT8, m_editCameraPsw);
	DDX_Control(pDX, IDC_EDIT9, m_editCameraChl);
	DDX_Control(pDX, IDC_COMBO1, m_comboxCameraExisted);
	DDX_Control(pDX, IDC_COMBO2, m_comboxSsExisted);
	DDX_Control(pDX, IDC_COMBO3, m_comboxMtsExisted);
	DDX_Control(pDX, IDC_DATETIMEPICKER1, m_dateBegin);
	DDX_Control(pDX, IDC_DATETIMEPICKER2, m_timeBegin);
	DDX_Control(pDX, IDC_DATETIMEPICKER3, m_dateEnd);
	DDX_Control(pDX, IDC_DATETIMEPICKER4, m_timeEnd);
	DDX_Control(pDX, IDC_EDIT10, m_editQuerySSId);
	DDX_Control(pDX, IDC_EDIT11, m_editQueryCameraId);
	DDX_Control(pDX, IDC_DATETIMEPICKER5, m_dataRecordBegin);
	DDX_Control(pDX, IDC_DATETIMEPICKER6, m_timeRecordBegin);
	DDX_Control(pDX, IDC_DATETIMEPICKER7, m_dataRecordEnd);
	DDX_Control(pDX, IDC_DATETIMEPICKER8, m_timeRecordEnd);
	DDX_Control(pDX, IDC_EDIT15, m_editPlanId);
	DDX_Control(pDX, IDC_DATETIMEPICKER9, m_dateTimePlayBegin);
	DDX_Control(pDX, IDC_DATETIMEPICKER10, m_timeTimePlayBegin);
	DDX_Control(pDX, IDC_DATETIMEPICKER11, m_dateTimePlayEnd);
	DDX_Control(pDX, IDC_DATETIMEPICKER12, m_timeTimePlayEnd);
	DDX_Control(pDX, IDC_COMBO4, m_comQuerySource);
	DDX_Control(pDX, IDC_COMBO5, m_comTimePlayWin);
	DDX_Control(pDX, IDC_COMBO6, m_comTimePlaySource);
	DDX_Control(pDX, IDC_COMBO8, m_comQueryRecordType);
	DDX_Control(pDX, IDC_EDIT16, m_editRecordCamera);
	DDX_Control(pDX, IDC_EDIT13, m_editTimePlayCamera);
	DDX_Control(pDX, IDC_EDIT21, m_editTimePlaySsId);
	DDX_Control(pDX, IDC_EDIT22, m_editRecordSsId);
	DDX_Control(pDX, IDC_EDIT25, m_editRecordMtsId);
	DDX_Control(pDX, IDC_EDIT23, m_editRecPlanSsId);
	DDX_Control(pDX, IDC_EDIT24, m_editRecPlanMtsId);
	DDX_Control(pDX, IDC_EDIT20, m_editRecPlanCameraId);
	DDX_Control(pDX, IDC_EDIT19, m_editRecPlanPlanId);
	DDX_Control(pDX, IDC_EDIT35, m_editTimeDownFileName);
	DDX_Control(pDX, IDC_EDIT36, m_editTimeDownFilePath);
	DDX_Control(pDX, IDC_EDIT12, m_editTimeDownStatus);
	DDX_Control(pDX, IDC_ADKPLAYBACKOCXCTRL1, m_ocxPlayback);
}

BEGIN_MESSAGE_MAP(CADKPlaybackTestDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CADKPlaybackTestDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CADKPlaybackTestDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON_ADDCAMERA, &CADKPlaybackTestDlg::OnBnClickedButtonAddcamera)
	ON_BN_CLICKED(IDC_BUTTON_QUERY, &CADKPlaybackTestDlg::OnBnClickedButtonQuery)
	ON_BN_CLICKED(IDC_BUTTON_SHOWLIST, &CADKPlaybackTestDlg::OnBnClickedButtonShowlist)
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_BUTTON_RECORD, &CADKPlaybackTestDlg::OnBnClickedButtonRecord)
	ON_BN_CLICKED(IDC_BUTTON_STOPRECORD, &CADKPlaybackTestDlg::OnBnClickedButtonStoprecord)
	ON_BN_CLICKED(IDC_BUTTON_ADD_RECORDPLAN, &CADKPlaybackTestDlg::OnBnClickedButtonAddRecordplan)
	ON_BN_CLICKED(IDC_BUTTON_REMOVE_RECORD_PLAN, &CADKPlaybackTestDlg::OnBnClickedButtonRemoveRecordPlan)
	ON_BN_CLICKED(IDC_BUTTON_PLAYTIME, &CADKPlaybackTestDlg::OnBnClickedButtonPlaytime)
	ON_BN_CLICKED(IDC_BUTTON_TIMEDOWN, &CADKPlaybackTestDlg::OnBnClickedButtonTimedown)
	ON_BN_CLICKED(IDC_BUTTON_HIDE, &CADKPlaybackTestDlg::OnBnClickedButtonHide)
	ON_BN_CLICKED(IDC_BUTTON_HIDE2, &CADKPlaybackTestDlg::OnBnClickedButtonHide2)
	ON_BN_CLICKED(IDC_BTN_LOCALFILE, &CADKPlaybackTestDlg::OnBnClickedBtnLocalfile)
	ON_BN_CLICKED(IDC_BUTTON_PLAY, &CADKPlaybackTestDlg::OnBnClickedButtonPlay)
	ON_BN_CLICKED(IDC_BUTTON_STOP, &CADKPlaybackTestDlg::OnBnClickedButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_PAUSE, &CADKPlaybackTestDlg::OnBnClickedButtonPause)
	ON_BN_CLICKED(IDC_BUTTON_RESUME, &CADKPlaybackTestDlg::OnBnClickedButtonResume)
	ON_BN_CLICKED(IDC_BUTTON_FAST, &CADKPlaybackTestDlg::OnBnClickedButtonFast)
	ON_BN_CLICKED(IDC_BUTTON_SLOW, &CADKPlaybackTestDlg::OnBnClickedButtonSlow)
	ON_BN_CLICKED(IDC_BUTTON_HEAD, &CADKPlaybackTestDlg::OnBnClickedButtonHead)
	ON_BN_CLICKED(IDC_BUTTON_TAIL, &CADKPlaybackTestDlg::OnBnClickedButtonTail)
	ON_BN_CLICKED(IDC_BUTTON_HIDEPLAYBAR, &CADKPlaybackTestDlg::OnBnClickedButtonHideplaybar)
	ON_BN_CLICKED(IDC_BUTTON_OPENSOUND, &CADKPlaybackTestDlg::OnBnClickedButtonOpensound)
	ON_BN_CLICKED(IDC_BUTTON_CLOSESOUND, &CADKPlaybackTestDlg::OnBnClickedButtonClosesound)
	ON_BN_CLICKED(IDC_BUTTON_DOWNLOADCANCEL, &CADKPlaybackTestDlg::OnBnClickedButtonDownloadcancel)
	ON_CBN_SELCHANGE(IDC_COMBO_WNDNUM, &CADKPlaybackTestDlg::OnCbnSelchangeComboWndnum)
END_MESSAGE_MAP()


// CADKPlaybackTestDlg ��Ϣ��������


int CADKPlaybackTestDlg::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  �ڴ�������ר�õĴ�������
	// ��������
	TCHAR	cFileName[512] = {0};
	TCHAR	acBuf[512] = {0};
	GetModuleFileName(AfxGetInstanceHandle(), cFileName, 512);
	GetLongPathName(cFileName,acBuf,512);
	CString strPre = acBuf;
	CString strPath = strPre.Left(strPre.ReverseFind(_T('\\'))+1);
	if ( strPath.Right(1) != _T("\\"))
	{
		strPath += _T("\\");
	}

	//�����ļ��ĳ�ʼ��
	CDemoLanguage::Instance()->Init( strPath );

//  	CDemoLanguage::Instance()->SetCurInterfaceSolution( LANGUAGE_ENGLISH_VERSION );
	CDemoLanguage::Instance()->SetCurInterfaceSolution( LANGUAGE_CHINESE_VERSION );
	

	//���öԻ����еľ�̬�ı�(Ӣ��-->��ǰ����)
	//_CWndCS( this );

	if ( !IsWindow(m_dlgRecordList.m_hWnd))
	{
		m_dlgRecordList.SetDlgInfo(this);
		m_dlgRecordList.Create(IDD_DLG_RECORDLIST,this);
	}


	if ( !IsWindow(m_dlgOther.m_hWnd))
	{
		m_dlgOther.SetDlgInfo(this);
		m_dlgOther.Create(IDD_DLG_OTHER,this);
		m_dlgOther.ShowWindow(SW_HIDE);
	}

	return 0;
}



BOOL CADKPlaybackTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	//���öԻ����еľ�̬�ı�(Ӣ��-->��ǰ����)
	_CWndCS( this );

	m_editMTSIp.SetWindowText(_T("20.2.1.36"));
	m_editSSIp.SetWindowText(_T("20.2.1.36"));

#ifdef DEBUG
	m_editMTSIp.SetWindowText(_T("10.7.9.50"));
	m_editSSIp.SetWindowText(_T("10.7.9.50"));

	m_editCameraUser.SetWindowText(_T("1"));
	m_editCameraChl.SetWindowText(_T("1"));
	m_editCameraIp.SetWindowText(_T("10.7.4.23"));
#endif
	//m_editCameraUser.SetWindowText(_T("2"));
	//m_editCameraPsw.SetWindowText(_T("2"));
	//m_editCameraChl.SetWindowText(_T("0"));
	//m_editCameraIp.SetWindowText(_T("10.7.4.42"));



	m_editMTSPort.SetWindowText(_T("9110"));
	m_editSSPort.SetWindowText(_T("9310"));
	m_editMTSPort.SetReadOnly(TRUE);
	m_editSSPort.SetReadOnly(TRUE);

	m_editCameraPort.SetWindowText(_T("37777"));
	m_editCameraPort.SetReadOnly(TRUE);

	m_comQuerySource.AddString(_CS(_T("2 Device source")));
	m_comQuerySource.AddString(_CS(_T("3 Center source")));
	m_comQueryRecordType.AddString(_CS(_T("1 Normal record")));
	m_comQueryRecordType.AddString(_CS(_T("2 Alarm record")));
	m_comQueryRecordType.AddString(_CS(_T("3 Motion record")));
	m_comQueryRecordType.AddString(_CS(_T("4 VideoLose record")));
	m_comQueryRecordType.AddString(_CS(_T("5 VideoCove record")));
	m_editQuerySSId.SetReadOnly(TRUE);

	m_comTimePlaySource.AddString(_CS(_T("2 Device source")));
	m_comTimePlaySource.AddString(_CS(_T("3 Center source")));
	m_comTimePlayWin.AddString("0");
	m_comTimePlayWin.AddString("1");
	m_comTimePlayWin.AddString("2");
	m_comTimePlayWin.AddString("3");

	CString formatStr= _T(" HH:mm:ss");
	m_timeBegin.SetFormat(formatStr);
	m_timeEnd.SetFormat(formatStr);
	CTime tm1 = CTime::GetCurrentTime();
	m_dateBegin.SetTime(&tm1);
	m_dateEnd.SetTime(&tm1);
	m_timeEnd.SetTime(&tm1);
	CTime tm2(tm1.GetYear(),tm1.GetMonth(),tm1.GetDay(),0,0,0);
	m_timeBegin.SetTime(&tm2);

	m_editQuerySSId.SetReadOnly(TRUE);
	m_editTimePlaySsId.SetReadOnly(TRUE);
	m_editRecordSsId.SetReadOnly(TRUE);
	m_editRecPlanSsId.SetReadOnly(TRUE);

	m_editRecordMtsId.SetReadOnly(TRUE);
	m_editRecPlanMtsId.SetReadOnly(TRUE);
	m_editTimeDownStatus.SetReadOnly(TRUE);

	m_comTimePlayWin.SetCurSel(2);

	

	//DWORD dwExtendedStyle = m_dlgRecordList.m_listRecordInfo.GetStyle();
	DWORD dwExtendedStyle = LVS_SINGLESEL;
	m_dlgRecordList.m_listRecordInfo.ModifyStyle(0,dwExtendedStyle);

	//���ʼ�طŴ�����
 	m_ocxPlayback.SetVideoWndNum(4);
	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CADKPlaybackTestDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ��������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ��
//
HCURSOR CADKPlaybackTestDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CADKPlaybackTestDlg::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	
	CString strSSIp,strSSPort;

	m_editSSIp.GetWindowText(strSSIp);
	m_editSSPort.GetWindowText(strSSPort);

	if ( strSSIp.IsEmpty()
		|| strSSPort.IsEmpty() )
	{
		return;
	}

	int nPort = atoi(strSSPort);

	int nSS = m_ocxPlayback.AddSSServer(strSSIp,nPort,_T(""));

	if ( nSS > 0 )
	{

		MessageBox(_T(_CS("Login SS server success")));
 		GetDlgItem(IDC_BUTTON1)->EnableWindow(FALSE);

		CString strTmp;
		strTmp.Format(_T("%d"),nSS);
		m_comboxSsExisted.AddString(strTmp);

		m_editQuerySSId.SetWindowText(strTmp);
		m_editTimePlaySsId.SetWindowText(strTmp);
		m_editRecordSsId.SetWindowText(strTmp);
		m_editRecPlanSsId.SetWindowText(strTmp);

		m_dlgOther.m_editSnapSsId.SetWindowText(strTmp);
		m_dlgOther.m_editSnapPlanSsId.SetWindowText(strTmp);
		m_dlgOther.m_editSetPathSsid.SetWindowText(strTmp);
		m_dlgOther.m_editAddDdnsSsId.SetWindowText(strTmp);


	}
	else
	{
		MessageBox(_CS("Login SS server failed"));
	}

}

void CADKPlaybackTestDlg::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CString strMTSIp,strMTSPort;

	m_editMTSIp.GetWindowText(strMTSIp);
	m_editMTSPort.GetWindowText(strMTSPort);

	if ( strMTSIp.IsEmpty()
		|| strMTSPort.IsEmpty() )
	{
		return;
	}

	int nPort = atoi(strMTSPort);

	int nMTS = m_ocxPlayback.AddMTSServer(strMTSIp,nPort,_T(""));

	if ( nMTS > 0 )
	{
		GetDlgItem(IDC_BUTTON2)->EnableWindow(FALSE);
		MessageBox(_T(_CS("Login MTS server success")));

		CString strTmp;
		strTmp.Format(_T("%d"),nMTS);
		m_comboxMtsExisted.AddString(strTmp);

		m_editRecordMtsId.SetWindowText(strTmp);
		m_editRecPlanMtsId.SetWindowText(strTmp);

		m_dlgOther.m_editAddDdnsMtsId.SetWindowText(strTmp);
		
	}
	else
	{
		MessageBox(_CS("Login MTS server failed"));
	}
}

void CADKPlaybackTestDlg::OnBnClickedButtonAddcamera()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CString strIp(_T(""));
	CString strPort = _T("");
	CString strUser, strPsw, strChl;

	m_editCameraIp.GetWindowText(strIp);
	m_editCameraPort.GetWindowText(strPort);
	m_editCameraUser.GetWindowText( strUser );
	m_editCameraPsw.GetWindowText(strPsw);
	m_editCameraChl.GetWindowText(strChl);

	if ( strIp.IsEmpty() )
	{
		MessageBox(_T(_CS("Please fill in the device's ip")));
		return;
	}
	if ( strPort.IsEmpty() )
	{

		MessageBox(_T(_CS("Please fill in the device's port")));
		return;
	}
	if ( strUser.IsEmpty() )
	{

		MessageBox(_T(_CS("Please fill in the device's username")));
		return;
	}

	if ( strChl.IsEmpty() )
	{

		MessageBox(_T(_CS("Please fill in the channel")));
		return;
	}

	int nPort = atoi(strPort);
	int nChannel = atoi(strChl);

	int nCameraId = m_ocxPlayback.AddCamera(strIp, nPort, strUser,strPsw,nChannel);

	if ( nCameraId > 0 )
	{

		MessageBox(_T(_CS("Add camera success")));


		m_editCameraIp.SetWindowText("");
		m_editCameraUser.SetWindowText("");
		m_editCameraPsw.SetWindowText("");
		m_editCameraChl.SetWindowText("");

		//CLIENT_CAMERA_INFO cameraInfo;
		//cameraInfo.strIp = strIp;
		//cameraInfo.strUser = strUser;
		//cameraInfo.strPsw = strPsw;
		//cameraInfo.nPort = nPort;
		//cameraInfo.nChannel = nChannel;

		//m_mapClientCameraInfo[nCameraId] = cameraInfo;

		CString strTmp;
		strTmp.Format(_T("%d-%s:%s:%s"),nCameraId,strIp,strPort,strChl);
		m_comboxCameraExisted.AddString(strTmp);
	}
	else
	{
		MessageBox(_CS("Add camera failed"));
	}

}

void CADKPlaybackTestDlg::OnBnClickedButtonQuery()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CString strSsId,strCameraId;
	m_editQuerySSId.GetWindowText(strSsId);
	m_editQueryCameraId.GetWindowText(strCameraId);
	if ( strSsId.IsEmpty() )
	{
		MessageBox(_CS("Please login ss server first"));
		return;
	}
	if ( strCameraId.IsEmpty() )
	{
		MessageBox(_CS("Please add camera first"));
		return;
	}
	int nssId = atoi(strSsId);
	int nCameraId = atoi(strCameraId);

	int nSource = -1;
	int nRecord = -1;
	nSource = m_comQuerySource.GetCurSel();
	nRecord = m_comQueryRecordType.GetCurSel();
	if ( nSource == -1 )
	{
		MessageBox(_CS("Please select the source type"));
		return;
	}
	if ( nRecord == -1 )
	{
		MessageBox(_CS("Please select the record type"));
		return;
	}
	nSource += 2;
	nRecord += 1;
	
	CTime dateBegin,dateEnd;
	CTime timeBegin,timeEnd;

	m_dateBegin.GetTime(dateBegin);
	m_dateEnd.GetTime(dateEnd);
	m_timeBegin.GetTime(timeBegin);
	m_timeEnd.GetTime(timeEnd);

	CString strBegin, strEnd;
	strBegin.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateBegin.GetYear(),dateBegin.GetMonth(),dateBegin.GetDay(),timeBegin.GetHour(),timeBegin.GetMinute(),timeBegin.GetSecond());
	strEnd.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateEnd.GetYear(),dateEnd.GetMonth(),dateEnd.GetDay(),timeEnd.GetHour(),timeEnd.GetMinute(),timeEnd.GetSecond());



	CString strXml = m_ocxPlayback.QueryRecords(nssId,nCameraId,nSource,nRecord,strBegin,strEnd,m_nMaxItem);

	if ( strXml.IsEmpty() )
	{
		m_dlgRecordList.m_listRecordInfo.DeleteAllItems();
		MessageBox(_CS("There are no record information"));
		return;
	}

	const char* tmp = (LPCTSTR)strXml;

	int nResult = m_recordXMLParse.formStream(tmp);
	if ( nResult == 0 )
	{

		m_dlgRecordList.InputNewRecordInfo(&m_recordXMLParse);


		m_bNeedFlash = TRUE;
		MessageBox(_CS("Query success,please turn to the record list"));
	}
	else
	{
		MessageBox(_CS("Failed to parse record InfoXML"),"error",MB_OK|MB_ICONWARNING);
	}

	return;
}

void CADKPlaybackTestDlg::OnBnClickedButtonShowlist()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	if ( m_dlgRecordList.IsWindowVisible() )
	{
		m_dlgRecordList.ShowWindow(SW_HIDE);
	}
	else
	{
		//if ( m_bNeedFlash == TRUE )
		//{
		//	//���������б�����

		//	m_dlgRecordList.InputNewRecordInfo(&m_recordXMLParse);


		//	m_bNeedFlash = FALSE;
		//}

		m_dlgRecordList.ShowWindow(SW_SHOW);
	}
	

}

void CADKPlaybackTestDlg::OnBnClickedButtonRecord()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	int nCameraId = -1;
	CString strCameraId("");
	m_editRecordCamera.GetWindowText(strCameraId);
	if ( strCameraId.IsEmpty() )
	{
		MessageBox(_CS("Camera Id is empty"));
		return;
	}
	nCameraId = atoi(strCameraId);

	CString strTmp("");
	m_editPlanId.GetWindowText(strTmp);
	if ( strTmp.IsEmpty() )
	{
		MessageBox(_CS("Plan Id is empty"));
	}
	int nPlanId = atoi(strTmp);

	CString strSs("");
	m_editRecordSsId.GetWindowText(strSs);
	int nSsId = atoi(strSs);

	CString strMts("");
	m_editRecordMtsId.GetWindowText(strMts);
	int nMtsId = atoi(strMts);

	if ( nCameraId > 0 && nPlanId > 0 )
	{
		int nRes = m_ocxPlayback.StartRecord(nSsId,nMtsId,nCameraId,nPlanId);

		if ( nRes < 0 )
		{
			ConverErrorCode(nRes);
		}
		else
		{
			MessageBox(_CS("Start record success"));
		}

		return;
	}
	else
	{
		MessageBox(_CS("Bad parameter"));

	}
}

void CADKPlaybackTestDlg::OnBnClickedButtonStoprecord()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	int nCameraId = -1;
	CString strCameraId("");
	m_editRecordCamera.GetWindowText(strCameraId);
	if ( strCameraId.IsEmpty() )
	{
		MessageBox(_CS("Camera Id is empty"));
		return;
	}
	nCameraId = atoi(strCameraId);


	CString strTmp("");
	m_editPlanId.GetWindowText(strTmp);
	int nPlanId = atoi(strTmp);


	CString strSs("");
	m_editRecordSsId.GetWindowText(strSs);
	int nSsId = atoi(strSs);

	if ( nCameraId > 0 && nPlanId > 0 )
	{
		int nRes = m_ocxPlayback.StopRecord(nSsId,nCameraId,nPlanId);

		if ( nRes < 0 )
		{
			ConverErrorCode(nRes);
		}
		if ( nRes == 0 )
		{
			MessageBox(_CS("Stop record success"));
		}

		return;
	}
	else
	{
		MessageBox(_CS("Bad parameter"));

	}
}

void CADKPlaybackTestDlg::OnBnClickedButtonAddRecordplan()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	int nCameraId = -1;
	CString strCameraId("");
	m_editRecPlanCameraId.GetWindowText(strCameraId);
	if ( strCameraId.IsEmpty() )
	{
		MessageBox(_CS("Camera Id is empty"));
		return;
	}
	nCameraId = atoi(strCameraId);

	CString strTmp("");
	m_editRecPlanPlanId.GetWindowText(strTmp);
	if ( strTmp.IsEmpty())
	{
		MessageBox(_T(_CS("Plan Id is empty")));
		return;
	}

	int nPlanId = atoi(strTmp);


	CString strSs("");
	m_editRecPlanSsId.GetWindowText(strSs);
	int nSsId = atoi(strSs);

	CString strMts("");
	m_editRecPlanMtsId.GetWindowText(strMts);
	int nMtsId = atoi(strMts);


	CTime dateBegin,dateEnd;
	CTime timeBegin,timeEnd;

	m_dataRecordBegin.GetTime(dateBegin);
	m_dataRecordEnd.GetTime(dateEnd);
	m_timeRecordBegin.GetTime(timeBegin);
	m_timeRecordEnd.GetTime(timeEnd);

	CString strBegin, strEnd;
	strBegin.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateBegin.GetYear(),dateBegin.GetMonth(),dateBegin.GetDay(),timeBegin.GetHour(),timeBegin.GetMinute(),timeBegin.GetSecond());
	strEnd.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateEnd.GetYear(),dateEnd.GetMonth(),dateEnd.GetDay(),timeEnd.GetHour(),timeEnd.GetMinute(),timeEnd.GetSecond());


	int nRes = m_ocxPlayback.AddRecordTask(nSsId,nMtsId, nCameraId,strBegin,strEnd,nPlanId);

	if ( nRes < 0 )
	{
		ConverErrorCode(nRes);
	}
	else
	{
		MessageBox(_CS("Add record task success"));
	}

	return;
}

void CADKPlaybackTestDlg::OnBnClickedButtonRemoveRecordPlan()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	int nCameraId = -1;
	CString strCameraId("");
	m_editRecPlanCameraId.GetWindowText(strCameraId);
	if ( strCameraId.IsEmpty() )
	{
		MessageBox(_CS("Camera Id is empty"));
		return;
	}
	nCameraId = atoi(strCameraId);

	CString strTmp("");
	m_editRecPlanPlanId.GetWindowText(strTmp);
	if ( strTmp.IsEmpty())
	{
		MessageBox(_T(_CS("Plan Id is empty")));
	}
	int nPlanId = atoi(strTmp);

	CString strSs("");
	m_editRecPlanSsId.GetWindowText(strSs);
	int nSsId = atoi(strSs);

	CString strMts("");
	m_editRecPlanMtsId.GetWindowText(strMts);
	int nMtsId = atoi(strMts);


	int nRes = m_ocxPlayback.RemoveRecordTask(nSsId,nMtsId, /*nCameraId,*/nPlanId);

	if ( nRes < 0 )
	{
		ConverErrorCode(nRes);
	}

	if ( nRes == 0 )
	{
		MessageBox(_CS("Remove record task success"));
	}

}

void CADKPlaybackTestDlg::OnBnClickedButtonPlaytime()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CTime dateBegin,dateEnd;
	CTime timeBegin,timeEnd;

	m_dateTimePlayBegin.GetTime(dateBegin);
	m_dateTimePlayEnd.GetTime(dateEnd);
	m_timeTimePlayBegin.GetTime(timeBegin);
	m_timeTimePlayEnd.GetTime(timeEnd);

	CString strBegin, strEnd;
	strBegin.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateBegin.GetYear(),dateBegin.GetMonth(),dateBegin.GetDay(),timeBegin.GetHour(),timeBegin.GetMinute(),timeBegin.GetSecond());
	strEnd.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateEnd.GetYear(),dateEnd.GetMonth(),dateEnd.GetDay(),timeEnd.GetHour(),timeEnd.GetMinute(),timeEnd.GetSecond());

	int nSource = -1;
	nSource = m_comTimePlaySource.GetCurSel();
	if ( nSource == -1 )
	{
		MessageBox(_CS("Please select the source type"));
		return;
	}
	nSource += 2;

	CString strWinNum;
	m_comTimePlayWin.GetWindowText(strWinNum);
	if ( strWinNum.IsEmpty() )
	{
		MessageBox(_CS("Please select the window number"));
		return;
	}
	int nWinNum = atoi(strWinNum);

	int nCameraId = -1;
	CString strCameraId("");
	m_editTimePlayCamera.GetWindowText(strCameraId);
	if ( strCameraId.IsEmpty() )
	{
		MessageBox(_CS("Camera Id is empty"));
		return;
	}
	nCameraId = atoi(strCameraId);

	CString strSs("");
	m_editTimePlaySsId.GetWindowText(strSs);
	int nSsId = atoi(strSs);

	int nRes = m_ocxPlayback.PlaybackByTime(nSsId,nSource,strBegin,strEnd,nCameraId,nWinNum);
	if ( nRes < 0 )
	{
		ConverErrorCode(nRes);
	}
}

void CADKPlaybackTestDlg::OnBnClickedButtonTimedown()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CTime dateBegin,dateEnd;
	CTime timeBegin,timeEnd;

	m_dateTimePlayBegin.GetTime(dateBegin);
	m_dateTimePlayEnd.GetTime(dateEnd);
	m_timeTimePlayBegin.GetTime(timeBegin);
	m_timeTimePlayEnd.GetTime(timeEnd);

	CString strBegin, strEnd;
	strBegin.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateBegin.GetYear(),dateBegin.GetMonth(),dateBegin.GetDay(),timeBegin.GetHour(),timeBegin.GetMinute(),timeBegin.GetSecond());
	strEnd.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateEnd.GetYear(),dateEnd.GetMonth(),dateEnd.GetDay(),timeEnd.GetHour(),timeEnd.GetMinute(),timeEnd.GetSecond());

	int nSource = -1;
	nSource = m_comTimePlaySource.GetCurSel();
	if ( nSource == -1 )
	{
		MessageBox(_CS("Please select the source type"));
		return;
	}
	nSource += 2;

	int nCameraId = -1;
	CString strCameraId("");
	m_editTimePlayCamera.GetWindowText(strCameraId);
	if ( strCameraId.IsEmpty() )
	{
		MessageBox(_CS("Camera Id is empty"));
		return;
	}
	nCameraId = atoi(strCameraId);


	CString strSs("");
	m_editTimePlaySsId.GetWindowText(strSs);
	if ( strSs.IsEmpty() )
	{
		MessageBox(_CS("Please login ss server first"));
		return;
	}
	int nSsId = atoi(strSs);

	CString strFileName("");
	CString strFilePath("");
	m_editTimeDownFileName.GetWindowText(strFileName);
	m_editTimeDownFilePath.GetWindowText(strFilePath);
	if ( strFileName.IsEmpty() )
	{
		MessageBox(_CS("Please fill in the file name that you want to save as"));
		return;
	}

	int nRes = m_ocxPlayback.DownloadByTime(nSsId,nSource,strBegin,strEnd,nCameraId,strFileName,strFilePath);

	if ( nRes < 0 )
	{
		m_editTimeDownStatus.SetWindowText("");
		ConverErrorCode(nRes);
	}
	else
	{
		m_nDownloadId = nRes;

		CString strTmp("");
		if ( nSource == 2 )
		{
			strTmp.Format(_T(_CS("Sending the download command.During the downloading time, you couldn't open video of the device record")));
		}
		if ( nSource == 3 )
		{
			strTmp.Format(_T(_CS("Sending the download command")));
		}

		m_editTimeDownStatus.SetWindowText(_CS("Downloading the TimeRecord file"));
		MessageBox(strTmp);
	}


}

BEGIN_EVENTSINK_MAP(CADKPlaybackTestDlg, CDialog)
	ON_EVENT(CADKPlaybackTestDlg, IDC_ADKPLAYBACKOCXCTRL1, 1, CADKPlaybackTestDlg::OnDownloadProgressAdkplaybackocxctrl1, VTS_I4 VTS_I4 VTS_I4 VTS_I4)
	ON_EVENT(CADKPlaybackTestDlg, IDC_ADKPLAYBACKOCXCTRL1, 2, CADKPlaybackTestDlg::OnErrorAdkplaybackocxctrl1, VTS_I4 VTS_BSTR VTS_I4 VTS_I4)
	ON_EVENT(CADKPlaybackTestDlg, IDC_ADKPLAYBACKOCXCTRL1, 3, CADKPlaybackTestDlg::OnPlayEndAdkplaybackocxctrl1, VTS_I4)
	ON_EVENT(CADKPlaybackTestDlg, IDC_ADKPLAYBACKOCXCTRL1, 4, CADKPlaybackTestDlg::OnDownloadEndAdkplaybackocxctrl1, VTS_I4)
END_EVENTSINK_MAP()

void CADKPlaybackTestDlg::OnDownloadProgressAdkplaybackocxctrl1(long bValid, long nSessionId, long nCurLen, long nFileLen)
{
	// TODO: �ڴ˴�������Ϣ�����������

	CString strText(_T(""));
	int nRate = 0;

	switch(bValid)
	{
	case DownloadFailed:
		strText = _T(_CS("Download failed"));
		m_editTimeDownStatus.SetWindowText("");
		m_dlgRecordList.m_editDownloadProc.SetWindowText("");
		MessageBox(strText);
		break;

	case DownloadSuccess:
		strText = _T(_CS("Download success"));
		m_editTimeDownStatus.SetWindowText("");
		m_dlgRecordList.m_editDownloadProc.SetWindowText("");
		MessageBox(strText);
		break;

	case Downloading:
		nRate = nCurLen* 100 / nFileLen;
		strText.Format("%d",nRate);
		m_dlgRecordList.m_editDownloadProc.SetWindowText(strText);
		break;

	default:
		break;

	}

	return;
}



static int s_nHide = 0;

void CADKPlaybackTestDlg::OnBnClickedButtonHide()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	if ( s_nHide == 0 )
	{
		s_nHide = 1;
		//m_ocxPlayback.HidePanel(s_nHide);
 		m_ocxPlayback.ShowWindow(SW_HIDE);
	}
	else
	{
		s_nHide = 0;
 		m_ocxPlayback.ShowWindow(SW_SHOW);
	}
}

void CADKPlaybackTestDlg::OnBnClickedButtonHide2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������


	if ( m_dlgOther.IsWindowVisible())
	{
		m_dlgOther.ShowWindow(SW_HIDE);
	}
	else
	{
		m_dlgOther.ShowWindow(SW_SHOW);
	}

}

void CADKPlaybackTestDlg::OnErrorAdkplaybackocxctrl1(long nError, LPCTSTR strTime, long nSessionId, long nParam)
{
	// TODO: �ڴ˴�������Ϣ�����������

	CString strText(_T(""));

	switch(nError)
	{
	case FILE_PLAYBACK_START_FAILED:
		strText = _T(_CS("Failed to start file video!"));
		break;

	case FILE_DOWNLOAD_START_FAILED:
		strText = _T(_CS("Failed to start file download!"));
		break;

	case TIME_PLAYBACK_START_FAILED:
		strText = _T(_CS("Failed to start time video!"));
		break;

	case TIME_DOWNLOAD_START_FAILED:
		strText = _T(_CS("Failed to start time download!"));
		break;

	case FILE_PLAYBACK_DATA_ERROR:
		strText = _T(_CS("Failed to send data of file video!"));
		break;

	case FILE_DOWNLOAD_DATA_ERROR:
		strText = _T(_CS("Failed to send data of file download!"));
		break;

	case TIME_PLAYBACK_DATA_ERROR:
		strText = _T(_CS("Failed to send data of time video!"));
		break;

	case TIME_DOWNLOAD_DATA_ERROR:
		strText = _T(_CS("Failed to send data of time download!"));
		break;

	default:
		return;
	}

	m_dlgRecordList.m_editDownloadProc.SetWindowText(_T(""));
	m_editTimeDownStatus.SetWindowText(_T(""));
	MessageBox(strText);
	return;
}

int CADKPlaybackTestDlg::ConverErrorCode( int nErrorCode )
{
	CString strText(_T(""));

	switch(nErrorCode)
	{
	case PB_ERROR_CTRLDATA_NULL:
	case PB_ERROR_INVALID_SYSPOINTER:
		strText = _T(_CS("Internal error of the control"));			break;

	case PB_ERROR_STRING_EMPTY:
		strText = _T(_CS("Empty string"));			break;

	case PB_ERROR_RESPONSE_TIMEOUT:
		strText = _T(_CS("Response timeout"));			break;

	case PB_ERROR_RESPONSE_FAILED:
		strText = _T(_CS("Response failed"));			break;

	case PB_ERROR_RESPONSE_LOST:
		strText = _T(_CS("Response lost"));			break;

	case PB_ERROR_REGOCX_FAILED:
		strText = _T(_CS("Failed to register the videownd ocx"));	break;

	case PB_ERROR_INVALID_PLANID:
		strText = _T(_CS("Invalid plan Id"));		break;

	case PB_ERROR_INVALID_CAMERAINDEX:
		strText = _T(_CS("Invalid camera Id"));		break;

	case PB_ERROR_INVALID_TIMESTR:
		strText = _T(_CS("Invalid value of time"));		break;

	case PB_ERROR_INVALID_SSID:
		strText = _T(_CS("Invalid SS Id"));		break;

	case PB_ERROR_INVALID_MTSID:
		strText = _T(_CS("Invalid MTS Id"));		break;

	case PB_ERROR_INVALID_TYPE:
		strText = _T(_CS("Invalid type value"));		break;

	case PB_ERROR_WITHOUT_PATH:
		strText = _T(_CS("Without path to save file"));	break;

	case PB_ERROR_INVALID_BOOL:
		strText = _T(_CS("Invalid valueof bool"));		break;

	case PB_ERROR_INVALID_WNDHANDLE:
		strText = _T(_CS("Invalid handle of window"));		break;

	case PB_ERROR_INVALID_SOURCE:
		strText = _T(_CS("Invalid value of source type"));		break;

	case PB_ERROR_INVALID_WND:
		strText = _T(_CS("Invalid value of window"));		break;

	case PB_ERROR_INVALID_XMLFILESTR:
		strText = _T(_CS("Invalid string of XML"));	break;

	case PB_ERROR_DOWNLOAD_EXISTED:
		strText = _T(_CS("There has been downloading,please waite"));	break;

	case PB_ERROR_PLANID_NOTFOUND:
		strText = _T(_CS("There are no record task of this plan Id"));	break;

	case PB_ERROR_PLANID_EXISTED:
		strText = _T(_CS("The record task of this plan Id has been exsited"));	break;

	case PB_ERROR_PLAN_ISRUNNING:
		strText = _T(_CS("The record of this Id is doing now"));	break;

	default:
		strText = _T(_CS("Error,please check"));
		break;
	}

	MessageBox(strText);

	return 0;

}

void CADKPlaybackTestDlg::OnBnClickedBtnLocalfile()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������


	CString strFile;

	CFileDialog dlg(TRUE,			
		"",//"*.264",		
		"",//"*.264",		
		0,				
		"",
		this);		

	if(dlg.DoModal() == IDOK)
	{
		strFile = dlg.GetPathName();
	} 


	m_ocxPlayback.PlayLocalFile( strFile, m_ocxPlayback.GetSelWndIdx());
}

void CADKPlaybackTestDlg::OnBnClickedButtonPlay()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ocxPlayback.Start( m_ocxPlayback.GetSelWndIdx() );
}

void CADKPlaybackTestDlg::OnBnClickedButtonStop()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ocxPlayback.Stop( m_ocxPlayback.GetSelWndIdx() );
}

void CADKPlaybackTestDlg::OnBnClickedButtonPause()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ocxPlayback.Pause( m_ocxPlayback.GetSelWndIdx() );
}

void CADKPlaybackTestDlg::OnBnClickedButtonResume()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ocxPlayback.Resume( m_ocxPlayback.GetSelWndIdx() );
}

void CADKPlaybackTestDlg::OnBnClickedButtonFast()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ocxPlayback.Fast( m_ocxPlayback.GetSelWndIdx() );
}

void CADKPlaybackTestDlg::OnBnClickedButtonSlow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ocxPlayback.Slow( m_ocxPlayback.GetSelWndIdx() );
}

void CADKPlaybackTestDlg::OnBnClickedButtonHead()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ocxPlayback.Head( m_ocxPlayback.GetSelWndIdx() );
}

void CADKPlaybackTestDlg::OnBnClickedButtonTail()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ocxPlayback.Tail( m_ocxPlayback.GetSelWndIdx() );
}

void CADKPlaybackTestDlg::OnBnClickedButtonHideplaybar()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	static int s_nHideBar = 0;
	if ( s_nHideBar == 0 )
	{
		s_nHideBar = 1;
		m_ocxPlayback.HidePlaybackBar(s_nHideBar);
	}
	else
	{
		s_nHideBar = 0;
		m_ocxPlayback.HidePlaybackBar(s_nHideBar);
	}
}

void CADKPlaybackTestDlg::OnBnClickedButtonOpensound()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ocxPlayback.PlaySound( m_ocxPlayback.GetSelWndIdx() );
}

void CADKPlaybackTestDlg::OnBnClickedButtonClosesound()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ocxPlayback.StopSound( m_ocxPlayback.GetSelWndIdx() );
}

void CADKPlaybackTestDlg::OnDownloadEndAdkplaybackocxctrl1(long nSessionId)
{
	// TODO: �ڴ˴�������Ϣ�����������
	AfxMessageBox(_CS(_T("Download end.")));
}

void CADKPlaybackTestDlg::OnPlayEndAdkplaybackocxctrl1(long nSessionId)
{
	// TODO: �ڴ˴�������Ϣ�����������
	AfxMessageBox(_CS(_T("Play end.")));
}

void CADKPlaybackTestDlg::OnBnClickedButtonDownloadcancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if ( m_nDownloadId > 0 )
	{
		long nRet = m_ocxPlayback.StopDownload(m_nDownloadId);

		if ( 0 == nRet )
		{
			m_nDownloadId = -1;
			m_editTimeDownStatus.SetWindowText("");
			AfxMessageBox(_CS(_T("Cancel")));
		}
	}
}

void CADKPlaybackTestDlg::OnCbnSelchangeComboWndnum()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString str;
	int nSel = ((CComboBox*)GetDlgItem(IDC_COMBO_WNDNUM))->GetCurSel();

	if (nSel == 0)
	{
		m_ocxPlayback.SetVideoWndNum(1);
	}
	else
	{
		m_ocxPlayback.SetVideoWndNum(4);
	}
}

BOOL CADKPlaybackTestDlg::PreTranslateMessage(MSG* pMsg)
{
	// TODO: �ڴ�����ר�ô����/����û���
	if (pMsg->message == WM_KEYDOWN)
	{
		if (pMsg->wParam == VK_RETURN)
		{
			return TRUE;
		}
	}

	return CDialog::PreTranslateMessage(pMsg);
}
