#pragma once


#include "resource.h"
#include "afxwin.h"
#include "afxdtctl.h"
#include "DemoLanguage.h"

// CDlgOther �Ի���

class CDlgOther : public CDialog
{
	DECLARE_DYNAMIC(CDlgOther)

public:
	CDlgOther(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgOther();

// �Ի�������
	enum { IDD = IDD_DLG_OTHER };

public:
	void	SetDlgInfo(void* pInfo){ m_pDlgInfo = pInfo;}
	void*	 m_pDlgInfo;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButtonClientsnaptask();
	afx_msg void OnBnClickedButtonServersnaptask();
	afx_msg void OnBnClickedButtonSetpath();
	afx_msg void OnBnClickedButtonSetpath2();
	afx_msg void OnBnClickedButtonAddddns();
	CEdit m_editSnapSsId;
	CEdit m_editSnapCameraId;
	CDateTimeCtrl m_dateSnapBegin;
	CDateTimeCtrl m_dateSnapEnd;
	CDateTimeCtrl m_timeSnapBegin;
	CDateTimeCtrl m_timeSnapEnd;
	CEdit m_editSnapPlanSsId;
	CEdit m_editSnapPlanCamera;
	CComboBox m_comSetPathType;
	CEdit m_editMaxNum;
	CEdit m_editDdnsIp;
	CEdit m_editDdnsPort;
	CEdit m_editSetPathSsid;
	CEdit m_editAddDdnsSsId;
	CEdit m_editAddDdnsMtsId;
	afx_msg void OnBnClickedBtnPlayex();
	afx_msg void OnBnClickedBtnGetversion();
	CEdit m_editSetPathPath;
	CEdit m_editSnapCount;
	CEdit m_editSnapInterval;
	CEdit m_editSnapPlanInterval;
};