// DlgOther.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ADKPlaybackTest.h"
#include "DlgOther.h"
#include "ADKPlaybackTestDlg.h"



// CDlgOther �Ի���

IMPLEMENT_DYNAMIC(CDlgOther, CDialog)

CDlgOther::CDlgOther(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgOther::IDD, pParent)
{
	
}

CDlgOther::~CDlgOther()
{
	CDemoLanguage::UnInstace();
}

void CDlgOther::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT28, m_editSnapSsId);
	DDX_Control(pDX, IDC_EDIT12, m_editSnapCameraId);
	DDX_Control(pDX, IDC_DATETIMEPICKER13, m_dateSnapBegin);
	DDX_Control(pDX, IDC_DATETIMEPICKER15, m_dateSnapEnd);
	DDX_Control(pDX, IDC_DATETIMEPICKER14, m_timeSnapBegin);
	DDX_Control(pDX, IDC_DATETIMEPICKER16, m_timeSnapEnd);
	DDX_Control(pDX, IDC_EDIT27, m_editSnapPlanSsId);
	DDX_Control(pDX, IDC_EDIT26, m_editSnapPlanCamera);
	DDX_Control(pDX, IDC_COMBO7, m_comSetPathType);
	DDX_Control(pDX, IDC_EDIT14, m_editMaxNum);
	DDX_Control(pDX, IDC_EDIT17, m_editDdnsIp);
	DDX_Control(pDX, IDC_EDIT18, m_editDdnsPort);
	DDX_Control(pDX, IDC_EDIT29, m_editSetPathSsid);
	DDX_Control(pDX, IDC_EDIT30, m_editAddDdnsSsId);
	DDX_Control(pDX, IDC_EDIT31, m_editAddDdnsMtsId);
	DDX_Control(pDX, IDC_EDIT1, m_editSetPathPath);
	DDX_Control(pDX, IDC_EDIT32, m_editSnapCount);
	DDX_Control(pDX, IDC_EDIT33, m_editSnapInterval);
	DDX_Control(pDX, IDC_EDIT34, m_editSnapPlanInterval);
}


BEGIN_MESSAGE_MAP(CDlgOther, CDialog)
	ON_BN_CLICKED(IDC_BUTTON3, &CDlgOther::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CDlgOther::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON_CLIENTSNAPTASK, &CDlgOther::OnBnClickedButtonClientsnaptask)
	ON_BN_CLICKED(IDC_BUTTON_SERVERSNAPTASK, &CDlgOther::OnBnClickedButtonServersnaptask)
	ON_BN_CLICKED(IDC_BUTTON_SETPATH, &CDlgOther::OnBnClickedButtonSetpath)
	ON_BN_CLICKED(IDC_BUTTON_SETPATH2, &CDlgOther::OnBnClickedButtonSetpath2)
	ON_BN_CLICKED(IDC_BUTTON_ADDDDNS, &CDlgOther::OnBnClickedButtonAddddns)
	ON_BN_CLICKED(IDC_BTN_PLAYEX, &CDlgOther::OnBnClickedBtnPlayex)
	ON_BN_CLICKED(IDC_BTN_GETVERSION, &CDlgOther::OnBnClickedBtnGetversion)
END_MESSAGE_MAP()


// CDlgOther ��Ϣ��������

BOOL CDlgOther::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	//���������ļ�·��
	TCHAR   cFileName[512] = {0};
	GetModuleFileName(AfxGetInstanceHandle(), cFileName, 512);
	TCHAR acBuf[512];
	GetLongPathName(cFileName,acBuf,512); //ȫ·��
	CString strPre = acBuf;
	CString strPath = strPre.Left(strPre.ReverseFind(_T('\\'))+1);
	if ( strPath.Right(1) != _T("\\"))
	{
		strPath += _T("\\");
	}

	//�����ļ��ĳ�ʼ��
	if ( !strPath.IsEmpty() )
	{
// 		CDemoLanguage::Instance()->Init( strPath );
// 		CDemoLanguage::Instance()->SetCurLanguageSolution( LANGUAGE_ENGLISH_VERSION );
		//���öԻ����еľ�̬�ı�(Ӣ��-->��ǰ����)
		_CWndCS( this );
	}

	m_comSetPathType.AddString(_CS("1 Path of client snap"));
	m_comSetPathType.AddString(_CS("2 Path of server snap"));
	m_comSetPathType.AddString(_CS("3 Default path of download"));

	m_editDdnsPort.SetWindowText("7070");

	m_editSnapSsId.SetReadOnly(TRUE);
	m_editSnapPlanSsId.SetReadOnly(TRUE);
	m_editSetPathSsid.SetReadOnly(TRUE);
	m_editAddDdnsSsId.SetReadOnly(TRUE);

	m_editMaxNum.SetWindowText("100");
	m_editAddDdnsMtsId.SetReadOnly(TRUE);

	m_editSetPathPath.SetWindowText(_T("D:\\Snap"));
	m_editSnapCount.SetWindowText(_T("1"));
	m_editSnapInterval.SetWindowText(_T("0"));

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlgOther::OnBnClickedButton3()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	int nCameraId = -1;
	CString strCameraId("");
	m_editSnapCameraId.GetWindowText(strCameraId);
	if ( strCameraId.IsEmpty() )
	{
		MessageBox(_CS("Camera Id is empty"));
		return;
	}
	nCameraId = atoi(strCameraId);

	CString strSsId("");
	m_editSnapSsId.GetWindowText(strSsId);
	if ( strSsId.IsEmpty() )
	{
		MessageBox(_CS("Please login ss server first"));
		return;
	}
	int nSsId = atoi(strSsId);

	//CString strCount("");
	//m_editSnapCount.GetWindowText(strCount);
	//if ( strCount.IsEmpty() )
	//{
	//	MessageBox("��ĿΪ��");
	//	return;
	//}

	//CString strInterval("");
	//m_editSnapInterval.GetWindowText(strInterval);
	//if ( strInterval.IsEmpty() )
	//{
	//}


	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;

	int nRes = pDlg->m_ocxPlayback.ClientSnap(nSsId,nCameraId,1,0);

	if ( nRes < 0 )
	{
		pDlg->ConverErrorCode(nRes);
	}
}

void CDlgOther::OnBnClickedButton4()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	int nCameraId = -1;
	CString strCameraId("");
	m_editSnapCameraId.GetWindowText(strCameraId);
	if ( strCameraId.IsEmpty() )
	{		
		MessageBox(_CS("Camera Id is empty"));
		return;
	}
	nCameraId = atoi(strCameraId);

	CString strSsId("");
	m_editSnapSsId.GetWindowText(strSsId);
	if ( strSsId.IsEmpty() )
	{
		MessageBox(_CS("Please login ss server first"));
		return;
	}

	int nSsId = atoi(strSsId);

	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;

	int nRes = pDlg->m_ocxPlayback.SsSnap(nSsId,nCameraId,1,0);

	if ( nRes < 0 )
	{
		pDlg->ConverErrorCode(nRes);
	}

}

void CDlgOther::OnBnClickedButtonClientsnaptask()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CTime dateBegin,dateEnd;
	CTime timeBegin,timeEnd;

	m_dateSnapBegin.GetTime(dateBegin);
	m_dateSnapEnd.GetTime(dateEnd);
	m_timeSnapBegin.GetTime(timeBegin);
	m_timeSnapEnd.GetTime(timeEnd);

	CString strBegin, strEnd;
	strBegin.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateBegin.GetYear(),dateBegin.GetMonth(),dateBegin.GetDay(),timeBegin.GetHour(),timeBegin.GetMinute(),timeBegin.GetSecond());
	strEnd.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateEnd.GetYear(),dateEnd.GetMonth(),dateEnd.GetDay(),timeEnd.GetHour(),timeEnd.GetMinute(),timeEnd.GetSecond());


	int nCameraId = -1;
	CString strCameraId("");
	m_editSnapPlanCamera.GetWindowText(strCameraId);
	if ( strCameraId.IsEmpty() )
	{
		MessageBox(_CS("Camera Id is empty"));
		return;
	}
	nCameraId = atoi(strCameraId);

	int nSsid = -1;
	CString strSs;
	m_editSnapPlanSsId.GetWindowText(strSs);
	if ( strSs.IsEmpty() )
	{
		MessageBox(_CS("Please login ss server first"));
		return;
	}
	nSsid = atoi(strSs);

	CString strInterval("");
	m_editSnapPlanInterval.GetWindowText(strInterval);
	if ( strInterval.IsEmpty() )
	{
		MessageBox(_CS("The snap interval is empty"));
		return;
	}
	int nInterval = atoi(strInterval);
	if ( nInterval <= 0 )
	{
		MessageBox(_CS("The snap interval is invalid"));
		return;
	}

	if ( nInterval < 3 )
	{
		MessageBox(_CS("The snap interval is too short"));
		return;
	}

	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;

	int nRes = pDlg->m_ocxPlayback.ClientSnapTask(nSsid,nCameraId,strBegin,strEnd,nInterval);

	if ( nRes < 0 )
	{
		pDlg->ConverErrorCode(nRes);
	}
	else
	{
		MessageBox(_CS("Add task of client snap success"));
	}


}

void CDlgOther::OnBnClickedButtonServersnaptask()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CTime dateBegin,dateEnd;
	CTime timeBegin,timeEnd;

	m_dateSnapBegin.GetTime(dateBegin);
	m_dateSnapEnd.GetTime(dateEnd);
	m_timeSnapBegin.GetTime(timeBegin);
	m_timeSnapEnd.GetTime(timeEnd);

	CString strBegin, strEnd;
	strBegin.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateBegin.GetYear(),dateBegin.GetMonth(),dateBegin.GetDay(),timeBegin.GetHour(),timeBegin.GetMinute(),timeBegin.GetSecond());
	strEnd.Format(_T("%04d-%02d-%02d %02d:%02d:%02d"),dateEnd.GetYear(),dateEnd.GetMonth(),dateEnd.GetDay(),timeEnd.GetHour(),timeEnd.GetMinute(),timeEnd.GetSecond());


	int nCameraId = -1;
	CString strCameraId("");
	m_editSnapPlanCamera.GetWindowText(strCameraId);
	if ( strCameraId.IsEmpty() )
	{
		MessageBox(_CS("Camera Id is empty"));
		return;
	}
	nCameraId = atoi(strCameraId);

	int nSsid = -1;
	CString strSs;
	m_editSnapPlanSsId.GetWindowText(strSs);
	if ( strSs.IsEmpty() )
	{
		MessageBox(_CS("Please login ss server first"));
		return;
	}
	nSsid = atoi(strSs);

	CString strInterval("");
	m_editSnapPlanInterval.GetWindowText(strInterval);
	if ( strInterval.IsEmpty() )
	{
		MessageBox(_CS("The snap interval is empty"));
		return;
	}
	int nInterval = atoi(strInterval);
	if ( nInterval <= 0 )
	{
		MessageBox(_CS("The snap interval is invalid"));
		return;
	}

	if ( nInterval < 3 )
	{
		MessageBox(_CS("The snap interval is too short"));
		return;
	}

	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;

	int nRes = pDlg->m_ocxPlayback.SsSnapTask(nSsid,nCameraId,strBegin,strEnd,nInterval);

	if ( nRes < 0 )
	{
		pDlg->ConverErrorCode(nRes);
	}
	else
	{
		MessageBox(_CS("Add task of server snap success"));
	}
}



void CDlgOther::OnBnClickedButtonSetpath()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CString strSsid;
	m_editSetPathSsid.GetWindowText(strSsid);
	if ( strSsid.IsEmpty() )
	{
		MessageBox(_T(_CS("Please login ss server first")));
		return;
	}
	int nSsId = atoi(strSsid);

	int nSel = m_comSetPathType.GetCurSel();
	if ( nSel < 0  )
	{
		MessageBox(_T(_CS("The type value of path is empty")));
		return;
	}
	int pathType = nSel +1;

	CString strPath("");
	m_editSetPathPath.GetWindowText(strPath);
	if ( strPath.IsEmpty() )
	{
		MessageBox(_T(_CS("The path is empty")));
		return;
	}

	int nCreate = SHCreateDirectoryEx(NULL,strPath,NULL);
	if ( nCreate == ERROR_BAD_PATHNAME )
	{
		MessageBox(_T(_CS("The paht is wrong")));
		return;
	}
	else if ( nCreate == ERROR_FILENAME_EXCED_RANGE )
	{
		MessageBox(_T(_CS("The path is too long to save")));
		return;
	}
	

	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;
	int nRes = pDlg->m_ocxPlayback.SetPath(nSsId,pathType,strPath);
	if ( nRes < 0 )
	{
		MessageBox(_CS("Failed to set the path"));
	}
	else
	{
		//CString strTmp(_T(""));
		//strTmp.Format(_T("����·�� %s �ɹ�"),strPath);
		MessageBox(_CS("Set path success"));

	}

	return;

}

void CDlgOther::OnBnClickedButtonSetpath2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strNum;

	m_editMaxNum.GetWindowText(strNum);
	if ( strNum.IsEmpty() )
	{
		MessageBox(_CS("The value is empty"));
	}

	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;
	int nMaxNum = atoi(strNum);
	if (nMaxNum > 500)
	{
		MessageBox(_CS("The max value can't bigger than 500"));
		m_editMaxNum.SetFocus();
		return;
	}

	pDlg->m_nMaxItem = nMaxNum;

	MessageBox(_T(_CS("Set Max value success")));

}

void CDlgOther::OnBnClickedButtonAddddns()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;
	CString strIp;
	CString strPort;

	m_editDdnsIp.GetWindowText(strIp);
	m_editDdnsPort.GetWindowText(strPort);

	if ( strIp.IsEmpty() || strPort.IsEmpty() )
	{
		return;
	}
	int nPort = atoi(strPort);

	CString strMtsId, strSsId;
	m_editAddDdnsSsId.GetWindowText(strSsId);
	m_editAddDdnsMtsId.GetWindowText(strMtsId);
	int nSsId = atoi(strSsId);
	int nMtsId = atoi(strMtsId);

	int nRes = pDlg->m_ocxPlayback.AddDDNSServer(nSsId,nMtsId,strIp,nPort,"");

	if ( nRes < 0 )
	{
	
		MessageBox(_CS("Failed to add DDNS server"));

	}
	if ( nRes == 0 )
	{
		GetDlgItem(IDC_BUTTON_ADDDDNS)->EnableWindow(FALSE);
		MessageBox(_CS("Add DDNS server success"));
	}

	return;

}

const CString g_strXml = ("name=\"0-0-46763-122719\" beginTime=\"2009-08-03 00:00:02\" endTime=\"2009-08-03 01:00:00\" sourceType=\"2\" recordType=\"2\" recordLen=\"122719\" planId=\"0\" ssId=\"2\" diskId=\"\" fileHandle=\"0\"");

void CDlgOther::OnBnClickedBtnPlayex()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;
	if ( pDlg == NULL )
	{
		return;
	}

	CString strSsId = "";
	m_editSnapSsId.GetWindowText(strSsId);
	int nSsId = atoi(strSsId);

	CString strXmlInfo("");
	strXmlInfo = g_strXml;

	pDlg->m_ocxPlayback.PlaybackByFileEx(nSsId,strXmlInfo,1,1);

}

void CDlgOther::OnBnClickedBtnGetversion()
{
	CADKPlaybackTestDlg* pDlg = (CADKPlaybackTestDlg*)m_pDlgInfo;
	if ( pDlg == NULL )
	{
		return;
	}

	CString strVersion = pDlg->m_ocxPlayback.GetVersion();

	MessageBox(strVersion);


}
