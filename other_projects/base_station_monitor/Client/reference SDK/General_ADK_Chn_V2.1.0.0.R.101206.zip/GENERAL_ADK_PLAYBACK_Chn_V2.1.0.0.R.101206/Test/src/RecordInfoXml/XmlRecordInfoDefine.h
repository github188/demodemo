#ifndef _XML_RECORD_INFO_DEFINE_H
#define _XML_RECORD_INFO_DEFINE_H

namespace XMLRecordInfo
{

#define XML_TAG_RECORDS_INFO    "Recordsnfo"
#define XML_TAG_RECORD			"Record"

#define XML_ATTR_DEV_IP			"devIp"
#define XML_ATTR_DEV_PORT		"devPort"
#define XML_ATTR_CHANNEL		"channel"
#define XML_ATTR_SEQUENCE_NUM	"sequence"
#define XML_ATTR_CAMERA_INDEX	"cameraIndex"

#define XML_ATTR_ID				"id"
#define XML_ATTR_NAME			"name"
#define XML_ATTR_BEGIN_TIME		"beginTime"
#define XML_ATTR_END_TIME		"endTime"
#define XML_ATTR_RESOURCE_TYPE	"sourceType"
#define XML_ATTR_RECORD_TYPE	"recordType"
#define XML_ATTR_RECORD_LEN		"recordLen"
#define XML_ATTR_PLAN_ID		"planId"
#define XML_ATTR_SS_ID			"ssId"
#define XML_ATTR_DISK_ID		"diskId"
#define XML_ATTR_FILE_HANDLE	"fileHandle"

};

#endif
