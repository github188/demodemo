// PictureWnd.h: interface for the CPictureWnd class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PICTUREWND_H__28B9DC05_EF99_48DF_A1D8_A335323E2147__INCLUDED_)
#define AFX_PICTUREWND_H__28B9DC05_EF99_48DF_A1D8_A335323E2147__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPictureWnd : public CStatic  
{
public:
	enum{MODE_TILE = 1, MODE_FLEX = 2,};
	void SetBkImage(LPCTSTR szResourceName, BYTE bShowMode /*= MODE_TILE*/,LPCTSTR szResourceType);
	void SetBkImage(UINT uResourceID, BYTE bShowMode = MODE_TILE);
	void SetNoProcStaticColor(bool bNoProcColor);
	void SetBackColor(COLORREF cl);
	void SetBkImage(LPCTSTR szImage, BYTE bShowMode = MODE_TILE);
	CPictureWnd();
	virtual ~CPictureWnd();
protected:

	// Generated message map functions
	//{{AFX_MSG(CPictureWnd)
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	
	DECLARE_MESSAGE_MAP()
private:
	bool m_bBkImage;
	bool m_bProcStaticColor;
	HBRUSH m_hbrush;
	CString m_szBkImage;
	COLORREF m_crBkColor;
	
	enum{MODE_NONE = 0, MODE_BMP = 1, MODE_JPG = 2, MODE_BRUSH = 3,};
	
	BYTE	m_nBKMode;
	BYTE	m_bShowMode;

	CBitmap	m_bitmap;

	IStream*	m_pStream;  
	IPicture*	m_pPicture; 
};

#endif // !defined(AFX_PICTUREWND_H__28B9DC05_EF99_48DF_A1D8_A335323E2147__INCLUDED_)
