//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SDK_Demo.rc
//
#define IDD_SDK_DEMO_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_BTN_LOGIN                   1000
#define IDC_EDIT_IP                     1001
#define IDC_EDIT_PORT                   1002
#define IDC_BTN_LOGOUT                  1003
#define IDC_EDIT_DEVICE_IP              1004
#define IDC_EDIT_DEVICE_PORT            1005
#define IDC_EDIT_DEVICE_CNL             1006
#define IDC_EDIT_USR                    1007
#define IDC_EDIT_PWD                    1008
#define IDC_BTN_PLAY                    1009
#define IDC_IMAGE_PLAY                  1010
#define IDC_BTN_STOP                    1011
#define IDC_IMAGE_PLAY2                 1012
#define IDC_IMAGE_PLAY3                 1013
#define IDC_IMAGE_PLAY4                 1014
#define IDC_EDIT_PATH                   1015
#define IDC_COMBO_TYPE                  1016
#define IDC_BTN_AUDIO                   1017
#define IDC_COMBO_INDEX                 1018
#define IDC_COMBO_INDEX2                1019
#define IDC_BTN_STOP_AUDIO              1020
#define IDC_IMAGE_PLAY5                 1021
#define IDC_IMAGE_PLAY6                 1022
#define IDC_IMAGE_PLAY7                 1023
#define IDC_IMAGE_PLAY8                 1024
#define IDC_BTN_SNAP                    1025
#define IDC_BTN_RECORD                  1026
#define IDC_BTN_SETPATH                 1027
#define IDC_BTN_TALK                    1028
#define IDC_BTN_TALK2                   1029
#define IDC_BTN_STOP_AUDIO2             1030
#define IDC_BTN_STOP_TALK               1030
#define IDC_EDIT_DNS_IP                 1031
#define IDC_EDIT_DNS_PORT               1032
#define IDC_BTN_SET_DDNS                1033
#define IDC_BTN_STOP_RECORD             1034
#define IDC_CHECK_VIEW                  1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
