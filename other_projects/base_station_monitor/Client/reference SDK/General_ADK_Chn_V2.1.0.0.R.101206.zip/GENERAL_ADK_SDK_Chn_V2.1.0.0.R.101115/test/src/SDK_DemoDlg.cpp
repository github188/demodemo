// SDK_DemoDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "SDK_Demo.h"
#include "SDK_DemoDlg.h"


//#include "../Depend/plaympeg4.h"
#include "../Depend/dhplay.h"
#pragma comment(lib, "../Depend/dhplay.lib")

#include "../ADKStreamSDK/ADKStreamSDK.h"
#ifdef _DEBUG
#pragma comment(lib, "../debug/ADKStreamSDK.lib")
#else
#pragma comment(lib, "../release/ADKStreamSDK.lib")
#endif

#define ARRSIZE(x)	(sizeof(x)/sizeof(x[0]))
CString GetAppPath()
{
	static CString AppPath;
	if(!AppPath.IsEmpty())
		return AppPath;
	TCHAR path[_MAX_PATH];
	DWORD nReturnCode = GetModuleFileName(NULL,path,ARRSIZE(path));
	CString FileName = path;
	int pathLength = FileName.ReverseFind(_T('\\'));
	AppPath = FileName.Left(pathLength);
	return AppPath ;
}


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CSDK_DemoDlg �Ի���


CSDK_DemoDlg::CSDK_DemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSDK_DemoDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_bCBView = 0;
	for (int i=0; i<4; ++i)
	{
		m_bOpened[i] = false;
	}
	m_nCurIndex = 0;

	m_nApiId = -1;
	m_isTalk = false;
}

void CSDK_DemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_IMAGE_PLAY, m_ImgWnd1);
	DDX_Control(pDX, IDC_IMAGE_PLAY2, m_ImgWnd2);
	DDX_Control(pDX, IDC_IMAGE_PLAY3, m_ImgWnd3);
	DDX_Control(pDX, IDC_IMAGE_PLAY4, m_ImgWnd4);
	DDX_Control(pDX, IDC_IMAGE_PLAY5, m_ImgWnd5);
	DDX_Control(pDX, IDC_IMAGE_PLAY6, m_ImgWnd6);
	DDX_Control(pDX, IDC_IMAGE_PLAY7, m_ImgWnd7);
	DDX_Control(pDX, IDC_IMAGE_PLAY8, m_ImgWnd8);
}

BEGIN_MESSAGE_MAP(CSDK_DemoDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BTN_LOGIN, &CSDK_DemoDlg::OnBnClickedBtnLogin)
	ON_BN_CLICKED(IDC_BTN_LOGOUT, &CSDK_DemoDlg::OnBnClickedBtnLogout)
	ON_BN_CLICKED(IDC_BTN_PLAY, &CSDK_DemoDlg::OnBnClickedBtnPlay)
	ON_BN_CLICKED(IDC_BTN_STOP, &CSDK_DemoDlg::OnBnClickedBtnStop)
	ON_BN_CLICKED(IDC_BTN_AUDIO, &CSDK_DemoDlg::OnBnClickedBtnAudio)
	ON_BN_CLICKED(IDC_BTN_STOP_AUDIO, &CSDK_DemoDlg::OnBnClickedBtnStopAudio)
	ON_BN_CLICKED(IDC_BTN_SNAP, &CSDK_DemoDlg::OnBnClickedBtnSnap)
	ON_BN_CLICKED(IDC_BTN_RECORD, &CSDK_DemoDlg::OnBnClickedBtnRecord)
	ON_BN_CLICKED(IDC_BTN_SETPATH, &CSDK_DemoDlg::OnBnClickedBtnSetpath)
	ON_BN_CLICKED(IDC_BTN_SET_DDNS, &CSDK_DemoDlg::OnBnClickedBtnSetDdns)
	ON_BN_CLICKED(IDC_BTN_STOP_RECORD, &CSDK_DemoDlg::OnBnClickedBtnStopRecord)
	ON_BN_CLICKED(IDC_CHECK_VIEW, &CSDK_DemoDlg::OnBnClickedCheckView)
	ON_BN_CLICKED(IDC_BTN_TALK, &CSDK_DemoDlg::OnBnClickedBtnTalk)
	ON_BN_CLICKED(IDC_BTN_TALK2, &CSDK_DemoDlg::OnBnClickedBtnTalk2)
	ON_BN_CLICKED(IDC_BTN_STOP_TALK, &CSDK_DemoDlg::OnBnClickedBtnStopTalk)
	ON_MESSAGE(WM_SHOWTASK,onShowTask)
	//ON_WM_NCPAINT()
	ON_WM_CLOSE()
	ON_WM_DESTROY()
	ON_WM_SYSCOMMAND()
END_MESSAGE_MAP()

//�������ص�
static void __stdcall DataStreamcb(long API_ID, const int nIndex, const char * data, const int len, long nUser)
{
	CSDK_DemoDlg* pThis = (CSDK_DemoDlg*)nUser;
	pThis->playDataStream(API_ID, nIndex, data, len);
}


// CSDK_DemoDlg ��Ϣ��������

BOOL CSDK_DemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	SetDlgItemText(IDC_EDIT_IP,_T("20.2.1.36")); //20.2.1.36 10.7.9.60
	SetDlgItemText(IDC_EDIT_PORT,_T("9110"));

	SetDlgItemText(IDC_EDIT_DEVICE_IP,_T("20.2.1.36")); //10.7.10.205 10.7.4.28
	SetDlgItemText(IDC_EDIT_DEVICE_PORT,_T("37777"));
	SetDlgItemText(IDC_EDIT_DEVICE_CNL,_T("0"));
	SetDlgItemText(IDC_EDIT_USR,_T("admin"));
	SetDlgItemText(IDC_EDIT_PWD,_T("admin"));
	//SetDlgItemText(IDC_EDIT_INDEX,_T("1"));

	((CComboBox*)GetDlgItem(IDC_COMBO_INDEX))->InsertString(0, _T("1"));
	((CComboBox*)GetDlgItem(IDC_COMBO_INDEX))->InsertString(1, _T("2"));
	((CComboBox*)GetDlgItem(IDC_COMBO_INDEX))->InsertString(2, _T("3"));
	((CComboBox*)GetDlgItem(IDC_COMBO_INDEX))->InsertString(3, _T("4"));
	((CComboBox*)GetDlgItem(IDC_COMBO_INDEX))->SetCurSel(0);

	((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->InsertString(0, _T("1"));
	((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->InsertString(1, _T("2"));
	((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->InsertString(2, _T("3"));
	((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->InsertString(3, _T("4"));
	((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->SetCurSel(0);

	((CComboBox*)GetDlgItem(IDC_COMBO_TYPE))->InsertString(0, _T("������"));
	((CComboBox*)GetDlgItem(IDC_COMBO_TYPE))->InsertString(1, _T("������"));
	((CComboBox*)GetDlgItem(IDC_COMBO_TYPE))->SetCurSel(0);

	SetDlgItemText(IDC_EDIT_PATH, _T("C:\\ADK_API_PATH"));

	//��ʾ�ؼ�����
	CString szPath = GetAppPath() + _T("\\LOGO.bmp");
	m_ImgWnd1.SetBkImage(szPath,2);
	m_ImgWnd2.SetBkImage(szPath,2);
	m_ImgWnd3.SetBkImage(szPath,2);
	m_ImgWnd4.SetBkImage(szPath,2);
	m_ImgWnd5.SetBkImage(szPath,2);
	m_ImgWnd6.SetBkImage(szPath,2);
	m_ImgWnd7.SetBkImage(szPath,2);
	m_ImgWnd8.SetBkImage(szPath,2);

	//ToTray();
	//ModifyStyleEx(WS_EX_APPWINDOW, WS_EX_TOOLWINDOW);

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CSDK_DemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ��������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ��
//
HCURSOR CSDK_DemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CSDK_DemoDlg::ShowRes(long res)
{
	CString resStr("");
	if (res >= 0) 
	{
		resStr.Format("%s : %d", _T("����ֵ"), res);
		MessageBox( resStr, _T("�����ɹ�"), MB_ICONINFORMATION);
	}
	else
	{
		resStr.Format("%s : %d", _T("������"), res);
		MessageBox( resStr, _T("����ʧ��"), MB_ICONERROR);
	} 
}

void CSDK_DemoDlg::OnBnClickedBtnLogin()
{
	// TODO: ��½MTS������
	if (m_nApiId != -1)
	{
		MessageBox(_T("��Demoֻ֧��һ·MTS�������������Ƴ���ǰMTS������"));
		return;
	}
	CString strIp, strPort;
	GetDlgItem(IDC_EDIT_IP)->GetWindowText(strIp);
	GetDlgItem(IDC_EDIT_PORT)->GetWindowText(strPort);
 
 	m_nApiId = ADK_LoginMTS(/*m_nApiId,*/strIp,atoi(strPort));
	
 	ShowRes(m_nApiId);
}

void CSDK_DemoDlg::OnBnClickedBtnLogout()
{
	// TODO: �Ƴ�MTS������
	long res = ADK_RemoveMTS(m_nApiId);
	m_nApiId = -1;
	ShowRes(res);
	Invalidate();
}

void CSDK_DemoDlg::OnBnClickedBtnPlay()
{
	// TODO: ��ʵʱ����
	CString strIp, strPort, strChannel, strUser, strPsw, strIndex;
	GetDlgItem(IDC_EDIT_DEVICE_IP)->GetWindowText(strIp);
	GetDlgItem(IDC_EDIT_DEVICE_PORT)->GetWindowText(strPort);
	GetDlgItem(IDC_EDIT_DEVICE_CNL)->GetWindowText(strChannel);
	GetDlgItem(IDC_EDIT_USR)->GetWindowText(strUser);
	GetDlgItem(IDC_EDIT_PWD)->GetWindowText(strPsw);
	long nType = ((CComboBox*)GetDlgItem(IDC_COMBO_TYPE))->GetCurSel();
	nType++;

	HWND realplayWnd;
	long nIndex = ((CComboBox*)GetDlgItem(IDC_COMBO_INDEX))->GetCurSel();
	if (nIndex == 0)
	{
		GetDlgItem(IDC_IMAGE_PLAY, &realplayWnd);
	}
	else
	{
		GetDlgItem(IDC_IMAGE_PLAY+nIndex+1, &realplayWnd);
	}

	//�رյ�ǰ�������ص���ʾ
	for (int i=0; i<4; ++i)
	{
		if (m_hPlayWnd[i]==realplayWnd)
		{
			if (m_bOpened[i])
			{
				PLAY_Stop(6+i);
				PLAY_CloseStream(6+i);
				m_bOpened[i] = false;
			}
		}
	}
	

	ADK_Camera_Info info = {0};
	info.hWnd = realplayWnd;
	strncpy(info.ip,(LPCTSTR)strIp,sizeof(info.ip));
	info.port = atoi(strPort);
	info.channel = atoi(strChannel);
	strncpy(info.userName,(LPCTSTR)strUser,sizeof(info.userName));
	strncpy(info.password,(LPCTSTR)strPsw,sizeof(info.password));
	info.streamType = nType;

	long res = ADK_SetDataStreamCallBack(m_nApiId,DataStreamcb,(long)this);
	if ( 0 > res)
	{
		ShowRes(res);
		return;
	}
	long _index = ADK_OpenRealPlay(m_nApiId, &info);
	ShowRes(_index);

	if ( 0 <= _index)
	{
		m_hPlayWnd[_index] = realplayWnd;
		((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->SetCurSel(nIndex);
	}

}

void CSDK_DemoDlg::OnBnClickedBtnStop()
{
	// TODO: �ر�ʵʱ����
	HWND realplayWnd;
	long nIndex = ((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->GetCurSel();
	if (nIndex == 0)
	{
		GetDlgItem(IDC_IMAGE_PLAY, &realplayWnd);
	}
	else
	{
		GetDlgItem(IDC_IMAGE_PLAY+nIndex+1, &realplayWnd);
	}

	//����ر�
 	long res = ADK_StopRealPlayByHwnd(m_nApiId, realplayWnd);
 	ShowRes(res);
 	if (0 <= res)
	{
		PLAY_Stop(6+nIndex);
		PLAY_CloseStream(6+nIndex);
		m_bOpened[nIndex] = false;
	}
	//��Źر�
	//for (int i=0; i<4; ++i)
	//{
	//	if (m_hPlayWnd[i]==realplayWnd)
	//	{
	//		PLAY_Stop(6+i);
	//		PLAY_CloseStream(6+i);
	//		m_bOpened[i] = false;

	//	 	long res = ADK_StopRealPlayByIndex(m_nApiId, i);
	//	 	ShowRes(res);
	//	}
	//}

	Invalidate();
}

void CSDK_DemoDlg::OnBnClickedBtnAudio()
{
	// TODO: �򿪰���
	HWND realplayWnd;
	long nIndex = ((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->GetCurSel();
	if (nIndex == 0)
	{
		GetDlgItem(IDC_IMAGE_PLAY, &realplayWnd);
	}
	else
	{
		GetDlgItem(IDC_IMAGE_PLAY+nIndex+1, &realplayWnd);
	}

	long res = ADK_EnableAudioByHwnd(m_nApiId, realplayWnd, 1);
	ShowRes(res);
}

void CSDK_DemoDlg::OnBnClickedBtnStopAudio()
{
	// TODO: �رհ���
	HWND realplayWnd;
	long nIndex = ((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->GetCurSel();
	if (nIndex == 0)
	{
		GetDlgItem(IDC_IMAGE_PLAY, &realplayWnd);
	}
	else
	{
		GetDlgItem(IDC_IMAGE_PLAY+nIndex+1, &realplayWnd);
	}

	long res = ADK_EnableAudioByHwnd(m_nApiId, realplayWnd, 0);
	ShowRes(res);
}

void CSDK_DemoDlg::playDataStream(long API_ID, const int nIndex, const char * data, const int len)
{
	int _index = nIndex;
	if (!m_bCBView)
	{
		return;
	}

	//���Żص�������
	if (!m_bOpened[_index])
	{
		HWND hWnd;
		GetDlgItem(IDC_IMAGE_PLAY5+_index, &hWnd);
		BOOL b = PLAY_OpenStream(6+_index, 0, 0, 100*1024);
		if (!b)
		{
			printf("PLAY_OpenStream return FALSE ! \n");
		}

		b = PLAY_Play(6+_index, hWnd);
		if (!b)
		{
			printf("PLAY_Play return FALSE ! \n");
		}
		m_bOpened[_index] = true;
	}

	BOOL b = PLAY_InputData(6+nIndex,(PBYTE)data,len);
	if (!b)
	{
		printf("v return FALSE ! \n");
	}
}

void CSDK_DemoDlg::OnBnClickedBtnSnap()
{
	// TODO: ͨ�����ץͼ
	HWND realplayWnd;
	long nIndex = ((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->GetCurSel();
	if (nIndex == 0)
	{
		GetDlgItem(IDC_IMAGE_PLAY, &realplayWnd);
	}
	else
	{
		GetDlgItem(IDC_IMAGE_PLAY+nIndex+1, &realplayWnd);
	}

	long res = ADK_SnapByHwnd(m_nApiId, realplayWnd, NULL);
	ShowRes(res);
}

void CSDK_DemoDlg::OnBnClickedBtnRecord()
{
	// TODO: ͨ�������ʼ¼��
	HWND realplayWnd;
	long nIndex = ((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->GetCurSel();
	if (nIndex == 0)
	{
		GetDlgItem(IDC_IMAGE_PLAY, &realplayWnd);
	}
	else
	{
		GetDlgItem(IDC_IMAGE_PLAY+nIndex+1, &realplayWnd);
	}

	long res = ADK_StartRecordByHwnd(m_nApiId, realplayWnd, NULL, 0);
	ShowRes(res);
}

void CSDK_DemoDlg::OnBnClickedBtnStopRecord()
{
	// TODO: ͨ�����ֹͣ¼��
	HWND realplayWnd;
	long nIndex = ((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->GetCurSel();
	if (nIndex == 0)
	{
		GetDlgItem(IDC_IMAGE_PLAY, &realplayWnd);
	}
	else
	{
		GetDlgItem(IDC_IMAGE_PLAY+nIndex+1, &realplayWnd);
	}

	long res = ADK_StopRecordByHwnd(m_nApiId, realplayWnd);
	ShowRes(res);
}


void CSDK_DemoDlg::OnBnClickedBtnSetpath()
{
	// TODO: ����ץͼ��¼��洢·��
	CString strPath;
	GetDlgItem(IDC_EDIT_PATH)->GetWindowText(strPath);

	long res = ADK_SetWordPath(m_nApiId, strPath);
	ShowRes(res);
}

void CSDK_DemoDlg::OnBnClickedBtnSetDdns()
{
	// TODO: ����DDNS
	CString strIp, strPort;
	GetDlgItem(IDC_EDIT_DNS_IP)->GetWindowText(strIp);
	GetDlgItem(IDC_EDIT_DNS_PORT)->GetWindowText(strPort);

 	long res = ADK_SetDDNSServer(m_nApiId,strIp,atoi(strPort));
 	ShowRes(res);
}

void CSDK_DemoDlg::OnBnClickedCheckView()
{
	// TODO: �Ƿ���ʾ�������ص�
	CButton *pbtn = (CButton*)GetDlgItem(IDC_CHECK_VIEW);
	m_bCBView = pbtn->GetCheck();

	for (int i=0; i<4; ++i)
	{
		if (m_bOpened[i])
		{
			PLAY_Stop(6+i);
			PLAY_CloseStream(6+i);
			m_bOpened[i] = false;

			Invalidate();
		}
	}
}

void CSDK_DemoDlg::OnBnClickedBtnTalk()
{
	// TODO: ���豸�Խ�
	CString strIp, strPort, strChannel, strUser, strPsw, strIndex;
	GetDlgItem(IDC_EDIT_DEVICE_IP)->GetWindowText(strIp);
	GetDlgItem(IDC_EDIT_DEVICE_PORT)->GetWindowText(strPort);
	GetDlgItem(IDC_EDIT_DEVICE_CNL)->GetWindowText(strChannel);
	GetDlgItem(IDC_EDIT_USR)->GetWindowText(strUser);
	GetDlgItem(IDC_EDIT_PWD)->GetWindowText(strPsw);
	long nType = ((CComboBox*)GetDlgItem(IDC_COMBO_TYPE))->GetCurSel();
	nType++;

	ADK_Camera_Info info = {0};
	strncpy(info.ip,(LPCTSTR)strIp,sizeof(info.ip));
	info.port = atoi(strPort);
	info.channel = atoi(strChannel);
	strncpy(info.userName,(LPCTSTR)strUser,sizeof(info.userName));
	strncpy(info.password,(LPCTSTR)strPsw,sizeof(info.password));
	info.streamType = nType;

	long res = ADK_StartTalkByDev(m_nApiId, &info);
	ShowRes(res);
	if ( 0 <= res)
	{
		m_isTalk = true;
	}
}

void CSDK_DemoDlg::OnBnClickedBtnTalk2()
{
	// TODO: ���ݴ��ھ���򿪶Խ�
	HWND realplayWnd;
	long nIndex = ((CComboBox*)GetDlgItem(IDC_COMBO_INDEX2))->GetCurSel();
	if (nIndex == 0)
	{
		GetDlgItem(IDC_IMAGE_PLAY, &realplayWnd);
	}
	else
	{
		GetDlgItem(IDC_IMAGE_PLAY+nIndex+1, &realplayWnd);
	}

	//����ر�
	long res = ADK_StartTalkByHwnd(m_nApiId, realplayWnd);
	ShowRes(res);
	if ( 0 <= res)
	{
		m_isTalk = true;
	}
}

void CSDK_DemoDlg::OnBnClickedBtnStopTalk()
{
	// TODO: �رնԽ�
	long res = ADK_StopTalk(m_nApiId);
	ShowRes(res);
}

void CSDK_DemoDlg::OnClose()
{
	// TODO: �˳�ǰ��رնԽ�
	//if (m_isTalk)
	//{
	//	ADK_StopTalk(m_nApiId);
	//}
	ADK_RemoveMTS(m_nApiId);

	CDialog::OnClose();
}

void CSDK_DemoDlg::ToTray()
{
	m_nid.cbSize = (DWORD)sizeof(NOTIFYICONDATA); 
	m_nid.hWnd = this->m_hWnd; 
	m_nid.uID = IDR_MAINFRAME; 
	m_nid.uFlags = NIF_ICON|NIF_MESSAGE|NIF_TIP ; 
	m_nid.uCallbackMessage = WM_SHOWTASK;

	//�Զ������Ϣ���� WM_SHOWTASK ͷ�����ж���ΪWM_USER+1
	m_nid.hIcon = LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_MAINFRAME)); 
	strcpy(m_nid.szTip,"ADK_API_DEMO");//������������ʱ������ʾ������ 
	Shell_NotifyIcon(NIM_ADD,&m_nid);//������������ͼ�� 

	//this->ShowWindow(SW_HIDE); //���ش��� 
}

//wParam���յ���ͼ���ID��lParam���յ���������Ϊ
LRESULT CSDK_DemoDlg::onShowTask(WPARAM wParam,LPARAM lParam)  
{ 
	if(wParam!=IDR_MAINFRAME) 
		return 1; 
	switch(lParam) 
	{ 
	case WM_RBUTTONUP://�Ҽ�����ʱ������ݲ˵�������ֻ��һ�����رա� 
		{   
			LPPOINT lpoint=new tagPOINT; 
			::GetCursorPos(lpoint);//�õ����λ�� 
			CMenu menu; 
			menu.CreatePopupMenu();//����һ������ʽ�˵� 
			//���Ӳ˵���رա������������ϢWM_DESTROY�������ڣ��� 
			//���أ�������������� 
			menu.AppendMenu(MF_STRING,WM_DESTROY,"�˳�"); 
			//ȷ������ʽ�˵���λ�� 
			menu.TrackPopupMenu(TPM_LEFTALIGN,lpoint->x,lpoint->y,this); 
			//��Դ���� 
			HMENU hmenu=menu.Detach(); 
			menu.DestroyMenu(); 
			delete lpoint; 
		} 
		break; 
	case WM_LBUTTONDBLCLK://˫������Ĵ��� 
		{
			ModifyStyleEx(WS_EX_TOOLWINDOW, WS_EX_APPWINDOW);
			this->ShowWindow(SW_SHOWNORMAL);//�򵥵���ʾ������
			::Shell_NotifyIcon(NIM_DELETE,&m_nid);
		} 
		break; 
	} 
	return 0; 
}
 
void CSDK_DemoDlg::OnNcPaint()
{
	static int i = 2;
	if(i > 0)
	{
		i--;
		ShowWindow(SW_HIDE);
	}
	else
		CDialog::OnNcPaint();
}


void CSDK_DemoDlg::OnDestroy()
{
	CDialog::OnDestroy();

	// TODO: �ڴ˴�������Ϣ�����������
	::Shell_NotifyIcon(NIM_DELETE,&m_nid);
}

void CSDK_DemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	//if(nID==SC_MINIMIZE)
	//{
	//	ToTray();
	//	ShowWindow(SW_HIDE);
	//}
	//else
	{
		CDialog::OnSysCommand(nID, lParam);
	}


	//CDialog::OnSysCommand(nID, lParam);
}
