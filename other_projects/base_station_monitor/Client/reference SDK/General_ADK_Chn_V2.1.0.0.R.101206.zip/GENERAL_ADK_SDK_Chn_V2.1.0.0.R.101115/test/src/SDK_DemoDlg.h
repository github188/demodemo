// SDK_DemoDlg.h : ͷ�ļ�
//

#pragma once

#include "PictureWnd.h"

#define WM_SHOWTASK WM_USER+1



// CSDK_DemoDlg �Ի���
class CSDK_DemoDlg : public CDialog
{
// ����
public:
	CSDK_DemoDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_SDK_DEMO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnClose();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

protected:
	void ShowRes(long res);
public:
	void playDataStream(long API_ID, const int nIndex, const char * data, const int len);

protected:
	long m_nApiId;
	bool m_bOpened[4];
	int m_nCurIndex;
	HWND m_hPlayWnd[4];
	int m_bCBView;
	bool m_isTalk;

	NOTIFYICONDATA m_nid;
	void ToTray();
	afx_msg LRESULT onShowTask(WPARAM wParam,LPARAM lParam);
	afx_msg void OnNcPaint();

public:
	afx_msg void OnBnClickedBtnLogin();
	afx_msg void OnBnClickedBtnLogout();
	afx_msg void OnBnClickedBtnPlay();
	afx_msg void OnBnClickedBtnStop();
	afx_msg void OnBnClickedBtnAudio();
	afx_msg void OnBnClickedBtnStopAudio();
	afx_msg void OnBnClickedBtnSnap();
	afx_msg void OnBnClickedBtnRecord();
	afx_msg void OnBnClickedBtnSetpath();
	afx_msg void OnBnClickedBtnSetDdns();
	afx_msg void OnBnClickedBtnStopRecord();
	afx_msg void OnBnClickedCheckView();
	afx_msg void OnBnClickedBtnTalk();
	afx_msg void OnBnClickedBtnTalk2();
	afx_msg void OnBnClickedBtnStopTalk();
	afx_msg void OnDestroy();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	CPictureWnd m_ImgWnd1;
	CPictureWnd m_ImgWnd2;
	CPictureWnd m_ImgWnd3;
	CPictureWnd m_ImgWnd4;
	CPictureWnd m_ImgWnd5;
	CPictureWnd m_ImgWnd6;
	CPictureWnd m_ImgWnd7;
	CPictureWnd m_ImgWnd8;
};
