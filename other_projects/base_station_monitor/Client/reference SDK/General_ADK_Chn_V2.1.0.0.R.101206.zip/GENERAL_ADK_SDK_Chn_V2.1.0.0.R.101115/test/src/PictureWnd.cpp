// PictureWnd.cpp: implementation of the CPictureWnd class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PictureWnd.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
#define X_SAFE_RELEASE(x)	do{if(x) (x)->Release(); x = NULL;}while(0)

CPictureWnd::CPictureWnd()
{
	m_crBkColor = RGB(160,180,220);//RGB(162,189,252);//(COLORREF)0x0010FAFB;
	m_hbrush=CreateSolidBrush(m_crBkColor);
	m_nBKMode = MODE_BRUSH;
	//m_nBKMode = MODE_NONE;
	m_bShowMode = MODE_TILE;
	m_pPicture = NULL;
	m_pStream = NULL;	
	m_bProcStaticColor = true;
	m_bBkImage = false;
}

BEGIN_MESSAGE_MAP(CPictureWnd, CStatic)
	//{{AFX_MSG_MAP(CPictureWnd)
	ON_WM_DESTROY()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CPictureWnd::~CPictureWnd()
{

}


void CPictureWnd::OnDestroy() 
{
	CStatic::OnDestroy();
	
	// TODO: Add your message handler code here
	if(m_bitmap.GetSafeHandle())
		m_bitmap.DeleteObject();
	X_SAFE_RELEASE(m_pPicture);
	X_SAFE_RELEASE(m_pStream);
}

void CPictureWnd::SetBkImage(LPCTSTR szImage, BYTE bShowMode)
{
	m_szBkImage = szImage;

	if(m_bitmap.GetSafeHandle())
		m_bitmap.DeleteObject();
	X_SAFE_RELEASE(m_pPicture);
	X_SAFE_RELEASE(m_pStream);

	if(_tcsicmp(m_szBkImage.Right(4),_T(".bmp"))==0)
	{
		HBITMAP hGMap=(HBITMAP)::LoadImage(NULL,m_szBkImage,IMAGE_BITMAP,0,0,LR_LOADFROMFILE);
		if (!hGMap)
		{
			return;
		}
		m_nBKMode = MODE_BMP;
		
		m_bitmap.Attach(hGMap);
		BITMAP bitmap;
		m_bitmap.GetBitmap(&bitmap);

	}
	else if(_tcsicmp(m_szBkImage.Right(4),_T(".jpg"))==0 || _tcsicmp(m_szBkImage.Right(4),_T(".gif"))==0)
	{
		CFileStatus fstatus;  
		memset(&fstatus,0,sizeof(CFileStatus));
		CFile file;  
		ULONG ulFileLen = 0;
		if (file.Open(m_szBkImage,CFile::modeRead | CFile::shareDenyWrite))
		{  
			ulFileLen = file.GetLength();
			if(0 == ulFileLen)
			{
				file.Close();
				return;
			}
			HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE, ulFileLen);  
			LPVOID pvData = NULL;  
			if (!hGlobal)  
			{
				file.Close();
				return;
			}
			if ((pvData = GlobalLock(hGlobal)) != NULL)  
			{  
				file.Read(pvData, ulFileLen);  
				file.Close();

				GlobalUnlock(hGlobal);  
				HRESULT hr = CreateStreamOnHGlobal(hGlobal, TRUE, &m_pStream);  
				if(S_OK != hr)
				{
					GlobalFree(hGlobal);
					return;
				}
			} 
			if(FAILED(OleLoadPicture(m_pStream, fstatus.m_size, TRUE,IID_IPicture, (LPVOID*)&m_pPicture))) 
			{ 
				X_SAFE_RELEASE(m_pStream);
				AfxMessageBox(_T("fail to load image from datasteam"));  
			}
			m_nBKMode = MODE_JPG;
		} 
	}
	m_bShowMode = bShowMode;
	m_bBkImage = true;
	return;
}

void CPictureWnd::SetBackColor(COLORREF cl)
{
	m_crBkColor = cl;
	m_nBKMode = MODE_BRUSH;
	m_bBkImage = false;
}

void CPictureWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CDialog::OnPaint() for painting messages
	CRect rcClient;
	GetClientRect(&rcClient);
	if(MODE_BMP == m_nBKMode)
	{
		BITMAP bitmap;
		m_bitmap.GetBitmap(&bitmap);
		//if(!m_bitmap.GetSafeHandle())
		//	m_bitmap
		CDC memDC;
		memDC.CreateCompatibleDC(&dc);
		CBitmap* pOldBitmap=memDC.SelectObject(&m_bitmap);
		if(m_bShowMode == MODE_TILE)
		{
			for(int i=0 ;;i++)
			{
				for(int j=0;;j++)
				{
					dc.StretchBlt(i*bitmap.bmWidth,j*bitmap.bmHeight,bitmap.bmWidth,bitmap.bmHeight,&memDC,0,0,bitmap.bmWidth,bitmap.bmHeight,SRCCOPY);		
					if((j+1)*bitmap.bmHeight >= rcClient.Height())
						break;
				}
				if((i+1)*bitmap.bmWidth >= rcClient.Width())
						break;
			}
		}
		else
		{
		//	rcClient.DeflateRect(1,1,1,1);
			dc.StretchBlt(0,0,rcClient.Width(),rcClient.Height(),&memDC,0,0,bitmap.bmWidth,bitmap.bmHeight,SRCCOPY);
			CRect rc;
			GetWindowRect(&rc);

		//	rcClient.InflateRect(1,1,1,1);

			dc.Draw3dRect(rcClient, RGB(0, 0, 0), RGB(0, 0, 0));
			//dc.MoveTo(0,0); 
			//dc.LineTo(rc.right,rc.bottom); 
		}
		memDC.SelectObject(pOldBitmap);
		memDC.DeleteDC();
	}
	else if(MODE_JPG == m_nBKMode)
	{
		if(m_pPicture)
		{
			OLE_XSIZE_HIMETRIC hmWidth ;  
			OLE_YSIZE_HIMETRIC hmHeight;  
			m_pPicture->get_Width(&hmWidth);  
			m_pPicture->get_Height(&hmHeight);  				
			double fX,fY;  
			fX = rcClient.Width();
			fY = rcClient.Height();
			//HRESULT hr = m_pPicture->Render(dc,0,0,(DWORD)fX,(DWORD)fY,0,hmHeight,hmWidth, -hmHeight, NULL);
			if(m_bShowMode == MODE_TILE)
			{
				CSize sz(hmWidth,hmHeight);
				dc.HIMETRICtoDP(&sz);				
				for(int i=0 ;;i++)
				{
					for(int j=0;;j++)
					{
						m_pPicture->Render(dc,i*sz.cx,j*sz.cy,(DWORD)sz.cx,(DWORD)sz.cy,0,hmHeight,hmWidth, -hmHeight, NULL);
						if((j+1)*sz.cy >= rcClient.Height())
							break;
					}
					if((i+1)*sz.cx >= rcClient.Width())
							break;
				}
			}
			else			
				m_pPicture->Render(dc,0,0,(DWORD)fX,(DWORD)fY,0,hmHeight,hmWidth, -hmHeight, NULL);
		}
	}
	else if(MODE_BRUSH == m_nBKMode)
	{
		CBrush backBrush(m_crBkColor);
		CBrush* pOldBrush = dc.SelectObject(&backBrush);
		CRect rect;
		dc.GetClipBox(&rect);
		dc.PatBlt(rect.left,rect.top,rect.Width(),rect.Height(),PATCOPY);
		dc.SelectObject(pOldBrush);	
	}
	
	return;
}

void CPictureWnd::SetNoProcStaticColor(bool bNoProcColor)
{
	m_bProcStaticColor = bNoProcColor;
}

void CPictureWnd::SetBkImage(UINT uResourceID, BYTE bShowMode)
{
	m_szBkImage = _T("");
	if(m_bitmap.GetSafeHandle())
		m_bitmap.DeleteObject();
	X_SAFE_RELEASE(m_pPicture);
	X_SAFE_RELEASE(m_pStream);
	m_nBKMode = MODE_BMP;
	m_bitmap.LoadBitmap(uResourceID);
	m_bShowMode = bShowMode;
	m_bBkImage = true;
}

void CPictureWnd::SetBkImage(LPCTSTR szResourceName, BYTE bShowMode,LPCTSTR szResourceType)
{
	m_szBkImage = _T("");
	if(m_bitmap.GetSafeHandle())
		m_bitmap.DeleteObject();
	X_SAFE_RELEASE(m_pPicture);
	X_SAFE_RELEASE(m_pStream);
	if(_tcsicmp(szResourceType,_T("DATA_JPG"))==0 || _tcsicmp(szResourceType,_T("DATA_GIF"))==0)
	{		
		HRSRC hPicture = FindResource(AfxGetResourceHandle(),szResourceName,szResourceType);
		HGLOBAL hResData;
		if (!hPicture || !(hResData = LoadResource(AfxGetResourceHandle(),hPicture)))
		{
			TRACE(_T("Load (resource): Error loading resource %s\n"),szResourceName);
			return;
		};
		DWORD dwSize = SizeofResource(AfxGetResourceHandle(),hPicture);

		HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE | GMEM_NODISCARD,dwSize);
		if (!hGlobal)
		{
			TRACE(_T("Load (resource): Error allocating memory\n"));
			FreeResource(hResData);
			return;
		};
			
		char *pDest = reinterpret_cast<char *> (GlobalLock(hGlobal));
		char *pSrc = reinterpret_cast<char *> (LockResource(hResData));
		if (!pSrc || !pDest)
		{
			TRACE(_T("Load (resource): Error locking memory\n"));
			GlobalFree(hGlobal);
			FreeResource(hResData);
			return;
		};
		CopyMemory(pDest,pSrc,dwSize);
		FreeResource(hResData);
		GlobalUnlock(hGlobal);

		HRESULT hr = CreateStreamOnHGlobal(hGlobal, TRUE, &m_pStream);  
		if(S_OK != hr)
		{
			GlobalFree(hGlobal);
			return;
		}
		
		if(FAILED(OleLoadPicture(m_pStream, dwSize, TRUE,IID_IPicture, (LPVOID*)&m_pPicture))) 
		{ 
			X_SAFE_RELEASE(m_pStream);
			AfxMessageBox(_T("fail to load image from datasteam"));  
		}
		m_nBKMode = MODE_JPG;		
	}

	m_bBkImage = true;
	m_bShowMode = bShowMode;
}
void CPictureWnd::OnRButtonUp(UINT nFlags, CPoint point)
{
	int a =1;
	CStatic::OnRButtonUp(nFlags, point);
}